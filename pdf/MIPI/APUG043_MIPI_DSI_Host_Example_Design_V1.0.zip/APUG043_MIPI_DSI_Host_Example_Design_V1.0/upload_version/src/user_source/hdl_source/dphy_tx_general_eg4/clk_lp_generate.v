

module clk_lp_generate(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_lp_p,
    output wire     O_clk_lp_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
JK+CjUl46ZpafkxgXa8O9xe712crMsrK76Sn6EvAvhV5IaPnYjGL8AUomkhBj5nN
WlPrR1NfkkwDqlUwKFWpQoxb+qzUPCdEl+2GW9zdSv8ZrOKc9QaUnxnFEDRerV55
TLKMRj0wz9XWbAb6OufyrqIv3/ohKUx1qj2R8Nwl700=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1808)
`pragma protect data_block
cVF3cldnWmE2OGc4TjJTeknzQ3IP/t7yyMZPrMkiIsYsrRFXkeSPUpKu/4zDS+gx
ADg2wN+Lpu/+QeEXQuwZ84uDTw7ZxzW/d7WcstIV8v0i8EbDcRDYKhrc50B65mCe
c4pTWPfvclbfZ7aOwGPK+s29stkr6lFnDEmRdWXkXEfGIYKDDwI3ZEVU+nseyl/e
AuPBt9nJyCxs/kgsme7mWkYYC3fnGY80YM4RVUOIzs72JOyxyt2eZhrTElI3ie2W
bL8hzmeIlAOucCC9GnpE4PIZEQvZfNX4EUefR6sPQEt5NAx3JQoYwJVbRgpb0j5S
ncNNzrq6O1rsAbcgrbsPGOH0fUiDNUhM+67u6R7u4fYShh5jNUhe4OlZ2xh9/4fj
oQE4MM1A/B3hqQA/kJ05WtXtxxMtUaTZzRF3XmN74xAeMEWEgEWtKKK8Inug3BLA
Y8MHExoCQiUHJ7N827KmXIpxhmoz1eKBhx+eQ0zWW2iCmm5XOYZLEggq2Gw35ryz
95TOR4uJnHJFCmuEaTUO92grViaS+QwIr+GgHYwji0yjB2vpBunRn/rBm8Uvvbjm
mQ57DU2K8O7Q1xrQaRjf6grSe6f8flti7Vg93AN5KpZ9w6baagXh5nfMjqzHAX+R
6CxholEfugCJi5l6ucSjdEq+BHcQClNJPfxFwNtW+1lECmahx/9ayDZUlFiG8o/H
UJtmTl+r1mPdhWJTuvUsL5DR7VDoRBYWvOpqsehvOjvwpD+bc6VVzFXEcrQGTzDh
paU1pd19cWvHywu7RJ+iNIQOJgOvRq6G43iOC6fdlW64n/NFpEZgGqZS8sYEhIUz
QhKtv76/wl1ED8+lihF7w6brlHqlEc2e3gMOy8GSOutSKzKQZrn7TgDtyDk8ZWBI
T0YBcEo1D55t89ovx+znuBeJhJdK94myZV7IvGqQUvrMqUc1YU0Rao1+1B8M+L/Y
xo5bPDayluUL/LaI2tMo7XSLU/gtP/O6cRIMpC/FhJmFCsrdJmrfISb03GxtJd3X
7PIvF3mHuZeVQXuIiHeYadbbG/t1Dcjgq4LjPkmAejWpdaTuY0Qtps3arMXDVdn5
ZLSnkTcIqgibyrXE6LDXO/cPPEJCCq9WZvOQ5DCstv68pQiiAQDUGpTABqTSMxlB
PFa7C1vk/nnDY2Aj96b6KjLykkGWWQ1EwzxsouRZS+hAl/gzqpfcOz7Ni1QNshr0
D0riY3zjLYEiLGvMECHQGjo3lLgcBspgrGWPg/RsaFTlDuoQt5c0Iws8VHF8CPUY
N86DIX0WPzHwORvvLV+K5ex81ddnJiwazNN4aXDP4b1nJsM44PmicsLa4sOCQIwX
uubwsxKZcpYM2zEdRc9lFpSlaWS3ZV9DMCpzRNX37tM6URqWoB+4KPBaFYtjriLz
t8idgnIbTVNCe3L9QKYOCCbXN6LcyW7DToRai5L8f0yuIYoUSy8p62+yvDbfBAAC
Ekz1PkG/5B2jKXzgWyyCctW1zKPLh5iRYGfgxtjwDpU38WMI3bKVJvD+7lyrvH/Q
saFqxZcay1uHjHGwFp7d11kHmoEMc7uB+0AcGEeDzIWGFFIj3mFRpn6WWqodV4vn
8ISDSGaODRaxwaDOBJLQnwxwF9L1Wc9199OUC6W9NIJ05i6Op+/1YzjJsuj+aRQ6
tUa/r99hH1J4waEDtIFr/rK1Wtf+122qVDuEnNrAUGILh0iRvJSoDa3GUR7pDzvJ
WIPih6o6XSYloY/U1zk/4kjRGE/8qehzVg9ayUnO3+OJwPmNaGdSH2tnMWZSyUln
ShNGf/mmslGSbUfokHg5BdkRHc4E5ADcnqHxUxuq8QeSeW4GwQ7rNXxZ0W9A7aIM
dtXYdiy1zUXnp7WtotbgtvkNIi6/1YGtYGNy8JoeBu7n0+V/n12QXcRXXo/gPNWX
RuAUDYu6NbuohvhY2ITYdoDmzkYTXoqG3SIEkzcSCa2vO4YvLD1MFnMRooi2xiBh
U51i7rK70izubp/0Om6FcedaENONj2ZOZS6k5PLUjV90qqZCatwaFJgbxgeiz2Ec
tPbN9hCLbm8U5gUluqo+Wr/hsK/Nv6oG2VMatf7IuCF0gEqaeH0rzkxubfudgC9i
FWwyrW2Sp+1G6NibYcvjdNHVNTzOAiCCnkPWmw8KFvLop94QkUSClcOzKpP9JzKk
8UzNg1lISruIFivA7F2+S6Af2sEBni45txPssJhVyrjSCWhErBnk15xeH2yX9eH1
IQqd29FPzK9LokwdtmapkRVNA9+8ueyMAmK22LF9FvPAoioyHuSSIU4LZ9Tit3Ua
NtRRMkp0W4EybcIonEvue4h9bJ4y1okGYeYPUlkwgK3KrZfUSVF+sm1pAzHrojWx
/H5p8w/fndUZMrFF3PuWAhHGwGHpJEtHs/x3habaGe0=
`pragma protect end_protected


endmodule