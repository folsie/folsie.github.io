
module data_hs_generate #(
	parameter FIFO_TYPE  = "BRAM",
	parameter DRAM_DEPTH = 50
	)(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4,
    input wire      I_rst,

    input wire      I_tx_valid,
    input wire[7:0] I_tx_data,
    input wire      I_tx_last,

    input wire[3:0] I_lane_state_code,
    output reg      O_hs_data_end,

    output wire     O_data_hs_p
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
fyMOQxN4XaZrTiQf51h0fXmI2zK62kwq/2c8Yhy3WkTO54PuXBl6je3/J2l8J0KM
BQjXqIurEAjGlvPh0R2xixuE1K5W9J/aE3jYk+MwguSPH6HJbyPu47DQNUZ98c8n
pF2/cClknC5JR+5hpRF3YADce44eLf7YxmvIiW92Gs0=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 3296)
`pragma protect data_block
UHcyRUZhS3JUcERlS01MMbMOJ277eL26foCeNSQmwKtmvlnbCa8OzmSSr8YmFejh
/Gy9ZVC/xWXS4lr2vKeB0KMfUHBHRbzbNbx1IVkpLCjKQ+j8HRTJDAUKAxJLOXOz
iys5vGv0bMRrgFyz1RPBhyBubXlzCOnxk7Xw2mpWMyyyRH8u4k3bbIXA90ZcSc0t
8OdFStsdmbZNMjjDB1q14W4cZnlGmPE1x7nMxQJq/dMHNXYA51JUOleqcfRrCRxn
SBY04gT59b3SuyRSFPkjfr5BrTjf9430thsr6zRYrZurk7I1q7XFVU/rlk2Qcq30
HJZXhTjz+pMpNstaD1w5cBD5V7OA2N3XAlqOWt0rvXu+wPbb3tOWxDru7mCOE17o
b8NL8SQpebRYEyazrrvjwYfWbt8AQdlTqg86OFI76ucgyL9M3o1rJ/kozUUGHp05
bHZnj+K+baOhZFTeMPTKcuLtDq2x82QoVMLehhq3wVOVhR5ur7hThUbFr6RZFpeS
/Ff2WlKd98/t4ZoZVaMJi1j58SX0XDoygBl2LIbAm8Z+G1wYFZctzhSovW+w9w5/
LHWYXRWJ6Wn64WK4Vqs/NGE4AljiOygJsl0vTN8h1LZo9zmX6pxwOqEr7q9Infvv
PDLf0mUNzxDEM92NQZoAKW5yO8Lb25P2ie3OM1XX15wJSzTQu54PbvVq7XvkUSJi
bs/hzOUBOkxdIXci2pCwXGn/ZLNEutxZYV1E26NWP3EvU7jLzQcv1EG3l1l1hAo5
SJdDijzBtduEMKwez+gk9W6S0vR1nR8TNYSeYLioOy7raLyPAXsqB4DudoAvN5I4
VxxKL6OB6ho5qMINtQ0E1ktLYDKXE1aNrCjY6g2qMTZMJF0ycP/ta//yuTRpJmZE
4WemQDVaqsfYQ3LmJXTXRsqOG9z81F39QFB2tdz4u3eYtTRz/w0xJjhsOvoFE3yD
po3Z9MMMO2L6bHbMNmFaZyzWC6g1CMUb0LNTap2qKbp5P/wf16Jox8AY4j7lrahi
rmoDR2u0BXmRyfql6Nhe0pr+squJqQcnKqe3X8hsCRbNcFdlx8gBfb1PKHaymFJB
ChGmqamY/nAsbfRyglxcQv461+f4uCCMFoH0j8Mi480K/CeIyXKTj/yamWBtR8c5
c3aGdlHokr6R0l90L7qnGwg3jzhBy3zsPUNdxITrUk9ZXewnMGyE46+7C1k/Pmx9
S0I5yLh70rdqKfNQcUtB/iuPTNUL/vVQNnUPZ+h7S0DKreygj0j0tC88qSUrESGT
8p40Jnyh7Nf0C8JEPuxQ8/3yxgwl37kFTgSn/qd8QWlZtxCkY1w0uPNgTqXLwE+W
TDzOnqqOvqDappF9L4SqUhnZj0Kkk47CdeyXSXTsXbB9p/TuB4nENGsu8RZ7dCIK
hBkW6eTe++XfSrTqhpQ6gIWrpj9nAShJwN4eIBdLCDbfzZ4RSdXpElLxz8XCwNfc
gmhlN2LHAFUW7DVxP2fBgnb/fRdOxsQAVkqqcOoDVSHH3x0boRvWqSvXepY1OneG
cLZJ0pApcnWhzeXEM17Ou1jp0AZ4OVQmfnjTeqiNFpn9hTquZHIrqExGtvYomadt
92xjUc0Jsr3JrgkrZM8HH+7wqT/ktNAgbTzWZs5lbaQSzSt4zcO43Uxbkrth2TDb
clZ0ZG8OoJentReY1Kg5urLywmuVDRszI059Erz4Ma6y5KZnSDvOCz9eE9yOG3iT
4frnHnC46UtOVbSWKVvGqz5HnJj7GF/cvkmkgQLhoZZ1mdycZ4UgZwNro4mnhf8W
/Yn/adV5eMx6wpPBnZ7Ycy7NUtutVys8GMrF+6kdDqqSGecIp0dpBM1QBkzziyOv
/s3op9UD0C2x2ia3gY58Y5HtRAnbfEis3EAr1YFWhaNzfarn8iOrgM4FLPPqIzZ8
3Vj78keBroZookb3FLhse4eZ8xIAmGwLlbugHoW9sODHj8GP4/HrcWkLo7KNrTa3
+5lEVb/qcJi8zMri0HH9DHK30ne0D8eGmzRAU3doGwWzsA6/lv4eMawCBYyfQe+t
rIuNgmsiMTM2Y9neGj1Ujhipn2EBdvTwDIoQv5V1O2GMylxbv7JD+tZ93pzmEi8q
6rw+UuWkP9v0Nocyr3Bagtbqav5sn0Tw4u01Ml5p10q4fOaUWvJFidrQm7rlXHZP
ej38ntLhhWNNPmFQUaXmd13LKDLXR/WWDVpmmz+b4KuP/nNwi4n+SQOEkc03j1Lk
UZjYBeuBntRpfvMv0ShqeBjI1UyPay6GK4nTMt1uZJCzyqgzDRByTlHJo3BvnKzE
qEVzlbtkZcS8Ll2BuFcUTgCbPu4y+j2n4+n/upIrlJwkvgqdDvRXHbQBCZi2uDa1
Aeqg5BLd01EE9DiL7mP7YblXqAD5dgbyfLtxoniKYJ5aYPG+XvLbC6eZvI03X7we
w8/ZTOfb3qN5tULxZEDYJDgD1QPu7xzVkcYGMMJsDjljbNwYR5jVb6crIEJxvK0o
+DkJA5U4qaUUeblZiqq3DajxGbQMDSfMdjoFCbc9C2Rj/dCD9rmPFkuJCKu+WKyy
Z5MlyCjQ6h+l8PjunLbTxQXgbY51NJWyghfea+HhpHUmncY0BJZwaLDIPfyrARwG
zWRsArUhx7qtfM0cSXIgbQSk+IC4Tmo+KIE6+KeBgYXkEnPXZZ/oJ7jvPyOwy9GZ
tgudRte/m9ZJpr9m6yYBlYG64+asW2ni6Ei3cMcCuPUys1j0vO8EHYZ3OYxKrQRC
ngcNdOzX1k6jmH/vmOf2WutoJQOCaEvIC4Pb8xeeVQbttMxJ1DdKbB1uxshn1NCO
hcBsFZ53X8zxwTjGfba/HMkO+YIvH8Ab41MR6PjrOTC9RJ/P7UE43mP+C2ZStRit
V7LzNAOQnYkryA05AOSRZm9ZNWi6UnWPCWjlMbtdtX96xAqidUdansZbyc4BzYvZ
kWjKrn/GttQmK9uLYtZtPeRAMpy3pPyPquC5aiLHlKiO8jl7He6aOdCzO2ACYq/T
JaqeNS1qSby99+y4XFHizvcpodCG2VhIelOqmmgEQAA1ng70XVqjeKjOhq9QdpuI
vozA+CP329J936hrJMKIzfKyVAIirRFy42wSLipgms6RxJqUdttYl212ASf03x7t
kFpjufJBS8S7DYa32n5hMbIC17T9W1V7SvTkJr8yo1NeKCqo9t8D+mqw/3/OlJF1
NpBJwv9x3T1k/MOv3NifSTlrQQQN9l3G6TJwIGkHVWi8qeL2n10TZs+B4JAsrubA
PsLs9CP24IXkpVnqsLrpcLwbOzQCRVKd55pAbHjxT5nr0cPqMQtZZystnPCRwEwS
HKgY04LVk2CX6c4c8PPMe2rRcwRJGC5SVgZ9w7A9nbTUXEUyQiZrLjBncCgahq4h
vj0d01QNnk7VsH4LF9IIczkMEOXrHw7jFIXZwoS3li1q1SWjgUrACF35B1yI9Sko
YbQsXRTYrEmYZOK9LOanTj3NJG4mgBOb68zXRc9q2X8bqbiSPIHqEdRN9SgXv0J7
zApWQxId0t+Xh+lqKgnwiIWAY1UiKH0pbeQEKf3iuHMto36KBXbH47PhmBphWrKR
r6kh5Xc2wuzWcMhWT1qjvlejhB3XWP5fOQGG3YrkyzGo0FULe6e2xu1kRJTHkTSI
jnMdbKGbOiVxbDuWRDsLrK+MhOJ89gjeuwdZgWtLBPslD6t1qNEKaOnf3DR9l/D3
oVc+NSsaF5V3OsjpT35dNW5DaxwzcN+o683oJ9YWuzZDFg5r+APRs80xsftpUhLk
/jOCY2qmFqIOXpVn8Ks0ntmJMnyR3C4L2KEKdbcjv/qCEWI2S3dSs3dPd8yGpM1h
JeWY2dRwHYUqf6zFfunSZ1Lr8XlinDGuG6JivQgBcgrQ3UP3z5ityYq6UcyFOiO3
O50n8LVwBn8CUt0UhNLZolWNRMaVJ2icjj7wZsKugoE/48TwCLfKvnkqes4MhP/0
6aZCaKw6QwWJLq9P1OT3Z8IdnfCT5oasydsgJ3+pTUxI7rcE+FcuA7qlg882FFdk
AillBYab3/qlkOHooCUzm6SCwPmd1aXuAaRAALGV/MS9dNU5wIy6t1R3vKVFswOv
i2dO7YaLY3wB5P2ShQgqhqSJvgugNtcFmpbmbddhuLz02ngkImIPzcl5M+F8uz6z
Mc+QvVxaZv6BxDN83o7D9cyZ4lLOrmi0MkM2zA+n8HpuTM41EU5hjN2CZLAxzkiG
mU3uA4xP41gJSJsiyY7R9m2UgkUeRrmHuGj2hayxT9EBEWdZwgG2KXPc/H3AVjwc
zRQSUJkvyjfsKjOr94bactMGDVYyTaQlfxuf1hECNYqBJLHgRxUCToOqppp4H1Ql
sFhCBdhbdi17vaFcepgv3DmA0KdSvBw7OKJnqoqrtS4=
`pragma protect end_protected


    dphy_tx_fifo#(
        .FIFO_TYPE      ( FIFO_TYPE  ),  ///"BRAM","DRAM"
        .DRAM_DEPTH     ( DRAM_DEPTH )
    )u_dphy_tx_fifo(
        .I_clk          ( I_clk          ),
        .I_rst          ( I_rst          ),

        .I_fifo_wr_en   ( S_fifo_wr_en   ),
        .I_fifo_wr_data ( S_fifo_wr_data ),

        .I_fifo_rd_en   ( S_fifo_rd_en   ),
        .O_fifo_rd_data ( S_fifo_rd_data )
    );


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
gDmVfgifT3ARsPoNJ2z6Hx8GBh8fXqp1b0C0R0o4GnwApD9BqT6ynsAB2g/gl9oN
FLYnc5Jsw+y4G2w2JQMmtDABUxZ/q5uD5ACia762mcYfQ+lQQFaA1J5mkbyGoe0Y
bIbKXY+NT0Ss/Xr2l0tY3EH2mmTzSludHXB+aDknJts=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1728)
`pragma protect data_block
SkpwYk45WFVITVZaaWg5a0m9dXzSk8v96/c0JL2V+klDtnjHF1cmlKe2K6YExD5Y
vH6knIWupFFU72wjEKsPWI7nqIEakXPF+rpC/LdOn32tWhtNoNZRMTqQLN7vt8w2
k4oxlZYzE0KrPGY4U7WsOcGg3zv1C0Zpgv5D9FBJeYvsX5ZV3ZGJwUSbZBC+sHje
G2555JYc81SX2eRQVIcd8xla7KfAZRsrEHWvSHJBwcSa+FIq6WmK+dYuz1xoYHOT
4NsDRvMJ01mPucpq5CVpnBpisLH3Xis7RSuIlLqIXEzN1rXburUnvYHJeXuMlhb5
TVsuY6jTd3Z372FfMxwb6ohuY0ByTZ/SbYdabczU7QtovkuG31jtbXMyDQQEvTHd
aldrhjIcfQLfV9jcCwDHnUIwfz+uZ7qo0w4hHI2lAhLkf6gwEX4bcRc2FTwO7FrT
oVxkZpMumQuM6bEuSRetBMA4dvDlNnpRT+DCO4XQV3RAWpEKQjncqCPALfcvQD8x
TNdBpWwXbrlAiRtcauhuK86ih0JxdTUPDUp4/Xpi+z3jEUCNpHt2HYeUfqqCSN2n
wOereGv9/4HIZo7yOCPSnLGDLfmVekDFJz6dM8OAybG9ug5u0XmLnRzETNM1zws3
5prNphszY96KiBGZHGo95Lr3VGHJ1asD+6E+COdlMoI1FPDCYHNcQuoY2VvZ5KlU
AW0O2GCBBIs3LgVqtT3AxJg2xfiN1wn8NNes5agh+SDWrYfEuUvUjXIrNgNbk02u
r0HHvWvjsHynGpfr+Zd6KwVk34jzvJwEM0TUkBmqLaB2jJCTOrkBmoJQyHZV+Azx
pIAbAtd7QThIo5TcuH9hNkM4Owzj4YVTOi6Z8mOjS7F3zgHz+Mwr3BwuyPGdmaTF
LgLVsTXveNADSoFjqpypDguveTGyLkMrJ8A3hAkoRBYOFh58Bik+yTO0ekTaNK+M
5zWiMzq6lkP3Bc41y9SHPjypjWForrhkXX08Lr45+POGDDh4QxerDISTyJeBqoDs
9ykp75V+PaCW0WdIgZEZ53RBjN1tBGztigJqIN6h7FEzXa0yyo2W4PLoolB278/2
y3HSEUg0rzMBwTEYI5cYEbuwjKBGP/gSfNdtrhm+8KCpFetEzyb6JCe0MVzOK53o
6NgTssDGwGw6Qdd0yF/dZNa4zUv9LfMyy6sQkbO8n6Vg3nclQvwgb4y9zL6Mgl+B
yjoduff81XhsMikjuGftyGFSRC6Vgnjh6sUgij5ymTTMS/ogSckvb0fmeJ+5X0/f
TloUbEmMqhA1yiNSVnkcx6eJMVLP++pP97xtZO0M3SD77Sk5DDkWP0dxbnTrzS9/
5bk6OrjPwnneel49peGDmbEfWl/EmYFLks7NPxvO201mVZkIQXZZyeZKaq2ITENJ
4uKuK6CnLFHnWypPn0Mdohlx26HSLERxUE71+MGZIExHQVUZ69rYAHXUbHk3ElCX
zNkmAWoN5Dcf/KKlLhMUVy6cbB5fe5V6GpHeVTF9E3zlDbnqGtWkkXuB4y0hsjg4
glQJavHPwUVX1aFlV4WUkjhFkB7ROdslqmcA+W5RrPJ6AoTK/ZSf+yDe3G6d6Lx5
WLmXwsCTsZLCqbq9vvC6m2TLVVPNtRhwD4vy5h3ZV24oEhyo3rQBQ10Cs+lcsHH2
yPxJeDewTqJE+NJ/3Pes7LWMTF/zibviVaKIEEoUh9cCfw537XqqPP5/od1YCzEq
2sqlxjhfdTk6Je57Npzm7saztVeod1lkL17JpqhlPieuoKG5nRb+J3YUhOdGWVAC
Bd2nuN9sQl5wXhPoM/zni1GMI3BjOoIykP/n/5+hbjPD8l2TwqmaylG4RBGXUgpC
+uvFZ9FrDXGQbXx3grrx7mOySMHxT8s5t2gJKimIjJXObfGNhhPmt+y4ZtpTDmJ9
ybiGt9wBgzevJ/TewfJYSZJS91HjFe/7U/SEpuwL8ReV1XXSHga8IL2uPIoyrcSd
sSPFGyoEHsRmpZbmbmDQ5gGCSMgIf7Cmh3IXdAcdrESjRE1HdT8OkwlKbpL86pIL
Y2kEee8Djr7HfdzBqjJ81hyyj18fKAIw8t1hSzFZlQDM9MhaYakS8mEhsY3FeKkx
bcldAg39e2wNPsZEghVQgbJ0tMYRoprI9eRw9B1s1FFKm+eWuKjO3QTtvqfglJc3
AZ6NLAVhrvRUY8CJ3sSEZeOuLu+ZkRzqTnlSknuxVVl0EEsSBtLsgHLc/UPQUu0m
sYNwh21DAENgkTZ0NPAlah6h7TzhoGhg/UDQZbs65mlYwnZShhXeaRIP4iyFFu32
`pragma protect end_protected


	EG_LOGIC_ODDRx2  U_oddr_x2(
	   .sclk ( I_clk_x4          ), 
	   .pclk ( I_clk_x2          ),
	   .rst  ( 1'b0              ),
			
	   .d3   ( S_data_hs_oddr[3] ),
	   .d2   ( S_data_hs_oddr[2] ),
	   .d1   ( S_data_hs_oddr[1] ), 
	   .d0   ( S_data_hs_oddr[0] ),
			   
	   .q    ( S_oddr_data_p     )
	); 

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
E6cnq4uGkHrfk0af3LKa5157qTzYxLBbjqoxcrxfBso0bT8jISE4OiLSf7Ch6rrR
du9JFqCvPv6H6RZtBRcoO8GfgXsf25Fjay77zAD7T4iFwVR1ywBJ9WP5G7amRW0x
SoKJZqCovYGhvSQPLibOeDg2KdO0Vu9ODOpHajWun7w=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
VjU2MU5MVkkxVzZnM1Rwc49MzKJ9ODbHPVTZburmlhNeJnP3l6iAV1mZ4NaiBo9u
0wor+PEZjU94PVrnvV7Y4j8w/zAKnriuBoIvCdgbf1hd8u0HgXIjFUKIEsHxioCD
`pragma protect end_protected


endmodule
