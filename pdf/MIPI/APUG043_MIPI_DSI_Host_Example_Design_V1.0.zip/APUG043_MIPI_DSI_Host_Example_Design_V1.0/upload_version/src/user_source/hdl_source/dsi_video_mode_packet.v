
///pcaket mode: Non-Brust Mode with Sync Events

module dsi_video_mode_packet (
    input wire        I_clk,
    input wire        I_rst,
 
    input wire        I_vsync,
    input wire        I_hsync,
    input wire        I_de,
    input wire[31:0]  I_data,

    output reg        O_hs_en,
    output reg[31:0]  O_hs_data,
    output reg        O_hs_last
);

    parameter  H_ACTIVE = 800;
    localparam H_ACTIVE_WC = H_ACTIVE * 3;

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
UABKGi2IKozbMQq1Ls1XIRrnk5XloOA/F6hIL4qHMTRQuHre8Z8hseHMqHaPcAaA
a4EoF2MHhBRqJ2i0RjRIdU0YQh91xpQOqAI2t+9bG+O4CFVFu2FaXmJxk34pkLSR
i5yHyEztoel1NR1Lfh1RuK5oNqmF18cvew/ruHLepRQ=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 3536)
`pragma protect data_block
Y2NHQlpPZWNsWUw1TGFUdKfT+UqBGyt7mR2uQXI59l3Z+lZhoOwU33s38VgjZ9vQ
/Ohim6a2JXLQL23Bph0OKQiJh2VWXc5DNG3R42DcFpyr5R6bC8QN1Px8uxzssTEF
Veutq8l8Lrlorsd5wFHoZvBZu/yf1TyYrIjClPS9MSO3+W3hVWcC66xvHQMtAWEC
yD+fcaDnMy8ncgv1SHD1PfnkYiG3VR2OyFCxdLw+3kfZVQpQzfRPXP0guLAPVLWO
meTv4J5E2pEVNUyZA/t6Q3BbnqxTIRdwKS2WBwzJ8ybJK9vdzqkvTXzPaoq4ew20
04dhgwzbVhjxBRhOFR0YhtfrAJgIt7bvCECbP8B08R3rOk1ufl6vduuQATej53lu
oq+voC5qSPwky0BUuQU7ilIo3OquiaVAU2fWMDC1+N5vwi8v5poDjjh8ugMe6ECm
tAEtNaA7CdscRshjReU/z9LbyxHF3iigRuQMtKxGlSQBB5GOAcw5yBI45ywYO1O3
uhvP+bNqT8+eJ8SVzjE6M8yfBC528cIJ0ubXZROTLz4ALUD5EwGVHtB/3ptqj+lc
G0Kq2dRftR727P/OFXoGJYDLtTenDqd/dwpS4m98JI5VmRZ8IZ5rGydnNXoTLvqQ
3msPe3jmCxm5HwMZNX/G6KnTHd+ZTdO/ynjDh2ndlXK1ufrM5psZ0a+aah45yqQ/
XpX4+CsHkIBEbvdyccUQZCJ/6fBut5Az3m0NM6kJ6Q5MhrwF9WQozZvFh9cly8n8
b78AujDh8qNJBdZF9UewEhqSsjE/NPxiJjRHaEaqJHAu1y7N5Q7BY39NvPa8mApx
1dVAO6cS1QOEbqPlJO0W9fGcAXNgcHrefrGSN4t7G3jyn4OxyXJVKCzAqxNagKba
yxXgXRmbYwXEhT/G3hqh4LytWU6EYWTBtSWNrCXNBEX/USh23x7546KRrXoCJL7M
jv2ex6ICrcWHju+asoMjsGUBVwQZvTY+6L+/71SplsdjVrG0WLYdcYW6yqpihJgj
HFU1qqZSukzGYlSrMMFUHhehjv/OeMYNBizxXPunynZZFkJAWEIpQPHY5aoLAtob
U88HcQ6Zq4FnM7qdm8a1qvzNdA/nOCnpyzbiIfg6xfGvQ351IomNI7RFYhO1wBYp
NktJxPAA3v6R+kDP//PCaNDARVxVWoAS6gkMjBpqqM369QGiwl7mFZUMNNu1fti5
xx9xw8Z2UykykUovQpGvlkdTYaAlONczID+bw44vbpwZZJKl7TFg2XTeDEltJN6s
yoTl78iWCUc7yjA0crJkyoB3vkLXP2P2A+pGILOFklwhnj/DI28UuIA2MW1vMw5O
rxY16r59HWGEcKB7FcUxTxYPia+QRcGLWdXV5NgQ7z6GSl7GAyiif28PUyVEc8Zv
ihCz0NeLi/GPWWO5kD11DfmKWMQJKe4AI+yVb7wgHciwxyrr55mQJkvjDmUE/kiv
rsOHic+4YJcHg8416bh70FkBsr6EF6Rm+KkeHXcLyldM/i0Yyx4Skl049C0lIC/8
gro09Crgw3YLHpOxvR1/Uqm5bEiz0qylira1p8+PH3wiIlIQf9/TsvRbj3Uy+5KC
96tsVwWDsOkWjqimdh7prqGtklIwICEz7xEA/bFlLIj31Nk7ZqzbVmEa9dMV3YJD
jVnA96tTTjn8CyhH0dFABTjyyxuVBUh1VXc3qVlMcqb8cYUdLpDAQdFsEIPCZKwF
X/tRD6HIlVJrUG5YPXnKURVhwVFbXWw2qiQw6rJnZhpJczmGXMM+Lw678HdALcPK
6FVIlOHZv/6Wvh0scAkVLHOU2xn0YyQif56ePjpno8/44rD6YEfvRLBMJXRqa87i
qTieXT7nwEb2wajB7/+uXCTtmC+6Qk5hwPAw0MrWG1i/RLTnUEYglbFRjnpo0cLE
we+zSefSHKU7PYc9mVjyVBaBxePmAJ6Pc7Ax3bJ4+OrWfx9lESfU/Hxws+QRY3rx
aJuDiOX9xe5Y3RQz30KR+GJrnb6Fk4ijLiVAZWtC+ubmvNbnnIPdMIWgVDqdqSAd
pww4vx8diNcqekQTmht/Nta6dPt4k+24Fw/N3DYrZHQ8wzp/K9Y4PN5+EmEB55s4
CXK9JT38uDDLqQLM+Qv6GrX+IvP7R/GIhdrLVDWNiaEuM+Sim87BieScG77wiih9
SjhDcR7MsiDnRVEqR8zUBMHJvuTuj7yRUV+S3oO7nqg6wBivHJofrajj00Qm0y0t
LrSLbbo41e3Iepr+lYYcotLKizDmh9V2NUx0JA8Ldi8pMiiKpNp/ADy+6GyvGgGa
YsXyrANeOyzLc85jmgDRDBR8BH1vKQuu6YIl7I6NsdwZ7gt3JTdaUfxVg580GsSU
Gh/VM2RLMC/OvS+DjPdI9lcyxsF/LRFJjecOJadrPLG5LUCplVf+0G+RxMv0ay1N
oiI1bmkoAsmDLpXML6dZIG5r5APCswnmBCslpUEsKUhQXSImZ6sk4zGrd0LAmSqf
BLjI7n3eCq2u5IaexrlB9PU/JuBhz0zEyyhwdsqcOP7EHpLfvPW+65YYsp4jlau2
dPRAObfJ4vW8dgn7aU9+6qW8dHYEkq+1pxevyG+nWwUFhaX7vHbwWm0Xcdb/6xa3
mZDz7ZCuQcEMkEuB0ak/MHcCfd8+hnFCNdsoJ9SjfyNW8Abnf8t6e3ZCYUcKy/wq
01G1RJPmOgcZNSccao7PVCh9RENkyZak3eVIkxObDZ/f0WXF9DcfGjJsMwM6/u31
UdYun+oHXKL0tjugVrCMTJllAt+tyfU+g9bnIpAIe0A1pZKxgCasZv4ED7HGX3hu
yFfw9zfFBxGYYDjQqt0mnMGgOZmMgHImcYMne3b9t4BZtmcVFe5OAV/vDweyd/kh
ennNZOizNbONt4jGVr4oUebsbTn56bhpCOllaOAwNboT067Ui23ko2pN6jkB71Dj
kfxn9g7pt++6Aygitu3/2pADY0nrhypJjvBjCbmjkUzDv6PjM7MANeOLAR8Vj4HV
mB9Ybj52BxKLRvPQSFzsYBfqtawoZYGS/Chkf4lhCALSGCWQSycd7lGazGHvcBj6
KhyLzl1ZwgW3flkxqO081omplawIL4dQiFbHgntNZAjHdiXNmW/o2Pl7kc17UjUv
2gZIGBbwh6MMl8RfjKmjgTBu23wSe1NUQ17c9/UbOWdsC7NTt0pGdEBQ4a7CsGtG
HhtxsNS4s41EMRtvnnCLhKFlYvohaowf1kuvfpFlRsmymbGP2yYM5TrQWyzOjM0E
Pk3PwDewRBnDGrBF0u/7nSbftJsz296gNy3rqnv2f4uuIDQbYfngNh3JV0oGVkQB
3oQrsKu1RIOa5QBGn45z/nGJXcdy+4bojRcTbx6EqqhZrNV5V2LK5TNKqzEbZb4o
C89FHOta/TQcai5E/N45XbuR9rN5cFxfTh6wwbACxLi1VWwYo3ZUSsMAIGCxnQnz
FWGvsflOPXr8gLnijqNfj45/NdP5+xKfXDae/xGkpgfjxPbzxNv6w/vylTK4M1DV
XBW3IZ0+DHN1/bwuxrExMRqZMs6bqh7+V1EYoGvxhtjmMDKTL1y5Ll9zQIqtnCVh
BEPxOTphmqf3SItAe0rjfGfHMlwybv575ROo0rMBz5nFhh9wgif4dVT4IGLjI25C
TBbv3ogY/K/SyiPrLw86c0R03xO2pTuBiMPKSVG9ZZPTZrRN2ZYYxsfQeSfNlL01
+TyAlCcdgFEdU/QpR365IZYIhGoWRpGs3o5vo8z2jwDgGKrRgmWl+vsMpuI7sb7Y
lwFJFPC8ZZAhz+8RPXLJHDXa46faF41he+C4VcuX0rY+IyYsMl6Gmp4+xWZepwMR
IY/AFN3jpAowARsKMkwgxxiOtlYCEeUJFZzsnJMV4x6f1828yCvf+IoTxrp3d91X
pLshLzbpQP+cJlSmloBLXZ2axvjXmKlLdpu4Y4+pSmKCpRtKEXXFrVrn6Ipo7eKv
WwmEni4ahL3KIx5LyXcEXRwdTWUvtQ3GkAemkA1njxjhh5Ajj8Y0zh0kY/dvwGjH
4jWjXkXB3A9eQydRNOtZxvNxEmlTXZyVsqKCaII8jGe/GEzmKgr5low1/RYM865q
QF3V6X5ixlNn9I70LD8bdpQktgmqwW43evZJK2PH/1Zk5b2xruGJsud3vxJYC7Mm
piYO7YiZAp3UUMfN/spoWJQb//Mv/VoUvp3nHHlrpUACjmcP+1YqK+nl0PprShKT
pC1guIdf0OURhLT5PCayjLKHufGvXJAVDlrupbE+GRepzpmj5Uly0MSDcJCHuSVh
yQnPJz9krl3cPAPVU7xXKhFK7vMxTUOBpG8WdVgoHAFD1AMwaQDkOvSe9Yq1trM5
d0IYoGK5brDEZwgrEpygsGE2HPxy2LII3oXjHB1JfKq/bYKtaCI5Xeqm4ixXPUx6
oXx/61HDbgpnW4t0ZhAyK64QFGnbgrw9P78RFEnvxyNApGRsX0XsXMQKm9ib8jvf
ZlA1DHyvaAYNbpL9wfgbobHcuTsROmeU7QPQFaaiJR3i+SDfrVtYlkACHwOvryui
SA1AkKF59w/hBVJaC+mX4CJnSIU3Bj9DtbDcPnMfYSgX8Gw/k+rjchr0Fbh+Ouh2
gnpKq+AtU+ags5dnS+G/46oFOV02Gc90MrHEhzh/KB/O2rCpIT9WgQIa2aU50UJ6
jC61RUJx/vVi6YdRKhkkmh+sPplYgKeluhbLZ/viZHs=
`pragma protect end_protected


endmodule