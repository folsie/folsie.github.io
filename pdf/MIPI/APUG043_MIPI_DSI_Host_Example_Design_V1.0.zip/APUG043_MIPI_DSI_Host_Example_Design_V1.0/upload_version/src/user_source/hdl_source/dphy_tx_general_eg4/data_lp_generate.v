

module data_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_data_lp_p,
    output wire     O_data_lp_n
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
CN6NYseCRSf3w8MZCtYKfkKJvA0xChaP8WR3bthN3/VR9u3wydIkXGSkduXP3+ji
VwjBrAQcgriqIswYHvsUziGKwSzvyf0vJZ++blaQhCJ/uQK3TzhUPtqZjYAngaVB
ybTnZ6E+Tj9B9GjLaVOLkkXFLvIj7xuvUZbWzoZosfU=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2496)
`pragma protect data_block
ekl6c3pjM0FkZXNicWtuVrjNnzDNORbsV3h6N+ALgo8ldXBW8vr7w53+1kyaJZh5
93jTiWaD3uk0jtVMSrwGKKq54L5X1UyhTNg2b4T3685hMwLWjNaxI5ZqnealVZIf
Zvk1MqLz7o10MInOLE/h4Bkajv2zL7X/hI0WnFYgZIli9w0/Rcr4YktdaBvxmK4R
YTkH5L/EWpNFiZ99IFlEABUkuaiq5AswzAroaroLtwVlxTpem9M6MxaB4ehk5cwd
HvitJA11SBLwCvFe7CYBAKXa9lpEkp66QMDNxdhszTFRWH1u58OOGD6VP7PkTjiR
BlsX25tZBMPVK5TtPxWcnVy/nyvKIGpFlrxDbaFDS4eJ4VHEcUlpqZ+PwOHRyo4m
/dr66bSgNuc1KfY2gm4cpdobFBieeevQZ5jXr0r3X8uRNq9GlwuyWD1NbHe92Vuk
+Y51jaLNxXvEXKTkDb17gljRdgJdhr+OdnWUIQzbKetJ5Sijy9RxBtbCNv25jZyq
GkXQPjueqxj24rorOMHUCxMsUwA3JnRdyz4pQrqxtZreMRpzVeUguUId/+eL3HDx
j8aDvgNjoKt6AmihcnJgn3ZfbCHlaYFqdFZufCW1NplJO5ViIX2c6CYxk4FhURnz
ym8A3Tr3eUo5VkGsEmNOpniVlWpsG1z6NQZr4ND2k9q6pilaDDkCmeICkmVCecCG
Z5qH0LuFw6i41FA6ERT+yZO6Y87EwnS4Kf6inwAR4tdKt2DOkMQIulUgjJVMbBCz
w18Uu0Cea32dCuCSB9tVJ5JSCb9rrBcGQoNNQQARWGBYwU4tn2a/XakiPJOD1SFp
KqJMfUIx6bzDcdWWHaMWQI2H+8/098D2wTXkCrYAyIHzT5HKm+gubf0t5Q/A1jWX
dJ8m3Ayck7sULd9BcgDVmdjpaC87MtqpYrFzoatoEpwLpjpNj+8FO52nNx2x07ep
1gZ6zFklWRYUamPZ8g35Y9WKO9IwH7jYXvPc5PU2P65pSS61KQoHbzfkcTh0uC96
wRNMPIZKMioff9G+SpS51olGuN3wq0NvLjs8v0KkI+YuQYT5by/7F7GBjLZzVM3c
rIibYQWPFaf9GuXmOfV+xMCvhtCwGjhr7rbibRyscpfEbEgAQ9HIoTu3x/7M7bqW
rYqOliv+ihbZ/N4wCox8yrUY29zx+g7mEHphTNPmBo1fXZVlIEfQuTR/t1UBSNuj
ik5tLNFgQpyzkDd9cIkmBYIji8vY9ncwgQuHB/OUEZZ0McxL1ikaUj4absTjiWp4
6xurvLEV4Ad8BKcfopfMs4iu4AgfkIWHUQ0VtyuqAuVUXQ0zANkzi97iRKqcmgQ6
L0Xu6MDNy/HquMSjNXjhFbpQSNkd6FX5sFRHUBJNIfUEqMMlyuNl5twp3pOVwwdj
7U9FSn1R/gT70HNRQlhr40OK+BsMcN51+iZndlNV82acUF7T4bIGAqmjPc9o0Vg2
I5YyNWUi3uEofPL4N3b55G/25dYAAQC6pOrdYZT7yCCC7csWZdUoa8PjEu3b5m+u
F66eIpu3NGXaUj06b6sMyZfSDnEqpeRSGVIQQ+dEA1azfaNGfajFxJMt7cxcQR+f
+2Bzz+c2mWIujD37TR1He+YNa5Tg1Tkz53H6wkWHrZDzYq8RqXKtzuPnlAU1sltq
WGY6QlqxkWOi23Ve6eZn4i3YVl/bRF7HLkX4FDkwJDDEDwsOTQAtKvhnJ10kVsAn
ZKGgalLyP8GM5HSZNc7SfQQ2Zq/dgAOSFc75k7IjXWwe+HrKehUJRCuxAw95iuJk
KYwgFrONK2UHZdehDkjZxOEKcd9dbueiuLE8j7QB0bwIQmBbbWVHVolFXHu8O4Bz
q2yOSdtNgkcVEAuZhwmLtGSKaIi1uRNSac1CXdic+yQkqFhP8NmQq8zIwnWSttD1
qlQUh5PmViQ85uvmH17jF5JuDu2tImtooPMjcRLpfTubRS7Hf9xjZxUFZoSTh+iu
bHZc/dIlvI0e0YwRusGFiHZl7POh4TqP8iwhzUhdmnCQVLBKly93HQ9D/HdVoWJy
6z3mav8C2Zs0PL8C1AdLzthmp2ITWFmJQMR0/98LTQzs5JEEJqSqwRud1v3+J0ql
p+2XhS+8XJrfC3G+yh81q4Ux4zyek//xzNZhWnfz8wChxP5GUBYZ//IQLdh1yBsW
tGW5ysUlOoQ/mCA49dsvNl/qPuM4LrUFarK+xTuiNvDH05VpKIQK6R0JAyu8OL1J
XFG278DrrzyjGq7rClFxTXFHb4eZSyvzhMqM8cdim5ynCnClBhVHGm78GTrnmkX4
LzKoCL4giJQi7JqTzDgCyibESKDVGOHBPNmEwroLHT5CxHGu6p82VmIh1yTxB/9U
lOblG8UClz7DITuspPUWIKENZ9L08/ISdANlGy8Gp3EeljhEgthXuodeYeq184Rm
k2NvXL7HWUcWg2Q0fPw2lhKjou4GGcLJyFhMX9m9KIpPweK+FqUL5898obhCzwpt
0dpKwPpDKkxO21Yb9M8RKCpp/coYzpSKIDM8Byoxsnm+JVcxB1+J7IgE3haJ2cDk
imfOfXb+CLPu5fL2GZqjs5JXAQ5nGT5SlAt1nDc4hY3mEhxd8YdYUD02T48LaFZI
5csh1jPYQc1RpC8XfIyfXcRl7KMEhuuvVltqAOpKG2oitqW0QFMxdFuQSfoGNEUz
HdIBAbLRnJXtwMs160Nq+tY9dhxz/NrSYFVbSXWtTiBImZQukx1wrU2c+cyN0DUh
WwgJxemKA4oVgRMW2eGGUu1MAJBJdhV/DQSpTI665e7dVya4MNgbK3eX2xYRikAb
tlIrce9f9K2X+CI85QBq+6iMXBpLgfe8n5cKP7er/9k+PmwQ5EamQVvobMAfNlrC
q+SjEmM5BOxsmunzOujZJ3gQHGskl7qjQTIfWv1azlTi9GtwIYWURR2I+R5uhg6Y
x8Vy9O3CeU0X7wLfuzpsuhbN3L57fseQ0LmDAYsVHaUX0ceJVLCV0V18lha8MpFW
EszFLBOyICCMDGNbluKavJ/s2e4qm6nEvjeni0ToUUbszIqz4kOI9lYxJXKfD3k/
AcpdlS/eIoDhUlT4+LN0cmDPa5a5ON1EnVkjemWbkjqIu4wjwR4FPvwztcu8eBks
4IpTkX0MhBvV0tSj8JVBwvc8VSMxcewhshd8frInMy07D9nKA0d/YGhEpSU2s3+X
rQqQ7jrZ3zTXM/ema7DoFDSSouVVIFEyd7SyBPl80WtVmLrmUeKFnk6IntLNrdC2
Q3ldUudXLAeFVXRp5Stwc6kASTcz+hDpzEfiRQtgy/HuqzqxHcz4b9MW1uv8jt1d
`pragma protect end_protected


endmodule