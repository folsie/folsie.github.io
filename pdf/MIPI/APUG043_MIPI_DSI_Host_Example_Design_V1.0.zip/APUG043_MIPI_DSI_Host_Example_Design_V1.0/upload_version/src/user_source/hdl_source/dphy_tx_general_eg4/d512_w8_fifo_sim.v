// Verilog netlist created by TD v5.0.25750
// Mon Sep 27 09:49:04 2021

`timescale 1ns / 1ps
module d1024_w8_fifo  // d512_w8_fifo.v(14)
  (
  clk,
  di,
  re,
  rst,
  we,
  do,
  empty_flag,
  full_flag
  );

  input clk;  // d512_w8_fifo.v(24)
  input [7:0] di;  // d512_w8_fifo.v(23)
  input re;  // d512_w8_fifo.v(25)
  input rst;  // d512_w8_fifo.v(22)
  input we;  // d512_w8_fifo.v(24)
  output [7:0] do;  // d512_w8_fifo.v(27)
  output empty_flag;  // d512_w8_fifo.v(28)
  output full_flag;  // d512_w8_fifo.v(29)

  wire empty_flag_neg;
  wire full_flag_neg;

  EG_PHY_CONFIG #(
    .DONE_PERSISTN("ENABLE"),
    .INIT_PERSISTN("ENABLE"),
    .JTAG_PERSISTN("DISABLE"),
    .PROGRAMN_PERSISTN("DISABLE"))
    config_inst ();
  not empty_flag_inv (empty_flag_neg, empty_flag);
  EG_PHY_FIFO #(
    .AE(32'b00000000000000000000000000110000),
    .AEP1(32'b00000000000000000000000000111000),
    .AF(32'b00000000000000000001111111010000),
    .AFM1(32'b00000000000000000001111111001000),
    .ASYNC_RESET_RELEASE("SYNC"),
    .DATA_WIDTH_A("9"),
    .DATA_WIDTH_B("9"),
    .E(32'b00000000000000000000000000000000),
    .EP1(32'b00000000000000000000000000001000),
    .F(32'b00000000000000000010000000000000),
    .FM1(32'b00000000000000000001111111111000),
    .GSR("DISABLE"),
    .MODE("FIFO8K"),
    .REGMODE_A("NOREG"),
    .REGMODE_B("NOREG"),
    .RESETMODE("SYNC"))
    fifo_inst_0_ (
    .clkr(clk),
    .clkw(clk),
    .csr({2'b11,empty_flag_neg}),
    .csw({2'b11,full_flag_neg}),
    .dia({open_n47,di}),
    .orea(1'b0),
    .oreb(1'b0),
    .re(re),
    .rprst(rst),
    .rst(rst),
    .we(we),
    .dob({open_n68,do}),
    .empty_flag(empty_flag),
    .full_flag(full_flag));  // d512_w8_fifo.v(41)
  not full_flag_inv (full_flag_neg, full_flag);

endmodule 

