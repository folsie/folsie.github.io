

module ecc_gen (
    input wire       I_clk,
    input wire       I_rst,

    input wire[23:0] I_ecc_data_in,
    output reg[7:0]  O_ecc_data_out
);

   
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
gVjeHIhciXfR+wLBbLljy8w8tLRDl33haRTwmycFjcsAZ1gC57fcMAO7M1gy4hW6
pdYvHpte4E5Lf6RMzCl8CGA2LLbnb1uuqMMgvTJSJIvuXpzpkADa51cHQQiZycfA
HxI7POz/Xb/IMu0c83uG8gqXz9D4tIp9KSMvpd08nzc=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2000)
`pragma protect data_block
YlN1eHZCUmNBTUF1RnVEcgg0mG3kHJNY9yTbivExBl6UfE9EXyO3SocAfqudOVl+
mhTjxkshzkP9GvGq7CwYxh8hjHvXAZ6gJaOdF+x8dqqx1N8Xl9T2aIQ/P5QPDkSx
dsUrLVkQnphAv1X8q5eci+ca6g57YERbdxklt8ndTplEAaI6ajNvbYLPL8BDi4u+
5gA72+0vbu2N539Q9LpT6zX/kJV2PsyjgA/AduoYZUDa3Fq6swkVx7IBGcCEAsoi
OhUplmrgVwc6FBzlU9TpsmWqvIIE+uvrQ14Cb+Hu1Yp/DxiIvBizCAZlk5s5Q3SQ
7+TYIAIOMutY/gqwhd2Vj9q0eSDOzXtr0XshByAtRObVxDFxxhsMbKkMex8blzKH
N6JRHjxi53mKITXXSVWuA60IL/QSAeqhxubCllB3/Mmy+MGX8DM1BzJHMXZTtwqB
HYmJx57nvk4FbicI+6c6xco1Y8n+38OWQIbQVlgecea+VSFq/tm/dAlRgbv9/J5R
cHVDUDUsqrDo8FwAZFb/SellgMxpFCauWx+r4/j0qu1vnPrY86CU5t5LHqmkVeVR
Au6iWXwH2EHe/DI7J/QluijA3XvV+gjNSk+qRgkCgu51Hilm9BdaDm5mjVzzjWr2
kkbNcxADtE8xYZTD9z0SSelwQcJ//qtmbsnt2SweFtuqpa8CZa05QP/OJhuauwqA
u9ExjLM3nwDe8WpfxV9V3CWRVFK3xtLpOo+xPHE4eHl7hS18T0RETiVk+x2MIJ0M
BTp+ZPHETPuVCRAVAlVyK00t78dq/wka36TQ2Y8lT8aQ/oPVCsb5WMMFHx0SqRs5
rfR1m5YYB0nRxo0IOPB1LYF5k6tjrcJKUgJAxtMW9rCD6KH3Gu5YKLah2pFTA673
/m5Dyl1M/+OyCBuw597M1RZBef6HSKAOvDEFkBihf8Xkx8u+xvQNtfwn285lb2aa
0QOXnUghaTWaSb0+zUW2sEgu++kxvej/obtuW96140rCUP1dOcFa1oKlSZ8TceQ4
k0HqYKi3wVpEhHCccvwVKHvPsX7mc4ad8eBAAtpx1B9dypI5WW/id6tPh6iYphf4
IjnWRA+BKCVngZM6DXrbCES8Bx1PrafXwLZVC8ImBEDq8IOrbmCMAKsK1gf7Olmt
SIbxilu+Q44jDovdcM+xzojo+cwY4Gg00/ixnjX78fw9+anoEMZqChXT311i6DOp
wrpmeFtgT5nd8Mh2j3k5t6KhzdFMPmcJA4jp97J+sJUroVUwsHRjqwLmcoBO2OQg
MsDNNfPNAgkZ+3Ntw8eqmgna78PSWgZK06rSLYa/JuCBXdOW2eobqF35Dw8738r1
+c88S5SKFKl77qnJKR91frCidhNrzxRNq2xX8EjnytPsfSohbWTVloLF/DNZul9A
ZsEMa9I162VhBqqSJJEOUdYDSiKW/02v+y4A7oZyau4OXexOY+p9wk3IRHRofsME
9wK2bUvywJlrxez5+c/MXVIGAJXAAwmrHKEJCsgTAosYKC1Ps2TpNFb5HGpqi0tL
WMKvspiGr6eZmt9qX9fGhkq4otCWsL7jQl6tQgoB15r32AGCdf7MLWZz8XNAE20b
omGDBCWACh7Wvda7wGoBzgmOkZvGaud9Md4DSRy79Ff3D2w+XgATrzlt3IxhDYgM
AVWjYFqzOzYNT4opWqb8A93qM1HhzAu6bRKyvFNQdFDS+pZAiss/otc8isjLwlRy
fRlNnLO+aQ2+NbgfAvKQRlx/IxPsMSg+MVK4RPfQaDap97Isvxap77YFwm3351Y/
q+chSHAgOiUA0zVnO4ctRigE3jwBy1Bw2froAhRUYrd2qkkvbDrwEJbxZaFpCPfU
kud2EepWuQLM1jaOnNgqZEQeMOWDEbS5n3uxlYUMwaPC8dxyBdaqnmeD5aN5FhpQ
CwikwkC2+AF8AVIVflUlZkUlXaQPWvmcPOkPZbnGda87btM7rVysxJxjgpm9X6ji
gIeD54hucIr7tvXPRz0Zlr0vKrdDlJv6xToplqrBoqkOOPBQLyxq6ShBMqdX3wfj
GW28iuZS0iqGJHWE4NHs1yrWeWJfeByGWzozp+QFerXxmFpYbK7/fzpjE+ul7POa
nOuHALGyqiqyG2hU+6MiKsjI/VvDYTY/aEc+xDj/LdRmNoU5mVjhg6KoCuNJnTOs
azsQy2PsIB0n2GITFPH2HgiFiKDrmVgJK5YBbwiDgGmt5WXLyJbs1A00adEvsaLS
1N6qmr7oMDaXDFbBKhvoKBjkHjn+wJ9gPgNNy4mFi2dcuQVz4IkvaorOmsIRaVsb
EWqmhgEtEkbFIxd9KtQATJydIGKI3eHKbQbyw57vOAcOyT9tQsdQN2uiAAJ9S1FU
hwEfqCIVMioFkrFuexa0DzPp3K3wEkQY7J2eTvW9pJf8b27s1/QhnvmjFqcGeu+D
7mxowe6hGPgzLdW2TeMgILLNm3Qo3rJF4Vu1Y/465Y0EgfvJOjlQJFqY1KDkrRn0
cisUBE45/fmyzhNCwwk+ahXvptXwS3nE8v+U/N2IwftrSaDEJSBk45QUFN7l1JfH
1sOLxUdLjrE0mJn2WpXFP9ks02xFsrOwB32x6cmIWCe7ppOSoicJX/Yk6D4qJIkd
DmRSapusL1/bMoJBjmCkQ52RAemIH88GrL+OwYA/QzE=
`pragma protect end_protected


endmodule