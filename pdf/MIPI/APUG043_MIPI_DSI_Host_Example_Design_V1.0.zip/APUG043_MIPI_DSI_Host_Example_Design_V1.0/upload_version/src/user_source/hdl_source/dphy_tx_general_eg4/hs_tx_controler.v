

module hs_tx_controler #(
	parameter CLK_LANE_MODE     = "INTERRUPT",

    parameter T_DATA_LPX        = 1,
    parameter T_DATA_HS_PREPARE = 1,
    parameter T_DATA_HS_ZERO    = 1,
    parameter T_DATA_HS_TRAIL   = 1,

    parameter T_CLK_LPX         = 1,
    parameter T_CLK_PREPARE     = 1,
    parameter T_CLK_ZERO        = 1,
    parameter T_CLK_PRE         = 1,
    parameter T_CLK_POST        = 1,
    parameter T_CLK_TRAIL       = 1
    )(
    input wire       I_clk,
    input wire       I_rst,
 
    input wire       I_tx_start,
    input wire       I_hs_data_end,

    output wire[3:0] O_lane_state_code,
	output reg       O_tx_end
);
    
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
UTCjjsfjf+bYIBjIG3rAikjCB0+v+PCUhv3/KoQyrd/sD0SYHV95Yda2jaBrzwvc
8yslAzyfDOC/Ln+0LXtDZJ/FN6XLlNUsuP3yLyiq4WTGVLeIMH3UIqxNa/aP3WpT
KIKUKbz5ohA4gKlvSS29NmG1Y0TJXqBjmn6nmikpRxc=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 4448)
`pragma protect data_block
ZHp2U2ZVQk5BdEk4V0M3dS9FGTy7PmgihoA/BKz1k9KdbBi786q44c8NJKX6D+Bj
1ju/DCiO5kcCjnAFTSSej9+Umeav4I3IhYT5rHY00CHUxyKQ49BbhOEPaXt1GiYD
HbZ60g8RQnZ6z3ij2Dgg/QpK3wyj5GbLZB87AhnkxLgseaiffZ1ge1/GHOZQBD5/
maQRzKJgxQ+U459GQ1OXsnCKYOzEPuBq8HUXdLDwNcVzMuPeypqJ56190wa/h+LS
pHL744OY93aNCacKq5jC0p6gMCfMOfo3iLS/4fkqRn5vArSWO3CNYZDocxhzGGnX
+xycpABX/2KGI3Rnz7/lJJ5567Tj3M98DPAvr4VdWbzWvPgEjdSg0xDR5xtyFrh3
Up6v0VuxWKh7jUJS2tn2YRUS0ytM11pYqkeIO9U2QZM4s7MTWD6fbB8xhIpFY/Q0
8bzH1Tc0zzUc+xwnWHishAmpj3msMUhzW07+Cy8lsJuF9J3W34lGfiQ6lOT0TVhW
/IwR1a3EXh/J3Ez+0TmqfPPhJuuPOuQOL2y6X962bygS89n4EzZecGUO+kaUbUTi
lMKyCW+LE1nRTqY42hUvcMPYXqhqOsXPbi391Ea85r82d7ntatN7Jo0Wx5q0vih/
k+J18bVWLp2E7zB7urie29olabLMrYOfVcrpDek80bwH3LU+LnLJYu8v9XLB5nke
1YWKzIVsu1m+kyTP39rk4LL44Pynrt/xetNDs9nNCVa3gwE1xpklTeOP6h39XnXR
AngDC6kRsIuROBb/TR0IuJ++tled/BoyAQsxzN5KRWHZVOOTv8cT1sfLOYoCaHXk
r6Hx1ZxN0eSJfWqsrO/CDKc8xXlePH4rOBI/DhQAwBVQUEF/177dx17np1FtdEr8
xOhlqKT+tZn07ZEUa33ZyGECikRlJ4RSpPIwr+1nCzCAGVKek0XiCejUA15JDFKz
uc+Txf7H7ruyH9bTo+2OnYMUjixEmZUiw+FoxFu6hSy8pLpbGdaeRrcWnzwA8i7x
EKllN8/LlouAj0T4JNAq6wTaFt59GAgTm+jU1btFcgTl55oVGJ3rvv8VeVPsCGht
VFkzO6yoz2PZjWNCJKvul5p4RPN29mDL1ZaC2tjxF9iH1n5Xm94LeOigGpVpXqTS
rctC+dhyY22uA0r8OJt7C0WW+gq7HeSUd5HJKI17dPuew2W1iLRL2TPWLWKTLr2V
ZX8jXuaqtM1kmtQx2RUZrI4K/19UJjo5bBzsW0n/LvN6usTLKA6hxfZJl3DKfUH/
33ZVWDOwywn+D0MwIZMgDMPLPuirD/QYlrAFtpHPDdGKbuPrzzBwLaRVC1tk6b2y
9DUTKSUWW4J2ScsBr+ZcswsfYevh2QzlF6hUK+Chzd4qjs5mNHoeiXRiXR5DX2to
T0Fwvlqrr02lFDItiZYgme55BL52wpVFuBNh+GLjmn6TG8IS0WDxCq5nQ0VdX/dE
xfqivihsNLQvGOZxHfFIfEY5ZSC0U5HJ65EPA9Xfd7cSD+AJ35dQwKTOE5NJImOD
yTc6FEDCRZKuDbyrIsT5J0u9eUATkdYYzQ4Ajek5eUPsTsgWu124kfE2aQ0LKNKa
WctnpLB4w9Ix/n3P/0CqqAHVIz/tlFi0qLDbio53xXCAfIM7DYNdlLSt469mzF8j
/CUvBmA8u00mjjlfxCTz8UL1twtm2MJi+Iq++HGe5PNN5IGsC//XgRrkps/8QbiQ
wTVoljArTN8QyVoxd+VX8DAYzDb0vu7U2tSR0l92MFLAYg4SeqhoVlBHGru29pct
Igz3cQm1RlFLv2XazVZss3lmYISVmSuEcjM6bcYZPPJolw9yD+baijYU7X+Uugba
9yIhZ1Czq/59+SexvnWZaDuyPhgqRZC8qi5RlfzAkd/IAqtqnCrleghw1aEWSGsN
vaSsfkyXeFWopt+jcYsO46gM0XX7Esik09BUFO1wCUmoHoQ4ha3Zng6bMHcVpcoM
06oNBb9vigRIgu/9HeQ9BwTR/lKkDY2W4+F5pvpAmvkZIDQNTmWn5O4moBMQD85X
yydWtVVsK3YbLQNgI6hLnSSc7A2kfD0zfJrFrrgHvnAfJG6u+gkfn9SibEKPVmyd
asav1qhtNK8byER4RyH6GuLGVG2TFBLPVGmjlgykboBzZzIyVBXm6Yy6rS667Lht
9iyWbaYGpTCzm0YxQ/nZaisNVvmuvPyXXuCiB8vYzU7j2d6gFR/3o8hADFY0ej1o
/sD0fHopKEziIPxMnePYyLPSUmFYLgGoHXd7xKrHf8HrqkxwaUjgSu12QnvFwem7
SqQOYTGgCWVzj42IC9umBa/wO06Eh7rryZa7+kAjBBRP1N3p450vyyOoNBrB14zY
Uq0NNh0lkfVC7LuLB0LDvdGp1vshB05otLeBBYOekV6vcJbLqNpd+g4Uut4GYXrp
8cy4BCDlirNY8jC5+ywYNmi1RWwzjXS+QVK76Jb0h7U0u6Y6lbB52rTUEhj6Xlqh
aYJ70xV0pWcpp4g309J4CARsHucOLIRCTwdL5Dr9m2N7oAPDqwgMPS4+GST0Ntam
Cf06GxRzV0oDRbuuFo2FBryR4/VcbguIp38NQ5YXfq8oPlPVv5J+YKaDW6u/mf+3
/9TYPR+BtleL6tWs9TvS66dQ5UjYJPUvPdkygVp4BiNrjD7IWaz0mOIqRXri/qPa
aIQ4LVOlzyFuLKXLn515YajYeJ450QgziBh+oQduboxrQ1/PJwXHsILfuBEoNAmo
9IqUmW9MoRQLo8Biox9GYAVwrHv+vKjF5yu2rO8EWp20XrOJANl6vTsSq9OhVXto
z/TxIfHSdr26pQf5dycslDwUpYFRGt/I6io6PyRWf1dexKrc09oLhwrTeqfIFphB
7x1p21sSDS2AP7RaYnYPHAKvxntKT6qgHOvGowLfJpWYjprhrvezl3Eb7rcoCkJ8
NKeMQLQwH8H/YeY4hbMFzw5PHZifbYCVCAylYGO9/Cz50deFcn2yM0cbsaHyMNte
2ZHu8GCcwUb0fEEnVcckLhHj7i553rJ31R3aNwy1TzKOuENs9hUYXCD+FSVBg4ig
LKvyIfOu1g6rGVIwJz+WQLZP32yvNWoxu19OpcN8q8nZopRIkMJJ2nzwRUau7VFl
MqELhvWd80I+DXyOmCzpwjHho8cquAQV9YdAxLLvGASn3SPMwvo+cESW3udy9uPJ
nH1dzavVbS6NhLWUaZsM63HxMwo78znwDp7zvtQaPQnpuFo/YXXYcvmWwKhTgPsM
eC99PLI7dp/myHUriqxuTbBA/JIe55kUBp6WZ0PHEbPpUCllVX4dIaf/WP/zW0tI
ewzbBfARgcWkBOHJScecpoh1YEFdsMoUeIkD745U3sI6fG9PpqmKKdIXjBdmXwU1
Wy1KkNfAz9V0G9plZ9N6HP/RrpkJXZcUlDAKTaqdqdKqGdSRRMko6W/HEayBtnaJ
+DaHOGi2wxEO0tdJZ6PdCTflOdL3lfgJ+IhFH12Rt2WIbqNPrxy3wScJVYUPtnOt
4ecz0eVKuaRtHCkwhERhdV2hXe/SRBZZrT06ED6sW8RbzGO1PntehX02xxIYJqaP
KEvlxPE6aYmHO2+TE9FJbKVAB9gdL+airSJaIhN7V6ZAZTZxxEHcj+1rDT5xsMen
onyUjdcMbQiB8ztzS5ctj0KBUT7js/kRL6ZDd+q3a1adMdkxdijkodvCN7I0n40Y
cAHvmF8JJabP/ao85dVrhf54zj7r0TNKtBKC8CiZaDb2EGaNrr9mWrfmRBPWuJOg
f1Op8uXjOd8ZrkYAj98M05yDc83C3kUSjzJLjvQ3+2/Ul7XG7+1LMZ+sYAK74lu4
S7p7SX+LXOLYTOb3P0NzloOf50NZq4vUe0e0wv7z70B0f8LY5Ac6osECDjFaGQr1
l5VhAUWG+EXqrs5qn4Jo6XbAmYip8fqT6EjFUI6nHFDT0rKtJTNElTgTdDhqeMKS
Hkm75MpB17gTej46eDuHcuxrYgDu1/AOuZaY2GrcgsMXq6AaEY2hRGepyszrHFA5
Z5/gO21UQ2YyLady9LnmnMB9Kzt/0hJ8orv8zAQ8S2jmQ7wXarxLBj/sT7GiabAe
P9shZe+phW1Pn0BZPqXzyxexI2ZO6Pp9n8iBkOYPINQiscLzdW81r24Cd6SSIn9r
EPIGBraFsEfh2oNXE8LHsiO62xfUd9N/hHboHK/yOhCB2/zKjzI4nmo8529UVenF
QbJt67VrFY/CGrLqWUOLAQjLYz28ML/mVFylLRKbm1LXBIQPh3g6bGALukpZzYWq
TjlWruh3fWKTLB0D9ifLOxlLu9cfaoccC9AdeAQreT4GLmlfPsfWWVYRdi2oGCbP
1p0lANVB8ZcGB2JwyP2p7bsWY2t5nBa0fIlDOq5RH2b/IyplJB4Bbs1MjOocrl3U
FNvFE/bdg+31gFoBNhlboRgP3Zm5UHk3tzxRtSe8ji8+N+80dQ+IihO90JBZVU0C
dKSEQSBjeRKr59V5vpRQl2dSUlc4ZMeoRdeO3jlMeaMQ6wElgTqkyjrCQJJPTpCI
mMUw0sTy2qI6TO7NHYH8NlF0y8PZMi+S1wrrp7FxkhBVSq64Fg7dlv5hQ0IWOKx6
IxDvhojPQ9T9/JxcpwOaKbUKfROYAD6/ZgZqPDd3U5hceeVTfIA5CeWHcI4T9YcA
n1CpyEQZfNGlSDrv4AADh45urQtm2V7EAeZvMwCSMHU4P3Qx85RkuV0q08Y+UQhi
47/hnbNU1LqkOmCL8zQ8e0Bi7nd+AZ8ZRoF6MEJXgrIh9KqH7Ouzn+F7G1Vs3reT
10u1tsyg+FH9CdSla8FUkLPp/5Ky0yRydwE50vL7Ca1ZdKLQpMKgq7sMm8LDo+Ta
spacTBR3FhjAvMBejjyelj5mnTJ6bc1+xZlM1yfuc+tAwsZdcEVFI1l03Vy3qXav
hDUMgElB0OnGU8P07MwZ9wsWQFqSI+wxWZa4g1QG1+uOHYgBT4ElM3a5BhtTTr1x
vxwfYNo2c/LHcf+aSuAZOnU+pvJ0Y06Dh6vAvPVIlHuc57WfAapJzoVAwgN2i2mk
CwDQP2i8Dg/Vu4kMTpIFRG9t42BDGXmwn8r+JSG3wmNk1W4rC7yeYjlXZLVoNS4I
oWxrpI9nQVvNchhmRJdjadC09yk2tVuubirVxxFqUzmcx5SKhRK8p+R+MXnuaFS6
eWaU9urwwRNeEhwyVAskywBjXPtziwo/9DC9M6QTIi9TtXpX5WvzcpiUU7UnbcKT
LRTzwjiUMi71UYJV2gsBtq000u2CpxvXOXUg7UksNIo6W0llcROOcTk+F0XLnrR8
bbg+xSuJDynKO5XVRL5z50lToSf/gOMgHZq3r7IUzOJ633l+SN2261xuZ7MB1IW8
Xz3mNGMLkTqiEjS8jS3mFzUvJRxjY0Q8iUMKrrdZiAunkFNy8OV0q5mviQ0WzBjS
pdKIABeBfPj45UTs97CI6arxjCZDB6lYWhyBil1UIKmVkZwjN9DapctCxj5ezwB6
sDvwPsDrDNg+dP+WYhebjtAdV3Q2k7uRfdMua8ihh/Ri92o6bve8aeae+XKSnBbW
zLukGxjpI+6+IsA6BxX6knmjL/w+glqUeVrn2tcS8rJzohrP38ZRZTuQo+4eL3xf
mnHzW5DlFOnldtnpoifv+ridEyObnpar7FKUVPLNZf2yerXsJxhRTEQlMupgPCgm
F81Fuw1oXGLb7R1f34PXWqh1dJZ+UQHxaisf6c9834I6Yd7qsOYqFlYII9kCbI/X
mP+POfjV5TEQ88tsbG8eMWAsWFabaRmQEgn2WVWTW0lqkKs0i5ERZoQNhr8HjUdE
UOMRBNtvYPjGtSecXG5d46Nlp3alwnUoVqfETuVFj8d5zc70O/J9oGulrd/Z0IgT
09pdsA2lhkbcKuJ9VOFNPhQ+cRzBp3Y4/XcZ+Dn6ouM=
`pragma protect end_protected


endmodule