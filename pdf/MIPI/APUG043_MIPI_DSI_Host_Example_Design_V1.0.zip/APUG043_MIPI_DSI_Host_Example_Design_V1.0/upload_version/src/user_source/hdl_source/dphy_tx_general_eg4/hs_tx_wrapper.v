module hs_tx_wrapper #(
    parameter LANE_NUM          = 4,

	parameter HS_TX_FIFO_TYPE   = "BRAM",

	parameter CLK_LANE_MODE     = "INTERRUPT", ///"CONTINUE","INTERRUPT"

    parameter T_DATA_LPX        = 4,
    parameter T_DATA_HS_PREPARE = 4,
    parameter T_DATA_HS_ZERO    = 10,
    parameter T_DATA_HS_TRAIL   = 10,
    parameter T_CLK_LPX         = 4,
    parameter T_CLK_PREPARE     = 4,
    parameter T_CLK_ZERO        = 10,
    parameter T_CLK_PRE         = 10,
    parameter T_CLK_POST        = 10,
    parameter T_CLK_TRAIL       = 10
    )(
    input wire                 I_clk,
    input wire                 I_clk_x2,
    input wire                 I_clk_x4,
    input wire                 I_clk_x4_90d,
    input wire                 I_rst,
           
    input wire                 I_tx_valid,
    input wire[LANE_NUM*8-1:0] I_tx_data,    ///[31:24] -> lane3  
                                             ///[23:16] -> lane2  
                                             ///[15:8]  -> lane1  
                                             ///[7:0]   -> lane0
    input wire                 I_tx_last,
    output reg                 O_tx_ready,  

    output wire                O_clk_hs_p,
    output wire[LANE_NUM-1:0]  O_data_hs_p,

    output wire                O_clk_lp_p,
    output wire                O_clk_lp_n,
    output wire[LANE_NUM-1:0]  O_data_lp_p,
    output wire[LANE_NUM-1:0]  O_data_lp_n
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
IZTbD71a9GylrnuY6FX+OgA0gMAB6LZCyfknxkShvdEm9g4RHzWx8fgT1KFpePDE
nQHB0nrxfbvpBVvlYYo42vQbRxP+7scHEqP7D7lzmZhg3prPwXLx+JUhEb6VmJjz
b4uV0DLBNgRcwHHJBpa6sJzkT0gjI+s2McbufKBL2G4=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 880)
`pragma protect data_block
dHBBZGZ3MU1DNUpwN21mRsqXnKhpfn2b6pF+BqHl4gSc1lKRx4agvBhNvYDy/180
Y/tHIl/KiK+t9FKdphlE+ElZGC9imI6GDCbDHIE868rnrpjn7FJvzcE2rjMvK0uE
DEdkhcdC+flU7p6gffm9xlsgjRbsiXNx6YaCUIC2Ecn2LnmVAnXW43MVl01eyfLE
LBP3EWjOdNC9OLsXWB3Pc5jH9BGubEVsqkmGvAzWyReDFB1bNavZyEA8nPSQJBdu
+Ma6CfsgUB8j0L1y+WgPxV87v6o3/JsT8q0Z3L44HvTRfxW1NofK4verWgfFWqbr
S2pGrr8fHi8u2stVNgVem2Viju8Ux2iDuNNFadxxmTexusEt/LgDecwGPFjBVdXu
UCe+3/kl9BLDrSHoHDSuJyEDWvZi8MDzD0c3FWPFGgTN6oRwPEqK0rLvRo4x9bZw
3dBAgWSXUXBvIpG6wjqbc8tdGKCKr2auI1FyD6vnM78TLgpL2jyk/Wseau+gssIu
dsU5EqcxQiomBxjrhIMTwrGY2OArO2fLCcDR6cG4ShxQMw2NhG2XYddF5F9tZWxD
/LzPQmzrDm1CHT/k3o+5B2OXL5bzWBRRAtL0uIEszeF4L9Y108zlQv2x/Jfqo/8z
+ogRGKIuKRepf8VPRJKbbGJa4aGIBsgbR+cbSkTdqW2Ia8JdFyNbP9vPk3feolSe
cL/64ey29oE5Z/2BV54ABInWC7kED2Nqh2k5BUO5F8foTGe3gMqd27NOJqRKPJrC
HwJ9RQACd9pUEijpHdsqbTdMIopsM9LxHqdafvc+cFizjVvRWbD4/8QpGNgmmmkC
2vafaUbNqZoYY3xOfnssuMidPKxEB8dGea4XILGdxgfY9q0OoQqMxbt4y6dSGk8O
65/4F4/3mkr76cWNhEa5MU748AuxNdVsm0ey9ITgj2lRhr0NnitNMTh59jaia1GP
zVWorK9j/71MeKKfe8DMCLJ25Vx6wngt+OGGif5Kf+KuVHrXXLQh/taADw0ngI+a
Wyw8bI1Jf882+5xYl2T4WM7ebPBZ9UBOgX4SC7QYHNav+x1ksobC9fYJC8Qs/pfT
wbO53tfdbpFxNWkrYQXNzueBZgsXfRc3TBeC9ah4tVObgGoEc4qUuVlg2cc/ZMrF
tJY0Wf8d7qOAw51D63xVqw==
`pragma protect end_protected


    hs_tx_controler#(
		.CLK_LANE_MODE     ( CLK_LANE_MODE     ),
		
        .T_DATA_LPX        ( T_DATA_LPX        ),
        .T_DATA_HS_PREPARE ( T_DATA_HS_PREPARE ),
        .T_DATA_HS_ZERO    ( T_DATA_HS_ZERO    ),
        .T_DATA_HS_TRAIL   ( T_DATA_HS_TRAIL   ),
        .T_CLK_LPX         ( T_CLK_LPX         ),
        .T_CLK_PREPARE     ( T_CLK_PREPARE     ),
        .T_CLK_ZERO        ( T_CLK_ZERO        ),
        .T_CLK_PRE         ( T_CLK_PRE         ),
        .T_CLK_POST        ( T_CLK_POST        ),
        .T_CLK_TRAIL       ( T_CLK_TRAIL       )
    )u_hs_tx_controler(
        .I_clk             ( I_clk             ),
        .I_rst             ( I_rst             ),

        .I_tx_start        ( S_tx_start        ),
        .I_hs_data_end     ( S_hs_data_end[0]  ),

        .O_lane_state_code ( S_lane_state_code ),
        .O_tx_end          ( S_tx_end          )
    );



    clk_lane_wrapper #(
    	.CLK_LANE_MODE( CLK_LANE_MODE )
	)u_clk_lane_wrapper(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_clk_x4_90d      ( I_clk_x4_90d      ),

        .I_rst             ( I_rst             ),
                                               
        .I_lane_state_code ( S_lane_state_code ),
                                               
        .O_clk_lp_p        ( O_clk_lp_p        ),
        .O_clk_lp_n        ( O_clk_lp_n        ),
                                               
        .O_clk_hs_p        ( O_clk_hs_p        )
    );

    genvar i;
    generate
        for(i = 0; i < LANE_NUM; i = i+1) begin :   MIPI_DATA_LANE_GEN
            data_lane_wrapper #(   
				.FIFO_TYPE  ( HS_TX_FIFO_TYPE ),            
				.DRAM_DEPTH ( DRAM_DEPTH      )     
			)u_data_lane_wrapper(
                .I_clk             ( I_clk                ),
                .I_clk_x2          ( I_clk_x2             ),
                .I_clk_x4          ( I_clk_x4             ),
                .I_rst             ( I_rst                ),

                .I_tx_valid        ( I_tx_valid           ),
                .I_tx_data         ( I_tx_data[8*i+7:8*i] ),
                .I_tx_last         ( I_tx_last            ),

                .I_lane_state_code ( S_lane_state_code    ),

                .O_hs_data_end     ( S_hs_data_end[i]     ),

                .O_data_hs_p       ( O_data_hs_p[i]       ),

                .O_data_lp_p       ( O_data_lp_p[i]       ),
                .O_data_lp_n       ( O_data_lp_n[i]       )
            );
        end
    endgenerate

endmodule