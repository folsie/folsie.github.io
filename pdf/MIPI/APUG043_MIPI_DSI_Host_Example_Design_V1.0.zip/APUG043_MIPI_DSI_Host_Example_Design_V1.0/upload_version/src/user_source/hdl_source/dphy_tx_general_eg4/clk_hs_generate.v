

module clk_hs_generate(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4_90d,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_hs_p
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
STfdCd2NOGytI1lcAen/CWOCevEq1sxftE/CtkIACsF4+L0DQaoCdlKuXvNvN9JX
3pIwjQMk/IDfImp1HMZhvq3XkTRynXK2k95dtFrd/Yy+125E8R8R+eWdJAnPttA7
Ki/qrYUyCy6Rgg/sqIWRbOZwYkO28D32XpRnDtSK9a4=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2448)
`pragma protect data_block
Nk8yanFrQzlvWUxENzRUaHGXKiHW2I/msjdftMfbKOFXXvJCCNjM0RmDz6d1EQfE
ZNl6ZBCjveZJ1F6Nd5sQFiAhdt0y4BVwKMyZm+DaO0BAIrn+96oyNeNL2L7wYdQM
vSUYw+aPp/PtSorjMtWxDtMJso2Dmi9L1J2lLIwEbCeY9mUo7IjTpt9Vp+yuA0QI
qnD2mCS8FgHMviqhm3pmLJbGC42MkZ9xwcT8taFoHb8CNwlbxRUMnhjtB6jtoJnW
HLahlJ4KJ2qZrc3V5uPe/E/WhOUQrU9wTDZuNxf5/B++nTpL9llSNNVHVu89QOQd
aeYXaQ/arQirYw+sBnb88L2K5prNkNRHLPxqh4vEcNsxPQBBqVMP3t2798rnJEU1
uxixxcCxj9t2nHsUbBlGAhq1LL6pNLgLT/kij/xQQcl07FAqWSUmCUq1xXJgJ6ur
gzt+BlMB/FEscWAbPmI3TNbADB0UFwaD8cMa/kldz62AxOZbd0RmupIfbOPwuCTf
E7ec++AZ0WrM69j6p6zvNOEmqhjt9HN81Q28o+AvOTG2+quxLI1FeiyJHM47OxOg
JcO76YwIAiF32Rial6uUr/KSKhxlHQDot8lJn+0V5xbSiBlIZxjD6O2rVklS3dnA
w2vIdfWmkbCcKRs2NbYznxT0OwJd/eWBXY+SDAZrvwYAS/VXfzjSpUwxDls89kk1
C/rcF07sDDMULJYXPeK6XPG2Szzw30QF7L7iQrLJbbEUDoLn3TuFB8d7GavJyu+7
mclX5xuNT6P7y99GhWznyOG5JV+Q8lg+MCO0Iq+HT0OFEwou7hwkxoHrBshDtfIP
7xg+R8tRiuBU+E7ir3MasNQj9HNr3K0JdzPjV/EeYqHnWxR83WvUozmiOpJQXMKw
WPnqUY3wjiwGBU0nEkzbXfb0AdOrjQBF+rJcSwfbc+3hu3BH5jF4OPkCqXgQ2dLu
Vb/3JDg6Zd8yFDuPJNqHOmTIGHe3PIVgYWdur1o/n4WiNoe8MHsstZtk5+IQFQOC
6JqFiBu2xhFbIeG4nTLuLr9A6F/ks29TlWaeJq+aCMv8iav0g2DQEiv66K6IBR3P
Ag9d+qBslLRnJ1AAqz3pH3WVtenPdsmQiBVpSmEV9+Vqy3x8R1VJRgZlOzDB5xEa
bHP8CBmKmdrLN+kCTgBByuPFffauaZ3Ui1GLCgz2kcxSzfP+IeYUJYJfGvlD0f4o
bDQb4fxYYTTEzVICAQkaLn8/lYsakj5NZ/Y0+8lRIgWhlDiuIbM/TTAapcB4kqJ5
6uWqu/WjbgWHwIkh8rqwjKlaUNK+idGTEAKiYDE5Stx9MMehsLsyhVzVdhK758pM
KqM89pYlaD+LTH8LuF9B0naj5/HUtjcmhBM7wQuXbzNfIXZySz7eiymkgIPS8lGj
EPwW7nVa7MAE1vBLLjhgNFDApmawQX+M8jS0chOdnWaOsuGl8dFlHErcHbtJ5Qpg
lUmPG5lUADfpTEsdHc35qg3MxnmTSPo2v22oFhiDrJ27gjpVnzmO8rz83COyd9Vb
6gNMZKc8KNVhdFbtPtgGDyAvX4sCsoBq9ERawELwLeUCrfGW/aH2qFLOE2/9sMTm
Qg1UlMwCyNMttA3oFm0GNVdCPvKmtzmF9QwnOcE7m/JD0o4BBlX3isWlyHFR+tLU
DUpMrusUx4PRhseLgIUstOwW+uJObpbaw4IIRbGll37qmQR3HKulDfUP9VaFWycR
gN6HJv7N3y+AfQXT4WQvQOOG00AwtHgV8jX4oe61YrI7aK0gNiZeo9z3TP/z+2JN
NKD9O5z6gG59Kb5MqPBqUI3lVrVDFl6aiGlAEnCEOIewoY3wTylrZGNrFU3sJnFm
LN16ZfRol7AfgXFTXs0/T0qTVpl0HAdj0VkfcELfiUHoSglxUf13AW+/+xMTMH/H
+1OtDDg70zFCCrkQu5emURh/P/Qr94Xd2D0ERPqhJua8/Er95p1feGIxuD8UOZIt
y1ClLzZFCtw0wwRlbKHMohEMZSETDPx+7ap88AVp13c2cXon/5hXhdJOnK81of9L
N9U/a/ppkITtl3P3+Wz/kNViY6MZO0AZukKph/5psrjIimvpkwWyPVZl8dexdqF4
UuXesd/ksSzUK+VzTmo5JRdB8PWmAkjaJDmEeUl4yTkOmlAU/qdXBwqeKImImH0D
JigrtfURGf1W4xOjRMV4HVtwwYoXGiwM71VOIWK0tORYZ+aMhDAtAn+ezXCv9bdI
1FQrqOgovDOYW7xw7JmoG8cGiPCHxBuTQEzvciDiejnKMJn7JuBi3ouuHpZh8nQg
m8abxFmPUvTaHM127KzCQFLt7740fQcHkpSFLvsPWa9nzictJA4YR3uKkbtcfhrf
QSGLQ0S0IkPlkl/z1z2duInU8pFV3xlbeLvFcvIVQAuYSjP1SAM+hqQ4smEWIYdn
89x381eFCQ/qZJ3VYDQB2jdsA5GBHC++7srCbVHN9SX801M2jI/hajsJMfTS/Dsd
YcxnZ5wwa9oAwR3iqbmLccHm65nCOAZ3wDj+6SG6e8hjWgY6yvWB4w8Zz4P8mSNH
2oEn4HZVRqoYPvc6FqjT8dC+pKGu6WV01KEsfAlSj4cHexiAw6thIEUK161q7TvM
RGefdbi/SDIzTLndfWM1Kg7tLKSOn4sP2+7yn1Kj80FWkJDr1bvf6eLs0Hr9/551
NOR7lz0gfF9cRLwXoeXLv0p7MVoiDk7jupZOX7O9Due3ciJFvoxGo7H611+5lmkK
qdlAGBsWz5TtxB8foVYqocWtxanacLDyp7/OCHmrxlOCRArrOX1OwlHG9tR0NksN
002NqpceBUIm8FhJ/sqAWpDsefQyhM0nBclgZ1SVy2hUKMdVDJ5aadisw7vxsyDK
RpgmBhyabYLDBWifiGunZCpusmVcL4QVc5lavFbVgU1MO4EcsOozgWsIQOXpBCBi
4fovUp1Y72r729W3LdXHA4KtuOGmVtlG57adsvS6jsxF9BCsGE0vtaxTdTchTKnH
sX1H5NvoSl0xlYptNN02kp2X6Brcf9TLhUU7ZdzPu0YEj1IY9dCBKkA60kPlCU6o
lTjKUMgbjqDbNerc+jDOlVCtFzp4wuJ56z3WyJuOSBHhfcxBCkytrXXUhzdPxuZl
lbwiUsZga283Mv7aGopls37jDYOaaszMgtBLtND6mb0Kx9bxDaH+bliwqg2X1J9b
ZfaaxewhvhS4CyTnlxqhxKm392HoouERoazbjvTxDqGWc80O+C3UJiCKSQeLt8lw
`pragma protect end_protected


   EG_LOGIC_ODDRx2l  u_hs_clk(
	   .sclk ( I_clk_x4_90d          ), 
	   .rst  ( 1'b0                  ),
			   
	   .d3   ( S_clk_hs_data_oddr[3] ),
	   .d2   ( S_clk_hs_data_oddr[2] ),
	   .d1   ( S_clk_hs_data_oddr[1] ), 
	   .d0   ( S_clk_hs_data_oddr[0] ),
			   
	   .q    ( S_oddr_clk_p          )
	); 

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
fBOvYdsWJOXnvng7atKlxPsp+FxfaF1N8b164L/KgKfY6y9LDTi7NbDOnSF7AETq
0lPyI+vTNynUemcL7eO25E1PImmNfK6P7kg4+onihP3Si/y2xUd4kdz1XaH7ojUa
u8VD2orZ/8rOmyv30laJNvbz4zszs4uSBpWctbNyfN0=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
YzhvNVcyRmZQNjJuRnM2Vy/Mb3LSckkdW4fct8CNVsXxMoANwh/abuGGsLAiNzEu
Zken2f/hOloNY1Y1Zs84Kjo9vhB938z4U1tSi4il0ONhASkPsX5GV1572mDJq3hD
`pragma protect end_protected


endmodule