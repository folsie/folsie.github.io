module crc16_8b (
   input  wire        clk,
   input  wire        rst,
   input  wire        init,
   input  wire [7:0]  din,
   input  wire        din_en,
   output reg  [15:0] crc
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
ZS4EP3AgaK9ZF/z+W5VxcG8W3heA/KXwUtcLbLncX4aE2RNpvsQ1W6C5IgfmrmxF
+X2dxN8cgcoqdu+DYAQU82218huK4EcbUiJw1f4zAV+anauHFU8LOxjpVlvXIiSN
cxIiXF8SrS6zhDMEgPpnpyqIUvr8fwsTdtxoH6v8eOE=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2096)
`pragma protect data_block
MThlRDJUbzlzQmVSd0xYNlbOwOCb48tV5x+0k5wAFeWhOo5bQtHrWY4XoNHQBUli
wPPcVKME4QfNeOUdwFXAtBAZkWmwVZFDZ6KqURPr0UwY8CmEyFl0stPNPGY36OZj
QloyqIBj/ktVcs0giIDt8sBqmbByLy9+GhDwJQdoll0DKdUWqbnfBAAj9UAWOCfw
oSuMncjA+wJ05+mr2K2cbwp+IPm/MaYR/46piRZZ7jT2OcjTtix2uGUQoT6Lzo1D
KtKpsCoU9AcyQD+MO4nCAPfpkB0ApFpWefuB8nf+0yV3xSxevN3U+ldFActyDyf9
ncR61yxehxlXbIQ0nHcwiMFMTXGBe67C54NbdzcVug3PU3bHDPSwpqQ/hIEWfp2r
yuM3Bk7yVqfZqvVuuGq2Lu2dC+14t0e60YJ/bLbDY6cVRNx4z9Vmk5wgbLWLZdHO
C8FalykN30NyK/So4xTGKCTDb2kN3OAQy/tAPeDnITUg/p4lFJSATh8PDJQc6dHz
/En7hPtS5xdy+Y+EYJOT4LN8g6i+04GdxmtbtfCqUeNSC04+llKjrnR2JktdtJjH
NWEhBwsZCAYDIGKRH0IqKwfhddJBFHqfU7iPrEhDEa+xZjSrF83lkjr8mv+ViSFi
0rZettmCaZTaihVIkx482aTFzR8oziROB0ecGKNkI0wDaQZRZQ2QJym3lcGct6WG
AiMi8VrtqSAoUzNZUG/BVwoEa8WDyMnKUKfwWNaGW4EyeZkRT9XYODPG3QRdUD+t
xNKVXYjOY8qKm7vG/d8X97IUBszwsse3Zi328pbyT4pEJIsAmiNhMOWfxCLpyqRy
wPaG63gvpqekvV5jYSIdWrSjVcxfo8GJI6P5njcaf6QqcMLt+fkZDzNlNVnLreLD
uTkm8xzJ0VUvD5SsHD4/OMV5kY3aXmVcc9X3A8nsnKpMHcCDLK9tVZ+2XTHlBdQf
Ty9fsKm8XMKv9IBCJrbxDLWqBtQSrS5TieiTLXDHS64m+umggOhOI/JRAQDehij0
Vd9YNR55/0oVsLscarKZD0zp+ckhWsYE0aAzL6bpeWsUvYpOshZSi3r9vlMicfVW
8kF7HHvPuQocNBCmd/uSH/qfW1maLRS6tJOQHveZj53CsrbZiv6AAkiugozOD2m+
Lo9MSHobY+mm2w5SrvUf0AyJ79w003JVmuRU7sUwvkoBUXOWffitULy5edJkVzHz
rVO+7SKPETonD2qx4LgBny/GiAl2so/HJ4aEzGW1f/kgugpwCHL0dyOmvl4Nsw3l
tXLWayHQK52xt9tr8aXotGTAnz8bWe1Ri5LBYsXkGvzASU6yAbnwxUlMkE8k9K91
XYA9lkqWu3re5Fzjc5n8aCUxxbYjcd+orBqXOmJICpTP8c5LdOZQolm0i4ArYsF3
IPhR3d7qtRH0m6RxHQO1xhk0PwjT3VrT093ulisEonUrvn+wpgEo/XXKWb8EHqhl
dUqFWvXdUp2ONg4eekJy/F1MlFFlh5jYxgvj5jPAAkGtzMyImnLvzAJOS5YydwR3
SHzjP+ccP4lBYqloXShtmiW/+JOU6NDuC8+w7KRPiPY5GleFRMJxovznSyiFxTWY
cBmaL0D/dQP3TWiji+OjhsfvIbiD0Ru9gMhsZFAIcdfNGEhxJhGUlFQnLxUqdc0M
GpiwVVccaMJec6K4KMSXB6C88hf3BLTaqJB1MhNQDUOQSoeH7IZr0aWfA7wyP3Aq
iWsZ1/Gg79RjXq2hkqWFtjUuKIZe0fPuW4Yltm90XaQG/1D0jWm0zMBP8DoSQd5N
OBDL8h2j4bP3GxrfBJ2mhzcZbhhDrRTewgk4GOuprMmqzStqciZTSY6UaHIB9z4U
FsskjEx+6Y2G9EPbeENtdaxE+rvORZs6bCVIVGmP2thv7HXfQ7+cWFN4EuAzv90a
M/f0LUIZJnuEzDRM+7J1SyBR/KeiDlcH5KjOjbIjpPLdvFn/KDAdE0nzbVWmLzv/
DXYla/uwkstNC8Xb6DZLA775HCtrW2gL6xgeXcIgNWB0g5QPlfZ+M7EFoQLYFJYL
FoRrHhPik5j9g0tJsu1uCDd3zkhiolaSe8uIZxinLNTUGgIdFIfHsswZ3DmgrIBq
JNWuzJEI7kUPHzgTWjpAV7ZJO+8bK6O4I60yprXF4/UJ2xMFS1HLmuTf0L4EWCHx
+h5VqCmg5IDvBl1uujN6b9Lo/PzEVghjJQM7py7UGp1k+10oDO6rBMUxVZpfvmxO
693dt5pKxdBcVZykzcGD90yZgYIyYZlhYz/h9y1WmZOTvhOMOof5KBInBCbxf082
3iRpiFFiFmVeE7ovQ/qy9QeXEhsI3ENbo8zyewW2M6bE3OQfH1LL7xSfV/BerRV4
/bp7lOUIzaY2NxcKNyfiyAo8MkNz6dyWvrrc3U99gNTUIUvoL17B1puLPs9748HH
hCwlWjOU8XEqgoeLO1ue1aMtXt0l+Nonwb2eDgj1JivfmowSDbW/4bM1EapP4/au
DlVT4kTJwHBC8LqDXJD6QwRJCLj27XS+p8oxDQ/Ytl9xycoq4Q7/sVQBT7aB9oBM
O6tY8gatZR6fFBG8jqTMCtHd6lrbM1AU+flzQF/43YQxNMvHZ/sPprDyWTpyhvSE
mPQXUZI1rkJDZhFes3jcOoDGGd3IJav43nd4fU3xPteF7dnykg5onEy/S/PJ59+F
E7fLGTBU9Mtmvc2uDmJzFnAqc4+6Y/dyMkk6WEqGtDdZVmRH0XRCjWwCPNFhlCYN
Bby7tM1vS36s4yD7180GX3Cva+u+PeTooiQwm4wg3/s=
`pragma protect end_protected


endmodule
