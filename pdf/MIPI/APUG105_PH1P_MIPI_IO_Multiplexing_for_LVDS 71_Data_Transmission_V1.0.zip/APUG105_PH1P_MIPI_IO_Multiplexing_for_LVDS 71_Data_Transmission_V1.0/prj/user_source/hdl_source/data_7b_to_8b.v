module data_7b_to_8b(
    input wire       I_rst,
  
    input wire       I_7b_clk,
    input wire       I_7b_valid,
    input wire[6:0]  I_7b_data,
 
    input  wire      I_8b_clk,
    output wire      O_8b_valid,
    output wire[7:0] O_8b_data
);


	reg	[3:0]	S_fifo_wr_cnt;
    reg [3:0]	S_fifo_wr_cnt_1d;
    wire		S_fifo_wr_en;
    reg			S_fifo_wr_en_1d;
    reg [6:0]	S_7b_data_1d;
    wire[7:0]	S_fifo_wr_data;
    reg [7:0]	S_fifo_wr_data_1d;
    wire[8:0] 	S_fifo_rdpointer; 		
    reg			S_fifo_rd_en;
    reg	[3:0]	S_fifo_rd_en_cnt;
    


	always @(posedge I_7b_clk) begin
        if(I_7b_valid)
            begin
                if(S_fifo_wr_cnt == 'd7)
                    S_fifo_wr_cnt <= 'd0;
                else    
                    S_fifo_wr_cnt <= S_fifo_wr_cnt + 'd1;
            end
        else
            S_fifo_wr_cnt <= 'd0;
    end


    assign S_fifo_wr_en = I_7b_valid && S_fifo_wr_cnt < 'd7 ? 1'b1 : 1'b0;


    always @(posedge I_7b_clk) begin
        S_7b_data_1d  <= I_7b_data;

        S_fifo_wr_cnt_1d <= S_fifo_wr_cnt;
        S_fifo_wr_en_1d  <= S_fifo_wr_en;
    end


    assign S_fifo_wr_data = S_fifo_wr_en_1d && S_fifo_wr_cnt_1d == 'd0 ? {S_7b_data_1d     ,I_7b_data[6]  } : 
                            S_fifo_wr_en_1d && S_fifo_wr_cnt_1d == 'd1 ? {S_7b_data_1d[5:0],I_7b_data[6:5]} :
                            S_fifo_wr_en_1d && S_fifo_wr_cnt_1d == 'd2 ? {S_7b_data_1d[4:0],I_7b_data[6:4]} : 
                            S_fifo_wr_en_1d && S_fifo_wr_cnt_1d == 'd3 ? {S_7b_data_1d[3:0],I_7b_data[6:3]} : 
                            S_fifo_wr_en_1d && S_fifo_wr_cnt_1d == 'd4 ? {S_7b_data_1d[2:0],I_7b_data[6:2]} : 
                            S_fifo_wr_en_1d && S_fifo_wr_cnt_1d == 'd5 ? {S_7b_data_1d[1:0],I_7b_data[6:1]} : 
                            S_fifo_wr_en_1d && S_fifo_wr_cnt_1d == 'd6 ? {S_7b_data_1d[0]  ,I_7b_data}      : 'd0;
                            
                 
	always@(posedge I_7b_clk)begin
    	S_fifo_wr_data_1d <= S_fifo_wr_data;
    end    
    
    
    w8_d512_fifo u_w8_d512_fifo(
        .rst        ( I_rst             ),

        .clkw       ( I_7b_clk          ),
        .we         ( S_fifo_wr_en_1d   ),
        .di         ( S_fifo_wr_data    ),
        .full_flag  (                   ),
        .afull      (                   ),
        .wrusedw    (                   ),

        .clkr       ( I_8b_clk          ),
        .re         ( S_fifo_rd_en      ),
        .dout       ( O_8b_data	    	),
        .valid      ( O_8b_valid        ),
        .empty_flag ( S_fifo_empty_flag ),
        .aempty     (                   ),
        .rdusedw    ( S_fifo_rdpointer  )
    );

    
    always@(posedge I_8b_clk or posedge I_rst)begin
        if(I_rst)
            S_fifo_rd_en <= 1'b0;
        else
            begin
                if(S_fifo_rdpointer >= 'd256)
                    S_fifo_rd_en <= 1'b1;
                else if(S_fifo_rdpointer == 'd0)
                    S_fifo_rd_en <= 1'b0;
                else
                    S_fifo_rd_en <= S_fifo_rd_en;
            end
        	
    end
    

endmodule
