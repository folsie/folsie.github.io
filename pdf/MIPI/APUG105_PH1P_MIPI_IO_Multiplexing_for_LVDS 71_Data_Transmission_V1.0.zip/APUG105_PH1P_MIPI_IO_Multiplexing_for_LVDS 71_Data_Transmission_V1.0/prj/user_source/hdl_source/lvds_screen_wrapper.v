module lvds_screen_wrapper #(
    parameter	PROTOCOL = "VESA" //协议 "VESA"/"JEIDA"
)(
    input wire      I_pixel_clk,
    input wire      I_dpll_ref_clk,
    input wire      I_rst_n,

    input wire      I_vs,
    input wire      I_hs,
    input wire      I_de,
    
    input wire[23:0]I_rgb_data,
    
    output wire		O_8b_clk,
    
    inout wire      IO_tx_clk_pad_n, 
    inout wire      IO_tx_clk_pad_p, 
    inout wire[3:0] IO_tx_data_pad_n,
    inout wire[3:0] IO_tx_data_pad_p
);

    wire[6:0] S_tx_data_lane_0;  
    wire[6:0] S_tx_data_lane_1;  
    wire[6:0] S_tx_data_lane_2;  
    wire[6:0] S_tx_data_lane_3;  
    wire[6:0] S_tx_data_lane_clk;

	wire	  S_8b_clk_lane_valid;
    wire[7:0] S_8b_clk_lane_data;    
    wire	  S_8b_lane0_valid;
    wire[7:0] S_8b_lane0_data;
    wire	  S_8b_lane1_valid;
    wire[7:0] S_8b_lane1_data;
    wire	  S_8b_lane2_valid;
    wire[7:0] S_8b_lane2_data;
    wire	  S_8b_lane3_valid;
    wire[7:0] S_8b_lane3_data; 
    
    wire[7:0] S_8b_clk_lane_data_inv;
    wire[7:0] S_8b_lane0_data_inv;			
    wire[7:0] S_8b_lane1_data_inv;			
    wire[7:0] S_8b_lane2_data_inv;			
    wire[7:0] S_8b_lane3_data_inv;			
    
    wire	  S_lvds_tx_8b_clk_out;
    wire	  S_lvds_tx_8b_clk;
    reg		  S_dphy_dpll_locked;   
    wire	  S_dphy_dpll_locked_out; 
    wire	  S_lvds_tx_pll_clk_out; 
    wire	  S_tx_rst;      


    rgb_to_lvds_packet #(
        .PROTOCOL			(	PROTOCOL		 )
    )u_rgb_to_lvds_packet(
        .I_clk              ( I_pixel_clk        ),  
    
        .I_video_vsync      ( I_vs      		 ),
        .I_video_hsync      ( I_hs		         ),
        .I_video_de         ( I_de         		 ),
        .I_video_r_data     ( I_rgb_data[23:16]  ),
        .I_video_g_data     ( I_rgb_data[15:8]   ),
        .I_video_b_data     ( I_rgb_data[7:0]    ),
            
        .O_tx_data_lane_0   ( S_tx_data_lane_0   ),
        .O_tx_data_lane_1   ( S_tx_data_lane_1   ),
        .O_tx_data_lane_2   ( S_tx_data_lane_2   ),
        .O_tx_data_lane_3   ( S_tx_data_lane_3   ),
        .O_tx_data_lane_clk ( S_tx_data_lane_clk )
    );
    
    
    data_conversion_wrapper u_data_conversion_wrapper(
    	.I_7b_clk				(	I_pixel_clk			),
    	.I_8b_clk				(	S_lvds_tx_8b_clk	),
    	.I_rst					(	S_tx_rst			),
    	                		 	
    	.I_lane0_data			(	S_tx_data_lane_0	),
    	.I_lane1_data			(	S_tx_data_lane_1	),
    	.I_lane2_data			(	S_tx_data_lane_2	),
    	.I_lane3_data			(	S_tx_data_lane_3	),
    	.I_lane_clk				(	S_tx_data_lane_clk	),
        
        
    	.O_8b_clk_lane_valid	(	S_8b_clk_lane_valid	),
    	.O_8b_clk_lane_data		(	S_8b_clk_lane_data	),    	                     	
    	.O_8b_lane0_valid		(	S_8b_lane0_valid	),
    	.O_8b_lane0_data		(	S_8b_lane0_data		),
    	.O_8b_lane1_valid		(	S_8b_lane1_valid	),
    	.O_8b_lane1_data		(	S_8b_lane1_data		),
    	.O_8b_lane2_valid		(	S_8b_lane2_valid	),
    	.O_8b_lane2_data		(	S_8b_lane2_data		),
    	.O_8b_lane3_valid		(	S_8b_lane3_valid	),
    	.O_8b_lane3_data		(	S_8b_lane3_data		)
	);
    
    
    assign	S_8b_clk_lane_data_inv = {S_8b_clk_lane_data[0], S_8b_clk_lane_data[1], S_8b_clk_lane_data[2], S_8b_clk_lane_data[3],
    								  S_8b_clk_lane_data[4], S_8b_clk_lane_data[5], S_8b_clk_lane_data[6], S_8b_clk_lane_data[7]};
                                      
                         
    assign	S_8b_lane0_data_inv = {S_8b_lane0_data[0], S_8b_lane0_data[1], S_8b_lane0_data[2], S_8b_lane0_data[3],
    							   S_8b_lane0_data[4], S_8b_lane0_data[5], S_8b_lane0_data[6], S_8b_lane0_data[7]};
                                   
    assign	S_8b_lane1_data_inv = {S_8b_lane1_data[0], S_8b_lane1_data[1], S_8b_lane1_data[2], S_8b_lane1_data[3],
    							   S_8b_lane1_data[4], S_8b_lane1_data[5], S_8b_lane1_data[6], S_8b_lane1_data[7]};
                                   
    assign	S_8b_lane2_data_inv = {S_8b_lane2_data[0], S_8b_lane2_data[1], S_8b_lane2_data[2], S_8b_lane2_data[3],
    							   S_8b_lane2_data[4], S_8b_lane2_data[5], S_8b_lane2_data[6], S_8b_lane2_data[7]};  
                                   
    assign	S_8b_lane3_data_inv = {S_8b_lane3_data[0], S_8b_lane3_data[1], S_8b_lane3_data[2], S_8b_lane3_data[3],
    							   S_8b_lane3_data[4], S_8b_lane3_data[5], S_8b_lane3_data[6], S_8b_lane3_data[7]};                                                                                                       
                                      	
    
    always@(posedge I_pixel_clk or negedge I_rst_n)begin
    	if(!I_rst_n)
        	S_dphy_dpll_locked <= 1'b0;
        else
            if(S_dphy_dpll_locked_out)
                S_dphy_dpll_locked <= 1'b1;
            else
                S_dphy_dpll_locked <= S_dphy_dpll_locked;
    end
    
    
    assign	S_tx_rst = ~S_dphy_dpll_locked;
    
    
    PH1P_LOGIC_DPHY_LVDS_TX #(             
        .DPHY_TX_LOCATION          ( "DPHY0"           			), //"DPHY0", "DPHY1"
                                                       			   
        .P2S_RATIO                 ( "8:1"			   			), //"8:1","16:1"
        .LVDS_OUTPUT_VCM           ( "0.7v"            			), //"0.7v","0.75v","0.8v","0.9v","1v","1.1v","1.2v","1.3v"
        .LVDS_EXTRA_VOD_GAIN       ( "DISABLE"         			), //"EANBLE","DISABLE"
        .LVDS_OVER_CURRENT_PROTECT ( "DISABLE"         			), // "ENABLE","DISABLE"
                                                       			   
        .CK_DE_EMPHASIS            ( "0dB"             			), //"0dB","-1.5dB"
        .CK_LVDS_OUTPUT_VOD        ( "3.5mA"           			), //"2.5mA","3mA","3.5mA","4mA","4.5mA","5mA","5.5mA","6mA"
                                                       			   
        .L0_DE_EMPHASIS            ( "0dB"             			), //"0dB","-1.5dB"
        .L0_LVDS_OUTPUT_VOD        ( "3.5mA"           			), //"2.5mA","3mA","3.5mA","4mA","4.5mA","5mA","5.5mA","6mA"
                                                       			   
        .L1_DE_EMPHASIS            ( "0dB"             			), //"0dB","-1.5dB"
        .L1_LVDS_OUTPUT_VOD        ( "3.5mA"           			), //"2.5mA","3mA","3.5mA","4mA","4.5mA","5mA","5.5mA","6mA"
                                                       			   
        .L2_DE_EMPHASIS            ( "0dB"             			), //"0dB","-1.5dB"
        .L2_LVDS_OUTPUT_VOD        ( "3.5mA"           			), //"2.5mA","3mA","3.5mA","4mA","4.5mA","5mA","5.5mA","6mA"
                                                       			   
        .L3_DE_EMPHASIS            ( "0dB"             			), //"0dB","-1.5dB"
        .L3_LVDS_OUTPUT_VOD        ( "3.5mA"           			)  //"2.5mA","3mA","3.5mA","4mA","4.5mA","5mA","5.5mA","6mA"
    )u_PH1P_LOGIC_DPHY_LVDS_TX(                             	
        .io_clk_pad_n              ( IO_tx_clk_pad_n        	),
        .io_clk_pad_p              ( IO_tx_clk_pad_p        	),
        .io_data_pad_n             ( IO_tx_data_pad_n       	),
        .io_data_pad_p             ( IO_tx_data_pad_p       	),
                                                            	
        .i_phy_dpll_ref_clk        ( I_dpll_ref_clk         	), 
        .o_fabric_div5_10_clk      ( S_lvds_tx_pll_clk_out  	), 
        .o_fabric_div4_8_clk       ( S_lvds_tx_8b_clk_out      	), 
                                                            	
        .i_phy_dpll_rst_n          ( I_rst_n                    ), 
        .i_phy_dpll_pwdn_n         ( 1'b1                   	),
        .i_phy_dpll_vco_bypass_n   ( 1'b1                   	),
        .o_phy_dpll_locked         ( S_dphy_dpll_locked_out 	),
        .i_phy_dpll_multi_ratio    ( 7'd7	                  	),
        .i_phy_dpll_div_ratio      ( 6'd1                   	),
                                                            	
        .i_phy_rst_n               ( S_dphy_dpll_locked_out     ),
                                                            	
        .i_ck_tx_en                ( 1'b1				        ),
        .i_ck_odelay_value         ( 4'd0                   	),
        .i_ck_tx_data              ( S_8b_clk_lane_data_inv     ),
                                                            	
        .i_l0_tx_en                ( 1'b1			            ),
        .i_l0_odelay_value         ( 4'd0                   	),
        .i_l0_tx_data              ( S_8b_lane0_data_inv		),	
 
        .i_l1_tx_en                ( 1'b1			            ),
        .i_l1_odelay_value         ( 4'd0                   	),
        .i_l1_tx_data              ( S_8b_lane1_data_inv		),	
                                   
        .i_l2_tx_en                ( 1'b1			            ),
        .i_l2_odelay_value         ( 4'd0                   	),
        .i_l2_tx_data              ( S_8b_lane2_data_inv		),	
                                   
        .i_l3_tx_en                ( 1'b1			            ),
        .i_l3_odelay_value         ( 4'd0                   	),
        .i_l3_tx_data              ( S_8b_lane3_data_inv		)	
    );

	
    PH1P_LOGIC_BUFG U1_PH1P_LOGIC_BUFG (
 		.i( S_lvds_tx_8b_clk_out ), 
 		.o( S_lvds_tx_8b_clk     ) 
 	);
    
    assign	O_8b_clk = S_lvds_tx_8b_clk;

    
endmodule