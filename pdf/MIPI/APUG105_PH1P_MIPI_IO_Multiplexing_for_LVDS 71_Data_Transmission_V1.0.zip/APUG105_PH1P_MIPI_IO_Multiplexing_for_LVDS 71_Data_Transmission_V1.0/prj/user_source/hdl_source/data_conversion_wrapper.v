module data_conversion_wrapper(
    input	wire		I_7b_clk,
    input	wire		I_8b_clk,
    input	wire		I_rst,

    input	wire[6:0]	I_lane_clk,    
    input	wire[6:0]	I_lane0_data,
    input	wire[6:0]	I_lane1_data,
    input	wire[6:0]	I_lane2_data,
    input	wire[6:0]	I_lane3_data,
    
    output	wire		O_8b_clk_lane_valid,
    output	wire[7:0]	O_8b_clk_lane_data,
    output	wire		O_8b_lane0_valid,
    output	wire[7:0]	O_8b_lane0_data,
    output	wire		O_8b_lane1_valid,
    output	wire[7:0]	O_8b_lane1_data,
    output	wire		O_8b_lane2_valid,
    output	wire[7:0]	O_8b_lane2_data,
    output	wire		O_8b_lane3_valid,
    output	wire[7:0]	O_8b_lane3_data
);

	
    wire S_7b_valid;
    
    assign S_7b_valid = ~ I_rst;
    
    
    data_7b_to_8b u_clk_7b_to_8b(
    	.I_rst		(	I_rst				),
    	             	            		
    	.I_7b_clk	(	I_7b_clk			),
    	.I_7b_valid	(	S_7b_valid			),
    	.I_7b_data	(	I_lane_clk			),
    	             	                	
    	.I_8b_clk	(	I_8b_clk			),
    	.O_8b_valid	(	O_8b_clk_lane_valid	),
    	.O_8b_data	(	O_8b_clk_lane_data	)
	);
    
	

	data_7b_to_8b u_lane0_7b_to_8b(
    	.I_rst		(	I_rst				),
    	             	            		
    	.I_7b_clk	(	I_7b_clk			),
    	.I_7b_valid	(	S_7b_valid			),
    	.I_7b_data	(	I_lane0_data		),
    	             	                	
    	.I_8b_clk	(	I_8b_clk			),
    	.O_8b_valid	(	O_8b_lane0_valid	),
    	.O_8b_data	(	O_8b_lane0_data		)
	);
    
    
    data_7b_to_8b u_lane1_7b_to_8b(
    	.I_rst		(	I_rst				),
    	             	            		
    	.I_7b_clk	(	I_7b_clk			),
    	.I_7b_valid	(	S_7b_valid			),
    	.I_7b_data	(	I_lane1_data		),
    	             	                	
    	.I_8b_clk	(	I_8b_clk			),
    	.O_8b_valid	(	O_8b_lane1_valid	),
    	.O_8b_data	(	O_8b_lane1_data		)
	);
    
    
    data_7b_to_8b u_lane2_7b_to_8b(
    	.I_rst		(	I_rst				),
    	             	            		
    	.I_7b_clk	(	I_7b_clk			),
    	.I_7b_valid	(	S_7b_valid			),
    	.I_7b_data	(	I_lane2_data		),
    	             	                	
    	.I_8b_clk	(	I_8b_clk			),
    	.O_8b_valid	(	O_8b_lane2_valid	),
    	.O_8b_data	(	O_8b_lane2_data		)
	);
    
    
    data_7b_to_8b u_lane3_7b_to_8b(
    	.I_rst		(	I_rst				),
    	             	            		
    	.I_7b_clk	(	I_7b_clk			),
    	.I_7b_valid	(	S_7b_valid			),
    	.I_7b_data	(	I_lane3_data		),
    	             	                	
    	.I_8b_clk	(	I_8b_clk			),
    	.O_8b_valid	(	O_8b_lane3_valid	),
    	.O_8b_data	(	O_8b_lane3_data		)
	);



endmodule
