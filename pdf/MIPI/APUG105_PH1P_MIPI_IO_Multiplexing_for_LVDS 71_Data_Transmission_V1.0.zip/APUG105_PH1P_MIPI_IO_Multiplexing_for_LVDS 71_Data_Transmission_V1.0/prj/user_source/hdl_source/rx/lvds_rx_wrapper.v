module lvds_rx_wrapper#(
    parameter PROTOCOL = "VESA"
)(
	input wire		I_pixel_clk,
    input wire		I_sample_clk,
    input wire		I_rst_n,

    inout wire      IO_rx_clk_pad_n, 
    inout wire      IO_rx_clk_pad_p, 
    inout wire[3:0] IO_rx_data_pad_n,
    inout wire[3:0] IO_rx_data_pad_p,
    
    output wire		O_phy_to_pll_ref_clk,
    
    output	wire		O_de,
    output	wire		O_hs,
    output	wire		O_vs,
    output	wire[23:0]	O_rgb_data
);


 
    wire	   S_sample_clk_mlclk;

    wire       S_dphy1_rx_clk_out;
    wire[15:0] S_dphy1_l0_data_out;   
    wire[15:0] S_dphy1_l1_data_out;   
    wire[15:0] S_dphy1_l2_data_out;   
    wire[15:0] S_dphy1_l3_data_out;   
 
  
    reg[7:0]   S_dphy1_l0_data;  
    reg[7:0]   S_dphy1_l1_data;  
    reg[7:0]   S_dphy1_l2_data;  
    reg[7:0]   S_dphy1_l3_data; 


    PH1P_PHY_MLCLK #(
	  .GSR          ( "DISABLE"   			), //  "ENABLE", "DISABLE".        
	  .BYPASS       ( "DISABLE"   			)  //  "ENABLE", "DISABLE".        
	)u_PH1P_PHY_TX_MLCLK(           		
	  .ce           ( 1'b1         			),                                
	  .clkin        ( I_sample_clk	    	),                                
	  .clkout       ( S_sample_clk_mlclk  	)                                  
	); 
    

    PH1P_LOGIC_DPHY_LVDS_RX #(
        .DPHY_RX_LOCATION              ( "DPHY1"           ),//"DPHY0", "DPHY1"
                      
        .S2P_RATIO                     ( "1:8"             ),//"1:8","1:16"
        .SAMPLE_CLOCK_SEL              ( "PLL"             ),//"CLK_LANE","PLL"
                     
        .CK_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .CK_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .CK_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .CK_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .CK_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .CK_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .CK_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .CK_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"
        
        .L0_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L0_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L0_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L0_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L0_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L0_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L0_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L0_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L0_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"

        .L1_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L1_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L1_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L1_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L1_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L1_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L1_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L1_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L1_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"

        .L2_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L2_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L2_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L2_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L2_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L2_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L2_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L2_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L2_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"

        .L3_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L3_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L3_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L3_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L3_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L3_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L3_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L3_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L3_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ) //"ENABLE","DISABLE"
    )u1_PH1P_LOGIC_DPHY_LVDS_RX(
        .io_clk_pad_n            ( IO_rx_clk_pad_n     	 ),
        .io_clk_pad_p            ( IO_rx_clk_pad_p     	 ),
        .io_data_pad_n           ( IO_rx_data_pad_n    	 ),
        .io_data_pad_p           ( IO_rx_data_pad_p    	 ),

        .i_pll_to_phy_sample_clk ( S_sample_clk_mlclk    ),
        .o_phy_to_pll_ref_clk    ( O_phy_to_pll_ref_clk  ),     
        .o_fabric_div5_10_clk    (                       ),     
        .o_fabric_div4_8_clk     ( S_dphy1_rx_clk_out    ),
        .i_phy_rst_n             ( 1'b1                  ),
             
        .i_ck_rx_en              ( 1'b1                  ),
        .i_ck_idelay_value       ( 6'd0                  ),
    
        .i_l0_rx_en              ( 1'b1                  ),
        .i_l0_slave_deser_clk_en ( 1'b0                  ),
        .i_l0_idelay_value       ( 6'd0                  ),
        .o_l0_rx_data            ( S_dphy1_l0_data_out   ),
        .o_l0_rx_slave_data      (                       ),

        .i_l1_rx_en              ( 1'b1                  ),
        .i_l1_slave_deser_clk_en ( 1'b0                  ),
        .i_l1_idelay_value       ( 6'd0                  ),
        .o_l1_rx_data            ( S_dphy1_l1_data_out   ),
        .o_l1_rx_slave_data      (                       ),

        .i_l2_rx_en              ( 1'b1                  ),
        .i_l2_slave_deser_clk_en ( 1'b0                  ),
        .i_l2_idelay_value       ( 6'd0                  ),
        .o_l2_rx_data            ( S_dphy1_l2_data_out   ),
        .o_l2_rx_slave_data      (                       ),

        .i_l3_rx_en              ( 1'b1                  ),
        .i_l3_slave_deser_clk_en ( 1'b0                  ),
        .i_l3_idelay_value       ( 6'd0                  ),
        .o_l3_rx_data            ( S_dphy1_l3_data_out   ),
        .o_l3_rx_slave_data      (                       )
    );


	PH1P_LOGIC_BUFG U1_PH1P_LOGIC_BUFG (
 		.i( S_dphy1_rx_clk_out ), 
 		.o( S_dphy1_rx_clk     ) 
 	); 



    always @(posedge S_dphy1_rx_clk) begin
        S_dphy1_l0_data <= S_dphy1_l0_data_out;
        S_dphy1_l1_data <= S_dphy1_l1_data_out;
        S_dphy1_l2_data <= S_dphy1_l2_data_out;
        S_dphy1_l3_data <= S_dphy1_l3_data_out;
    end


	channel_wrapper #(    
	    .PROTOCOL 			(	"VESA"				)    
	)u_channel_wrapper1(
	    .I_pixel_clk		(	I_pixel_clk			),
	    .I_dphy_rx_clk		(	S_dphy1_rx_clk		),
        .I_rst				(	~I_rst_n			),
	                         	
	    .I_dphy_l0_data		(	S_dphy1_l0_data		),
	    .I_dphy_l1_data		(	S_dphy1_l1_data		),
	    .I_dphy_l2_data		(	S_dphy1_l2_data		),
	    .I_dphy_l3_data		(	S_dphy1_l3_data		),
        
        .O_DE				(	O_de	   			),
    	.O_HS				(	O_hs	   			),
    	.O_VS				(	O_vs	   			),
    	.O_RGB_data			(	O_rgb_data			)
	);


endmodule
