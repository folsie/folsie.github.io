module lcd_hs_dect(    
	input	wire		I_clk,
    input	wire		I_rst,
    
    input	wire		I_shifter_DE,
    input	wire		I_shifter_HS,
    input	wire		I_shifter_VS,
    
    output	reg 		O_shifter_right_dect
);


    reg	[11:0]	S_valid_col;	
    reg	[11:0]	S_col;			
    reg [11:0]	S_line;			
    reg [11:0]	S_valid_line;
    reg			S_HS_d;
    wire		S_HS_n_edge;	
    reg			S_shifter_de_d; 
    wire		S_shifter_de_n_edge;
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_valid_col <= 'd0;
        else if(I_shifter_DE)
        	S_valid_col <= S_valid_col + 1'b1;
        else
        	S_valid_col <= 'd0;
    end
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_col <= 'd0;
        else if(~I_shifter_HS)
        	S_col <= S_col + 1'b1;
        else
        	S_col <= 'd0;
    end
     
    
    always@(posedge I_clk)begin
        	S_HS_d <= I_shifter_HS;
            S_shifter_de_d <= I_shifter_DE;
    end
    
    
    assign	S_HS_n_edge = ~I_shifter_HS && S_HS_d;
    
    
    assign	S_shifter_de_n_edge = ~I_shifter_DE && S_shifter_de_d;
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_line <= 'd0;
        else if(I_shifter_VS)
        	if(S_shifter_de_n_edge)						
        		S_line <= S_line + 1'b1;
            else
            	S_line <= S_line;
        else
        	S_line <= 'd0;
    end

    
endmodule