module rx_8b_7b_conversion_wrapper(
    input	wire		I_7b_clk,
    input	wire		I_8b_clk,
    input	wire		I_rst,

	input	wire		I_rx_valid,  
    input	wire[7:0]	I_rx_lane0_data,
    input	wire[7:0]	I_rx_lane1_data,
    input	wire[7:0]	I_rx_lane2_data,
    input	wire[7:0]	I_rx_lane3_data,
    
    output	wire		O_7b_lane0_valid,
    output	wire[6:0]	O_7b_lane0_data,
    output	wire		O_7b_lane1_valid,
    output	wire[6:0]	O_7b_lane1_data,
    output	wire		O_7b_lane2_valid,
    output	wire[6:0]	O_7b_lane2_data,
    output	wire		O_7b_lane3_valid,
    output	wire[6:0]	O_7b_lane3_data
);

    
    
   	data_8b_to_7b u_lane0_8b_to_7b(
		.I_rst		(	I_rst				),
		             	            		
		.I_8b_clk	(	I_8b_clk			),
		.I_8b_valid	(	I_rx_valid			),
		.I_8b_data	(	I_rx_lane0_data		),
		             	                	
		.I_7b_clk	(	I_7b_clk			),
		.O_7b_valid	(	O_7b_lane0_valid	),
		.O_7b_data	(	O_7b_lane0_data		)
	);
    
    
   data_8b_to_7b u_lane1_8b_to_7b(
		.I_rst		(	I_rst				),
		             	            		
		.I_8b_clk	(	I_8b_clk			),
		.I_8b_valid	(	I_rx_valid			),
		.I_8b_data	(	I_rx_lane1_data		),
		             	                	
		.I_7b_clk	(	I_7b_clk			),
		.O_7b_valid	(	O_7b_lane1_valid	),
		.O_7b_data	(	O_7b_lane1_data		)
	);
    
    
   data_8b_to_7b u_lane2_8b_to_7b(
		.I_rst		(	I_rst				),
		             	            		
		.I_8b_clk	(	I_8b_clk			),
		.I_8b_valid	(	I_rx_valid			),
		.I_8b_data	(	I_rx_lane2_data		),
		             	                	
		.I_7b_clk	(	I_7b_clk			),
		.O_7b_valid	(	O_7b_lane2_valid	),
		.O_7b_data	(	O_7b_lane2_data		)
	);
    
    
   data_8b_to_7b u_lane3_8b_to_7b(
		.I_rst		(	I_rst				),
		             	            		
		.I_8b_clk	(	I_8b_clk			),
		.I_8b_valid	(	I_rx_valid			),
		.I_8b_data	(	I_rx_lane3_data		),
		             	
		.I_7b_clk	(	I_7b_clk			),
		.O_7b_valid	(	O_7b_lane3_valid	),
		.O_7b_data	(	O_7b_lane3_data		)
	);    
    

endmodule
