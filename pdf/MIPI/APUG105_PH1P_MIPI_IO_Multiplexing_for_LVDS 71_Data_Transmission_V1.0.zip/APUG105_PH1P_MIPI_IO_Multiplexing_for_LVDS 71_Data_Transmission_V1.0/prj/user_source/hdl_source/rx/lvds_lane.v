module lvds_lane(

    input	wire		I_clk_1x,   
    input	wire		I_rst,  
    
    input	wire[6:0]	I_lvds_rx_lane_data,
    
    output	wire[6:0]	O_shifter_bit0_data,
    output	wire[6:0]	O_shifter_bit1_data,
    output	wire[6:0]	O_shifter_bit2_data,
    output	wire[6:0]	O_shifter_bit3_data, 
    output	wire[6:0]	O_shifter_bit4_data,
    output	wire[6:0]	O_shifter_bit5_data,        
    output	wire[6:0]	O_shifter_bit6_data    
);
	
	wire	[6:0]	S_diff_pdata;				
    wire    [6:0]	S_diff_ndata; 								 				
    wire	[6:0]	S_diff_pdata_inv;      
    
    
	lvds_shifter_wrapper u_lvds_shifter_wrapper( 
		.I_clk				(	I_clk_1x				),
	    .I_rst				(	I_rst					),
	                                            		
	    .I_deserial_data	(	I_lvds_rx_lane_data		),
	    
	    .O_shifter0_data	(	O_shifter_bit0_data		),
	    .O_shifter1_data	(	O_shifter_bit1_data		),
	    .O_shifter2_data	(	O_shifter_bit2_data		),
	    .O_shifter3_data	(	O_shifter_bit3_data		),
	    .O_shifter4_data	(	O_shifter_bit4_data		),
	    .O_shifter5_data	(	O_shifter_bit5_data		),
	    .O_shifter6_data	(	O_shifter_bit6_data		)
	); 


endmodule
