
module lane_choose(
    input	wire		I_clk,
    input	wire		I_rst,
                    	
    input	wire		I_shifter0_right_dect,
	input	wire		I_shifter1_right_dect,
	input	wire		I_shifter2_right_dect,
	input	wire		I_shifter3_right_dect,
	input	wire		I_shifter4_right_dect,
	input	wire		I_shifter5_right_dect,
	input	wire		I_shifter6_right_dect,
    
    input	wire		I_shifter0_DE,
    input	wire		I_shifter0_HS,
    input	wire		I_shifter0_VS,
    input	wire[23:0]	I_shifter0_RGB_data,
    
    input	wire		I_shifter1_DE,
    input	wire		I_shifter1_HS,
    input	wire		I_shifter1_VS,
    input	wire[23:0]	I_shifter1_RGB_data,
    
    input	wire		I_shifter2_DE,
    input	wire		I_shifter2_HS,
    input	wire		I_shifter2_VS,
    input	wire[23:0]	I_shifter2_RGB_data,    
    
    input	wire		I_shifter3_DE,
    input	wire		I_shifter3_HS,
    input	wire		I_shifter3_VS,
    input	wire[23:0]	I_shifter3_RGB_data,    
    
    input	wire		I_shifter4_DE,
    input	wire		I_shifter4_HS,
    input	wire		I_shifter4_VS,
    input	wire[23:0]	I_shifter4_RGB_data,
    
    input	wire		I_shifter5_DE,
    input	wire		I_shifter5_HS,
    input	wire		I_shifter5_VS,
    input	wire[23:0]	I_shifter5_RGB_data,
    
    input	wire		I_shifter6_DE,
    input	wire		I_shifter6_HS,
    input	wire		I_shifter6_VS,
    input	wire[23:0]	I_shifter6_RGB_data,
    
    output	reg			O_DE,
    output	reg			O_HS,
    output	reg			O_VS,
    output	reg[23:0]	O_RGB_data
);
	
    wire[6:0]	S_lane_judge;
    
    
    assign	S_lane_judge = {I_shifter6_right_dect,I_shifter5_right_dect,I_shifter4_right_dect,I_shifter3_right_dect,
    						I_shifter2_right_dect,I_shifter1_right_dect,I_shifter0_right_dect};
    
    
    

    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	begin
            	O_DE <= 1'd0;
                O_HS <= 1'd0;
                O_VS <= 1'd0;
                O_RGB_data <= 24'd0;
            end
        else 
        begin
        	case(S_lane_judge)
        		7'b1000_000 : 
            		begin
            			O_DE       <= I_shifter6_DE;
            	    	O_HS       <= I_shifter6_HS;
            	    	O_VS       <= I_shifter6_VS;
            	    	O_RGB_data <= I_shifter6_RGB_data;
            		end
            	7'b0100_000 : 
            		begin
            			O_DE       <= I_shifter5_DE;
            	    	O_HS       <= I_shifter5_HS;
            	    	O_VS       <= I_shifter5_VS;
            	    	O_RGB_data <= I_shifter5_RGB_data;
            		end  
            	7'b0010_000 : 
            		begin
            			O_DE       <= I_shifter4_DE;
            	    	O_HS       <= I_shifter4_HS;
            	    	O_VS       <= I_shifter4_VS;
            	    	O_RGB_data <= I_shifter4_RGB_data;
            		end 
            	7'b0001_000 : 
            		begin
            			O_DE       <= I_shifter3_DE;
            	    	O_HS       <= I_shifter3_HS;
            	    	O_VS       <= I_shifter3_VS;
            	    	O_RGB_data <= I_shifter3_RGB_data;
            		end 
            	7'b0000_100 : 
            		begin
            			O_DE       <= I_shifter2_DE;
            	    	O_HS       <= I_shifter2_HS;
            	    	O_VS       <= I_shifter2_VS;
            	    	O_RGB_data <= I_shifter2_RGB_data;
            		end  
            	7'b0000_010 : 
            		begin
            			O_DE       <= I_shifter1_DE;
            	    	O_HS       <= I_shifter1_HS;
            	    	O_VS       <= I_shifter1_VS;
            	    	O_RGB_data <= I_shifter1_RGB_data;
            		end  
            	7'b0000_001 : 
            		begin
            			O_DE       <= I_shifter0_DE;
            	    	O_HS       <= I_shifter0_HS;
            	    	O_VS       <= I_shifter0_VS;
            	    	O_RGB_data <= I_shifter0_RGB_data;
            		end 
            	default :   
            		begin
            			O_DE       <= O_DE;
            	    	O_HS       <= O_HS;
            	    	O_VS       <= O_VS;
            	    	O_RGB_data <= O_RGB_data;
            		end   
			endcase 
           end                                                                          
  end

endmodule
