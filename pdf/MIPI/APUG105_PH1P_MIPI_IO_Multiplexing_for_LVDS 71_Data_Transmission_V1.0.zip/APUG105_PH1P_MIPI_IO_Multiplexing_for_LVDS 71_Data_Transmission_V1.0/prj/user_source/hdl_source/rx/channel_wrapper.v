module channel_wrapper#(
    parameter PROTOCOL = "VESA"
)(
    input	wire		I_pixel_clk,
    input	wire		I_dphy_rx_clk,
    input	wire		I_rst,
    
    input	wire [7:0] 	I_dphy_l0_data,
    input	wire [7:0] 	I_dphy_l1_data,
    input	wire [7:0] 	I_dphy_l2_data,
    input	wire [7:0] 	I_dphy_l3_data,
    
    output	wire		O_DE,
    output	wire		O_HS,
    output	wire		O_VS,
    output	wire[23:0]	O_RGB_data
);
	
    
    wire [7:0]   S_lvds_rx_l0_data_out; 
    wire [7:0]   S_lvds_rx_l1_data_out; 
    wire [7:0]   S_lvds_rx_l2_data_out; 
    wire [7:0]   S_lvds_rx_l3_data_out; 
    

    wire [7:0]   S_lvds_rx_l0_data_inv; 
    wire [7:0]   S_lvds_rx_l1_data_inv; 
    wire [7:0]   S_lvds_rx_l2_data_inv; 
    wire [7:0]   S_lvds_rx_l3_data_inv;  

    reg  [3:0]   S_rx_clk_cnt;
    wire 		 S_rx_valid;
    
    wire	     S_7b_lane0_valid;	
	wire[6:0]    S_7b_lane0_data;		
	wire	     S_7b_lane1_valid;	
	wire[6:0]    S_7b_lane1_data;		
	wire	     S_7b_lane2_valid;	
	wire[6:0]    S_7b_lane2_data;		
	wire	     S_7b_lane3_valid;	 
	wire[6:0]    S_7b_lane3_data;	
    
    wire[6:0]	 S_lane0_shifter_bit0_data;
    wire[6:0]	 S_lane0_shifter_bit1_data;    
    wire[6:0]	 S_lane0_shifter_bit2_data;
    wire[6:0]	 S_lane0_shifter_bit3_data;
    wire[6:0]	 S_lane0_shifter_bit4_data;    
    wire[6:0]	 S_lane0_shifter_bit5_data;
    wire[6:0]	 S_lane0_shifter_bit6_data;    
                 
    wire[6:0]	 S_lane1_shifter_bit0_data;
    wire[6:0]	 S_lane1_shifter_bit1_data;    
    wire[6:0]	 S_lane1_shifter_bit2_data;
    wire[6:0]	 S_lane1_shifter_bit3_data;
    wire[6:0]	 S_lane1_shifter_bit4_data;    
    wire[6:0]	 S_lane1_shifter_bit5_data;
    wire[6:0]	 S_lane1_shifter_bit6_data; 
                 
    wire[6:0]	 S_lane2_shifter_bit0_data;
    wire[6:0]	 S_lane2_shifter_bit1_data;    
    wire[6:0]	 S_lane2_shifter_bit2_data;
    wire[6:0]	 S_lane2_shifter_bit3_data;
    wire[6:0]	 S_lane2_shifter_bit4_data;    
    wire[6:0]	 S_lane2_shifter_bit5_data;
    wire[6:0]	 S_lane2_shifter_bit6_data;             
                 
    wire[6:0]	 S_lane3_shifter_bit0_data;
    wire[6:0]	 S_lane3_shifter_bit1_data;    
    wire[6:0]	 S_lane3_shifter_bit2_data;
    wire[6:0]	 S_lane3_shifter_bit3_data;
    wire[6:0]	 S_lane3_shifter_bit4_data;    
    wire[6:0]	 S_lane3_shifter_bit5_data;
    wire[6:0]	 S_lane3_shifter_bit6_data; 
    
    wire		 S_shifter0_right_dect;
    wire		 S_shifter1_right_dect;
    wire		 S_shifter2_right_dect;
    wire		 S_shifter3_right_dect;
    wire		 S_shifter4_right_dect;
    wire		 S_shifter5_right_dect;   
    wire		 S_shifter6_right_dect;
                 
    wire		 S_shifter0_DE;				
    wire		 S_shifter0_VS;				
    wire		 S_shifter0_HS;				
    wire[23:0]	 S_shifter0_RGB_data;		
                 
    wire		 S_shifter1_DE;				
    wire		 S_shifter1_VS;				
    wire		 S_shifter1_HS; 			
    wire[23:0]	 S_shifter1_RGB_data;   	 
    
    wire		 S_shifter2_DE;				
    wire		 S_shifter2_VS;				
    wire		 S_shifter2_HS;    			
    wire[23:0]	 S_shifter2_RGB_data; 		
                 
    wire		 S_shifter3_DE;				
    wire		 S_shifter3_VS;				
    wire		 S_shifter3_HS;				
    wire[23:0]	 S_shifter3_RGB_data; 		
                 
    wire		 S_shifter4_DE;				
    wire		 S_shifter4_VS;				
    wire		 S_shifter4_HS;				
    wire[23:0]	 S_shifter4_RGB_data;  		
                 
    wire		 S_shifter5_DE;				
    wire		 S_shifter5_VS;				
    wire		 S_shifter5_HS;				
    wire[23:0]	 S_shifter5_RGB_data;  		
                 
    wire		 S_shifter6_DE;				
    wire		 S_shifter6_VS;				
    wire		 S_shifter6_HS;				
    wire[23:0]	 S_shifter6_RGB_data;   	
    
    

    assign S_lvds_rx_l0_data_out = {I_dphy_l0_data[0], I_dphy_l0_data[1], I_dphy_l0_data[2], I_dphy_l0_data[3],
    								I_dphy_l0_data[4], I_dphy_l0_data[5], I_dphy_l0_data[6], I_dphy_l0_data[7]};
    

    assign S_lvds_rx_l1_data_out = {I_dphy_l1_data[0], I_dphy_l1_data[1], I_dphy_l1_data[2], I_dphy_l1_data[3],
    								I_dphy_l1_data[4], I_dphy_l1_data[5], I_dphy_l1_data[6], I_dphy_l1_data[7]};
                                    
                                    
    assign S_lvds_rx_l2_data_out = {I_dphy_l2_data[0], I_dphy_l2_data[1], I_dphy_l2_data[2], I_dphy_l2_data[3],
    								I_dphy_l2_data[4], I_dphy_l2_data[5], I_dphy_l2_data[6], I_dphy_l2_data[7]};
                                    
                                    
    assign S_lvds_rx_l3_data_out = {I_dphy_l3_data[0], I_dphy_l3_data[1], I_dphy_l3_data[2], I_dphy_l3_data[3],
    								I_dphy_l3_data[4], I_dphy_l3_data[5], I_dphy_l3_data[6], I_dphy_l3_data[7]};
                                    
                                    
    assign	S_lvds_rx_l0_data_inv = ~S_lvds_rx_l0_data_out;
    assign	S_lvds_rx_l1_data_inv = ~S_lvds_rx_l1_data_out;    
    assign	S_lvds_rx_l2_data_inv = ~S_lvds_rx_l2_data_out;                                                                                                            
    assign	S_lvds_rx_l3_data_inv = ~S_lvds_rx_l3_data_out;
    
    
        
    always@(posedge I_dphy_rx_clk or posedge I_rst)begin
    	if(I_rst)
        	S_rx_clk_cnt <= 4'd0;
        else if(S_rx_clk_cnt == 4'd10)
        	S_rx_clk_cnt <= S_rx_clk_cnt;
        else
        	S_rx_clk_cnt <= S_rx_clk_cnt + 1'b1;
    end
    
    
    assign	S_rx_valid = (S_rx_clk_cnt >= 4'd10) ? 1'b1:1'b0;
    
    
    rx_8b_7b_conversion_wrapper u_rx_8b_7b_conversion_wrapper(
    	.I_7b_clk				(	I_pixel_clk				),
    	.I_8b_clk				(	I_dphy_rx_clk			),
    	.I_rst					(	I_rst					),
    	                                                	
        .I_rx_valid				(	S_rx_valid				),                    	 	   
    	.I_rx_lane0_data		(	S_lvds_rx_l0_data_inv	),
    	.I_rx_lane1_data		(	S_lvds_rx_l1_data_inv	),
    	.I_rx_lane2_data		(	S_lvds_rx_l2_data_inv	),
    	.I_rx_lane3_data		(	S_lvds_rx_l3_data_inv	),
    	                         	
    	.O_7b_lane0_valid		(	S_7b_lane0_valid		),
    	.O_7b_lane0_data		(	S_7b_lane0_data			),
    	.O_7b_lane1_valid		(	S_7b_lane1_valid		),
    	.O_7b_lane1_data		(	S_7b_lane1_data			),
    	.O_7b_lane2_valid		(	S_7b_lane2_valid		),
    	.O_7b_lane2_data		(	S_7b_lane2_data			),
    	.O_7b_lane3_valid		(	S_7b_lane3_valid		),
    	.O_7b_lane3_data		(	S_7b_lane3_data			)
	);                   
  
                    
	lvds_lane u0_lvds_lane(
		.I_clk_1x				(	I_pixel_clk						),   
		.I_rst					(	I_rst							),   
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane0_data					),                                              
		                	                    	        	        
        .O_shifter_bit0_data  	(	S_lane0_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane0_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane0_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane0_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane0_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane0_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane0_shifter_bit6_data		)
	);
    
    
	lvds_lane u1_lvds_lane(
		.I_clk_1x				(	I_pixel_clk						),  
		.I_rst					(	I_rst							), 
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane1_data					),  
        
        .O_shifter_bit0_data  	(	S_lane1_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane1_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane1_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane1_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane1_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane1_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane1_shifter_bit6_data		)
	);
    
    
	lvds_lane u2_lvds_lane(
		.I_clk_1x				(	I_pixel_clk						),   
		.I_rst					(	I_rst							),  
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane2_data					),  
        
        .O_shifter_bit0_data  	(	S_lane2_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane2_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane2_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane2_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane2_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane2_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane2_shifter_bit6_data		)
	);
    
    
    
	lvds_lane u3_lvds_lane(
		.I_clk_1x				(	I_pixel_clk						),  
		.I_rst					(	I_rst							), 
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane3_data					),  
        
        .O_shifter_bit0_data  	(	S_lane3_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane3_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane3_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane3_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane3_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane3_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane3_shifter_bit6_data		)
	);
    
    
	lcd_shifter_packet_wrapper#(    
	    .PROTOCOL 			(	"VESA"	)    
	)u_lcd_packet_wrapper(    
	    .I_clk						(	I_pixel_clk					),    
	    .I_rst						(	I_rst						),    
	    
	    .I_lane0_shifter_bit0_data	(	S_lane0_shifter_bit0_data	),
	    .I_lane0_shifter_bit1_data	(	S_lane0_shifter_bit1_data	),    
	    .I_lane0_shifter_bit2_data	(	S_lane0_shifter_bit2_data	),    
	    .I_lane0_shifter_bit3_data	(	S_lane0_shifter_bit3_data	), 
	    .I_lane0_shifter_bit4_data	(	S_lane0_shifter_bit4_data	),
	    .I_lane0_shifter_bit5_data	(	S_lane0_shifter_bit5_data	),
	    .I_lane0_shifter_bit6_data	(	S_lane0_shifter_bit6_data	),
	    
	    .I_lane1_shifter_bit0_data	(	S_lane1_shifter_bit0_data	),
	    .I_lane1_shifter_bit1_data	(	S_lane1_shifter_bit1_data	),
	    .I_lane1_shifter_bit2_data	(	S_lane1_shifter_bit2_data	),
	    .I_lane1_shifter_bit3_data	(	S_lane1_shifter_bit3_data	),
	    .I_lane1_shifter_bit4_data	(	S_lane1_shifter_bit4_data	),
	    .I_lane1_shifter_bit5_data	(	S_lane1_shifter_bit5_data	),
	    .I_lane1_shifter_bit6_data	(	S_lane1_shifter_bit6_data	),  
	    
	    .I_lane2_shifter_bit0_data	(	S_lane2_shifter_bit0_data	),
	    .I_lane2_shifter_bit1_data	(	S_lane2_shifter_bit1_data	),
	    .I_lane2_shifter_bit2_data	(	S_lane2_shifter_bit2_data	),
	    .I_lane2_shifter_bit3_data	(	S_lane2_shifter_bit3_data	),
	    .I_lane2_shifter_bit4_data	(	S_lane2_shifter_bit4_data	),
	    .I_lane2_shifter_bit5_data	(	S_lane2_shifter_bit5_data	),
	    .I_lane2_shifter_bit6_data	(	S_lane2_shifter_bit6_data	), 
	    
	    .I_lane3_shifter_bit0_data	(	S_lane3_shifter_bit0_data	),
	    .I_lane3_shifter_bit1_data	(	S_lane3_shifter_bit1_data	),
	    .I_lane3_shifter_bit2_data	(	S_lane3_shifter_bit2_data	),
	    .I_lane3_shifter_bit3_data	(	S_lane3_shifter_bit3_data	),
	    .I_lane3_shifter_bit4_data	(	S_lane3_shifter_bit4_data	),
	    .I_lane3_shifter_bit5_data	(	S_lane3_shifter_bit5_data	),
	    .I_lane3_shifter_bit6_data	(	S_lane3_shifter_bit6_data	),    
	    
	    .O_shifter0_RGB_data		(	S_shifter0_RGB_data			),
	    .O_shifter0_DE				(	S_shifter0_DE				),
	    .O_shifter0_VS				(	S_shifter0_VS				),
	    .O_shifter0_HS				(	S_shifter0_HS				),  
        
	    .O_shifter1_RGB_data		(	S_shifter1_RGB_data			),
	    .O_shifter1_DE				(	S_shifter1_DE				),
	    .O_shifter1_VS				(	S_shifter1_VS				),
	    .O_shifter1_HS				(	S_shifter1_HS				),
        
	    .O_shifter2_RGB_data		(	S_shifter2_RGB_data			),
	    .O_shifter2_DE				(	S_shifter2_DE				),
	    .O_shifter2_VS				(	S_shifter2_VS				),
	    .O_shifter2_HS				(	S_shifter2_HS				),
        
	    .O_shifter3_RGB_data		(	S_shifter3_RGB_data			),
	    .O_shifter3_DE				(	S_shifter3_DE				),
	    .O_shifter3_VS				(	S_shifter3_VS				),
	    .O_shifter3_HS				(	S_shifter3_HS				),
        
	    .O_shifter4_RGB_data		(	S_shifter4_RGB_data			),
	    .O_shifter4_DE				(	S_shifter4_DE				),
	    .O_shifter4_VS				(	S_shifter4_VS				),
	    .O_shifter4_HS				(	S_shifter4_HS				),
        
	    .O_shifter5_RGB_data		(	S_shifter5_RGB_data			),
	    .O_shifter5_DE				(	S_shifter5_DE				),
	    .O_shifter5_VS				(	S_shifter5_VS				),
	    .O_shifter5_HS				(	S_shifter5_HS				),
        
	    .O_shifter6_RGB_data		(	S_shifter6_RGB_data			),
	    .O_shifter6_DE				(	S_shifter6_DE				),
	    .O_shifter6_VS				(	S_shifter6_VS				),
	    .O_shifter6_HS				(	S_shifter6_HS				)   
	);
    
    
    lcd_protocol_dect_wrapper u_lcd_dect_wrapper(
		.I_clk					(	I_pixel_clk				),
		.I_rst					(	I_rst					),
		                		                    		
		.I_shifter0_DE			(	S_shifter0_DE			),
		.I_shifter0_VS			(	S_shifter0_VS			),
		.I_shifter0_HS			(	S_shifter0_HS			),
		              			                    		
		.I_shifter1_DE			(	S_shifter1_DE			),
		.I_shifter1_VS			(	S_shifter1_VS			),
		.I_shifter1_HS			(	S_shifter1_HS			),
		              	                            		
		.I_shifter2_DE			(	S_shifter2_DE			),
		.I_shifter2_VS			(	S_shifter2_VS			),
		.I_shifter2_HS			(	S_shifter2_HS			),
		              			                    		
		.I_shifter3_DE			(	S_shifter3_DE			),
		.I_shifter3_VS			(	S_shifter3_VS			),
		.I_shifter3_HS			(	S_shifter3_HS			),
		              			                    		
		.I_shifter4_DE			(	S_shifter4_DE			),
		.I_shifter4_VS			(	S_shifter4_VS			),
		.I_shifter4_HS			(	S_shifter4_HS			),
		              			                    		
		.I_shifter5_DE			(	S_shifter5_DE			),
		.I_shifter5_VS			(	S_shifter5_VS			),
		.I_shifter5_HS			(	S_shifter5_HS			),
		              			                    		
		.I_shifter6_DE			(	S_shifter6_DE			),
		.I_shifter6_VS			(	S_shifter6_VS			),
		.I_shifter6_HS			(	S_shifter6_HS			),
		                        
		.O_shifter0_right_dect	(	S_shifter0_right_dect	),
		.O_shifter1_right_dect	(	S_shifter1_right_dect	),
		.O_shifter2_right_dect	(	S_shifter2_right_dect	),
		.O_shifter3_right_dect	(	S_shifter3_right_dect	),
		.O_shifter4_right_dect	(	S_shifter4_right_dect	),
		.O_shifter5_right_dect	(	S_shifter5_right_dect	),
		.O_shifter6_right_dect	(	S_shifter6_right_dect	)
	);
    

    lane_choose u_lane_choose(
    	.I_clk						(	I_pixel_clk				),
    	.I_rst						(	I_rst					),
    	                             	
    	.I_shifter0_right_dect		(	S_shifter0_right_dect	),
		.I_shifter1_right_dect		(	S_shifter1_right_dect	),
		.I_shifter2_right_dect		(	S_shifter2_right_dect	),
		.I_shifter3_right_dect		(	S_shifter3_right_dect	),
		.I_shifter4_right_dect		(	S_shifter4_right_dect	),
		.I_shifter5_right_dect		(	S_shifter5_right_dect	),
		.I_shifter6_right_dect		(	S_shifter6_right_dect	),
    	                             	
    	.I_shifter0_DE				(	S_shifter0_DE			),
    	.I_shifter0_HS				(	S_shifter0_HS			),
    	.I_shifter0_VS				(	S_shifter0_VS			),
    	.I_shifter0_RGB_data		(	S_shifter0_RGB_data		),
    	                             	
    	.I_shifter1_DE				(	S_shifter1_DE			),
    	.I_shifter1_HS				(	S_shifter1_HS			),
    	.I_shifter1_VS				(	S_shifter1_VS			),
    	.I_shifter1_RGB_data		(	S_shifter1_RGB_data		),
    	                             	
    	.I_shifter2_DE				(	S_shifter2_DE			),
    	.I_shifter2_HS				(	S_shifter2_HS			),
    	.I_shifter2_VS				(	S_shifter2_VS			),
    	.I_shifter2_RGB_data		(	S_shifter2_RGB_data		),    
    	                             	
    	.I_shifter3_DE				(	S_shifter3_DE	   		),
    	.I_shifter3_HS				(	S_shifter3_HS	   		),
    	.I_shifter3_VS				(	S_shifter3_VS	   		),
    	.I_shifter3_RGB_data		(	S_shifter3_RGB_data		),    
    	                             	
    	.I_shifter4_DE				(	S_shifter4_DE	   		),
    	.I_shifter4_HS				(	S_shifter4_HS	   		),
    	.I_shifter4_VS				(	S_shifter4_VS	   		),
    	.I_shifter4_RGB_data		(	S_shifter4_RGB_data		),
    	                             	                   		
    	.I_shifter5_DE				(	S_shifter5_DE	   		),
    	.I_shifter5_HS				(	S_shifter5_HS	   		),
    	.I_shifter5_VS				(	S_shifter5_VS	   		),
    	.I_shifter5_RGB_data		(	S_shifter5_RGB_data		),
    	                             	                   		
    	.I_shifter6_DE				(	S_shifter6_DE	   		),
    	.I_shifter6_HS				(	S_shifter6_HS	   		),
    	.I_shifter6_VS				(	S_shifter6_VS	   		),
    	.I_shifter6_RGB_data		(	S_shifter6_RGB_data		),
    	                             	
    	.O_DE						(	O_DE	   				),
    	.O_HS						(	O_HS	   				),
    	.O_VS						(	O_VS	   				),
    	.O_RGB_data					(	O_RGB_data				)
	);

endmodule
