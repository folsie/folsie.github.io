module lvds_shifter_wrapper( 
	input	wire		I_clk,
    input	wire		I_rst,
    
    input	wire[6:0]	I_deserial_data,
    
    output	wire[6:0]	O_shifter0_data,
    output	wire[6:0]	O_shifter1_data,
    output	wire[6:0]	O_shifter2_data,
    output	wire[6:0]	O_shifter3_data,
    output	wire[6:0]	O_shifter4_data,
    output	wire[6:0]	O_shifter5_data,
    output	wire[6:0]	O_shifter6_data
);
	
    
    
    deserial_data_shifter#(
    	.SHIFTER_BIT_NUM 	(	3'd0			)
    )shifter_0(                              	
    	.I_clk				(	I_clk			),
    	.I_rst				(	I_rst			),
    	.I_deserial_data	(	I_deserial_data	),
    	                    
    	.O_shifter_data		(	O_shifter0_data	)
	);
    
    
    deserial_data_shifter#(
    	.SHIFTER_BIT_NUM 	(	3'd1			)
    )shifter_1(                              	
    	.I_clk				(	I_clk			),
    	.I_rst				(	I_rst			),
    	.I_deserial_data	(	I_deserial_data	),
    	                    
    	.O_shifter_data		(	O_shifter1_data	)
	);
    
    
    deserial_data_shifter#(
    	.SHIFTER_BIT_NUM 	(	3'd2			)
    )shifter_2(                              	
    	.I_clk				(	I_clk			),
    	.I_rst				(	I_rst			),
    	.I_deserial_data	(	I_deserial_data	),
    	                    
    	.O_shifter_data		(	O_shifter2_data	)
	);
    
    
    deserial_data_shifter#(
    	.SHIFTER_BIT_NUM 	(	3'd3			)
    )shifter_3(                              	
    	.I_clk				(	I_clk			),
    	.I_rst				(	I_rst			),
    	.I_deserial_data	(	I_deserial_data	),
    	                    
    	.O_shifter_data		(	O_shifter3_data	)
	);
    
    
    deserial_data_shifter#(
    	.SHIFTER_BIT_NUM 	(	3'd4			)
    )shifter_4(                              	
    	.I_clk				(	I_clk			),
    	.I_rst				(	I_rst			),
    	.I_deserial_data	(	I_deserial_data	),
    	                    
    	.O_shifter_data		(	O_shifter4_data	)
	);
    
    
    deserial_data_shifter#(
    	.SHIFTER_BIT_NUM 	(	3'd5			)
    )shifter_5(                              	
    	.I_clk				(	I_clk			),
    	.I_rst				(	I_rst			),
    	.I_deserial_data	(	I_deserial_data	),
    	                    
    	.O_shifter_data		(	O_shifter5_data	)
	);
    
    
    deserial_data_shifter#(
    	.SHIFTER_BIT_NUM 	(	3'd6			)
    )shifter_6(                              	
    	.I_clk				(	I_clk			),
    	.I_rst				(	I_rst			),
    	.I_deserial_data	(	I_deserial_data	),
    	                    
    	.O_shifter_data		(	O_shifter6_data	)
	);
    


endmodule
