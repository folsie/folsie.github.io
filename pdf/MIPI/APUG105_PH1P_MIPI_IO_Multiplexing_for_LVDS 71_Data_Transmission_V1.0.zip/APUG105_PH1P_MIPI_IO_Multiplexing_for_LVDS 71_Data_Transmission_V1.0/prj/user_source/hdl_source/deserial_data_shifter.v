module deserial_data_shifter#(
    parameter	SHIFTER_BIT_NUM = 3'd0
   )(
    input	wire		I_clk,
    input	wire		I_rst,
    input	wire[6:0]	I_deserial_data,
    
    output	reg[6:0]	O_shifter_data
);
	
    reg	[13:0]	S_joint_data;
    reg	[6:0]	S_shifter_data;
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_joint_data <= 14'd0;
        else
        	S_joint_data <= {S_joint_data[6:0],I_deserial_data};
    end
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_shifter_data <= 7'd0;
        else
        	case(SHIFTER_BIT_NUM)
            	3'd0:S_shifter_data <= S_joint_data[13:7];
            	3'd1:S_shifter_data <= S_joint_data[12:6];
                3'd2:S_shifter_data <= S_joint_data[11:5];
                3'd3:S_shifter_data <= S_joint_data[10:4];
                3'd4:S_shifter_data <= S_joint_data[9:3];
                3'd5:S_shifter_data <= S_joint_data[8:2];
                3'd6:S_shifter_data <= S_joint_data[7:1];
            endcase
    end
    
    
    always@(posedge I_clk)begin
    	O_shifter_data <= S_shifter_data;
    end


endmodule
