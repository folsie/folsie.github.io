module lvds_rx_1_7(
    input	wire		I_clk_1x,
    input	wire		I_clk_3p5x,    
    input	wire		I_rst,
    
    input	wire		I_din_lvds_rx_p,
    
    output	reg[6:0]	O_diff_pdata
);
	
    wire [6:0]	S_diff_pdata;
    
    
    PH1P_LOGIC_HR_ISERDES #(
  		.IDDRMODE     ( "DDRX3P5"    )/*, //  "DDRX1", "DDRX1_PIPE", "DDRX2", "DDRX3P5", "DDRX4", "DDRX5".  IDDR mode select.  
  		.DEVICE       ( "PH1P35"   )  //  "PH1P100", "PH1X100", "PH1P35", "PH1S35", "PH1P50".  Device selection.*/  
	)u_PH1P_LOGIC_HR_ISERDES(
  		.sclk         ( I_clk_3p5x       ), //  1-Bit input. Clock input of sclk.           
  		.pclk         ( I_clk_1x		 ), //  1-Bit input. Clock input of pclk.           
  		.rst          ( I_rst        	 ), //  1-Bit input. Reset signal,high active.      
  		.idata        ( I_din_lvds_rx_p  ), //  1-Bit input. Serial data input.             
  		.odata        ( S_diff_pdata   	 )  //  10-Bit output. Parallel data output.          
	);
    
    
    always@(posedge I_clk_1x)begin
    	O_diff_pdata <= S_diff_pdata;
    end


endmodule
