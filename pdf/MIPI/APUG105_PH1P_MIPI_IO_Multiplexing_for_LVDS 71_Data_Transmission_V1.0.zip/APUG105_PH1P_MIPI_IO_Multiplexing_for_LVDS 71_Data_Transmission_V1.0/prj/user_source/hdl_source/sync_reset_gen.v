module sync_reset_gen(
    input	wire		I_clk_1x,
    input	wire		I_clk_3p5x,    
    input	wire		I_rst, 
    
    output	wire		O_sync_rst
);
	
    
    reg		S_rst_d;
    reg		S_rst_2d;
    
    
    always@(posedge I_clk_1x or posedge I_rst)begin
    	if(I_rst)
        	begin
        		S_rst_d  <= 1'b1;
            	S_rst_2d <= 1'b1;
            end
        else 
        	begin
            	S_rst_d  <= 1'b0;
                S_rst_2d <= S_rst_d;
            end
    end
    
    
    assign	O_sync_rst = S_rst_2d;


endmodule
