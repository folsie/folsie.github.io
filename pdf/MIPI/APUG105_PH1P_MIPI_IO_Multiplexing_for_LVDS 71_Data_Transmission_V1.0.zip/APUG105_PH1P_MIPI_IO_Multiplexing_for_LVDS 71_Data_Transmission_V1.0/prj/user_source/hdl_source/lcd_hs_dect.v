module lcd_hs_dect(    
	input	wire		I_clk,
    input	wire		I_rst,
    
    input	wire		I_shifter_DE,
    input	wire		I_shifter_HS,
    input	wire		I_shifter_VS,
    
    output	reg 		O_shifter_right_dect
);


/*
		S_valid_col = 100; S_line = 96;
*/

    reg	[7:0]	S_valid_col;	//synthesis keep = 1
    reg	[7:0]	S_col;			//synthesis keep = 1
    reg [7:0]	S_line;			//synthesis keep = 1
    reg [7:0]	S_valid_line;
    reg			S_HS_d;
    wire		S_HS_n_edge;	//synthesis keep = 1
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_valid_col <= 'd0;
        else if(I_shifter_DE)
        	S_valid_col <= S_valid_col + 1'b1;
        else
        	S_valid_col <= 'd0;
    end
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_col <= 'd0;
        else if(I_shifter_HS)
        	S_col <= S_col + 1'b1;
        else
        	S_col <= 'd0;
    end
     
    
    always@(posedge I_clk)begin
        	S_HS_d <= I_shifter_HS;
    end
    
    
    assign	S_HS_n_edge = ~I_shifter_HS && S_HS_d;
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_line <= 'd0;
        else if(I_shifter_VS)
        	if(S_HS_n_edge)						
        		S_line <= S_line + 1'b1;
            else
            	S_line <= S_line;
        else
        	S_line <= 'd0;
    end

    
endmodule