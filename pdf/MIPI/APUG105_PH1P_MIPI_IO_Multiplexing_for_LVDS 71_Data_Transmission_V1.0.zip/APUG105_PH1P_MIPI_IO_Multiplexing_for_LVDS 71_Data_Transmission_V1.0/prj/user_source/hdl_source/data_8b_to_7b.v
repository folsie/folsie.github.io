module data_8b_to_7b(
    input wire       I_rst,
  
    input wire       I_8b_clk,
    input wire       I_8b_valid,
    input wire[7:0]  I_8b_data,
 
    input wire       I_7b_clk,
    output reg       O_7b_valid,
    output reg[6:0]  O_7b_data
);
	
    
    wire      	S_fifo_rd_en;        
    wire[7:0] 	S_fifo_rd_data;     
    reg [7:0]	S_fifo_rd_data_1d;
    
    wire		S_fifo_empty_flag;
    wire[8:0]	S_fifo_rdpointer;

    reg			S_8b_to_7b_en; 
    reg			S_8b_to_7b_en_1d;
    
    reg [3:0]	S_fifo_rd_en_cnt;
    reg [3:0]	S_fifo_rd_en_cnt_1d;
    

	w8_d512_fifo u_w8_d512_fifo(
        .rst        ( I_rst             ),

        .clkw       ( I_8b_clk          ),
        .we         ( I_8b_valid   		),
        .di         ( I_8b_data		    ),
        .full_flag  (                   ),
        .afull      (                   ),
        .wrusedw    (                   ),

        .clkr       ( I_7b_clk          ),
        .re         ( S_fifo_rd_en      ),
        .dout       ( S_fifo_rd_data	),
        .valid      ( 			        ),
        .empty_flag ( S_fifo_empty_flag ),
        .aempty     (                   ),
        .rdusedw    ( S_fifo_rdpointer  )
    );
    
    
    always @(posedge I_7b_clk or posedge I_rst) begin
        if(I_rst)
            S_8b_to_7b_en <= 1'b0;
        else    
            begin
                if(S_fifo_rdpointer >= 'd256)
                    S_8b_to_7b_en <= 1'b1;
                else if(S_fifo_rdpointer == 'd0)
                    S_8b_to_7b_en <= 1'b0;
                else
                    S_8b_to_7b_en <= S_8b_to_7b_en;
            end
    end
    
    
    always @(posedge I_7b_clk) begin
        if(S_8b_to_7b_en)
            begin
                if(S_fifo_rd_en_cnt == 'd7)
                    S_fifo_rd_en_cnt <= 'd0;
                else
                    S_fifo_rd_en_cnt <= S_fifo_rd_en_cnt + 'd1;
            end
        else
            S_fifo_rd_en_cnt <= 'd0;
    end
    
    
    assign S_fifo_rd_en = S_8b_to_7b_en && (S_fifo_rd_en_cnt < 'd7) ? 1'b1 : 1'b0;
    
    
    always @(posedge I_7b_clk) begin
        S_8b_to_7b_en_1d    <= S_8b_to_7b_en;
        S_fifo_rd_en_cnt_1d <= S_fifo_rd_en_cnt;
        S_fifo_rd_data_1d   <= S_fifo_rd_data;
    end
    
    
    always @(posedge I_7b_clk) begin
        if(S_8b_to_7b_en_1d)
            begin
                O_7b_valid <= 1'b1;
                case(S_fifo_rd_en_cnt_1d)
                    'd0 : O_7b_data <= S_fifo_rd_data[7:1];
                    'd1 : O_7b_data <= {S_fifo_rd_data_1d[0],S_fifo_rd_data[7:2]};
                    'd2 : O_7b_data <= {S_fifo_rd_data_1d[1:0],S_fifo_rd_data[7:3]};
                    'd3 : O_7b_data <= {S_fifo_rd_data_1d[2:0],S_fifo_rd_data[7:4]};
                    'd4 : O_7b_data <= {S_fifo_rd_data_1d[3:0],S_fifo_rd_data[7:5]};
                    'd5 : O_7b_data <= {S_fifo_rd_data_1d[4:0],S_fifo_rd_data[7:6]};
                    'd6 : O_7b_data <= {S_fifo_rd_data_1d[5:0],S_fifo_rd_data[7]};
                    'd7 : O_7b_data <= S_fifo_rd_data_1d[6:0];
                endcase
            end
        else
            begin
                O_7b_valid <= 1'b0;
                O_7b_data  <= 'd0;
            end
    end



endmodule
