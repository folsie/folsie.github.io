module lvds_rx_wrapper#(
    parameter PROTOCOL = "VESA" // 协议：JEIDA、VESA
)(
    input	wire		I_sys_clk,
    input	wire		I_clk_1x,
    input	wire		I_clk_3p5x,    
    input	wire		I_rst, 
    
    inout	wire		IO_rx_clk_pad_n, 
	inout	wire		IO_rx_clk_pad_p,
	inout	wire[3:0]	IO_rx_data_pad_n,
	inout	wire[3:0]	IO_rx_data_pad_p,      
     
    output wire			O_DE,
    output wire			O_VS,
    output wire			O_HS,
    output wire[23:0]  	O_RGB	
);
	
    
    wire		S_rx_parall_clk;
    wire		S_clk_1x;
    wire		S_clk_3p5x;
    wire		S_clk_3p5x_mlclk;
    
    wire[6:0]	S_lane0_shifter_bit0_data;
    wire[6:0]	S_lane0_shifter_bit1_data;    
    wire[6:0]	S_lane0_shifter_bit2_data;
    wire[6:0]	S_lane0_shifter_bit3_data;
    wire[6:0]	S_lane0_shifter_bit4_data;    
    wire[6:0]	S_lane0_shifter_bit5_data;
    wire[6:0]	S_lane0_shifter_bit6_data;    

    wire[6:0]	S_lane1_shifter_bit0_data;
    wire[6:0]	S_lane1_shifter_bit1_data;    
    wire[6:0]	S_lane1_shifter_bit2_data;
    wire[6:0]	S_lane1_shifter_bit3_data;
    wire[6:0]	S_lane1_shifter_bit4_data;    
    wire[6:0]	S_lane1_shifter_bit5_data;
    wire[6:0]	S_lane1_shifter_bit6_data; 
    
    wire[6:0]	S_lane2_shifter_bit0_data;
    wire[6:0]	S_lane2_shifter_bit1_data;    
    wire[6:0]	S_lane2_shifter_bit2_data;
    wire[6:0]	S_lane2_shifter_bit3_data;
    wire[6:0]	S_lane2_shifter_bit4_data;    
    wire[6:0]	S_lane2_shifter_bit5_data;
    wire[6:0]	S_lane2_shifter_bit6_data;             
   
    wire[6:0]	S_lane3_shifter_bit0_data;
    wire[6:0]	S_lane3_shifter_bit1_data;    
    wire[6:0]	S_lane3_shifter_bit2_data;
    wire[6:0]	S_lane3_shifter_bit3_data;
    wire[6:0]	S_lane3_shifter_bit4_data;    
    wire[6:0]	S_lane3_shifter_bit5_data;
    wire[6:0]	S_lane3_shifter_bit6_data; 
    
    wire		S_shifter0_right_dect;
    wire		S_shifter1_right_dect;
    wire		S_shifter2_right_dect;
    wire		S_shifter3_right_dect;
    wire		S_shifter4_right_dect;
    wire		S_shifter5_right_dect;   
    wire		S_shifter6_right_dect;
    
    wire		S_shifter0_DE;				//synthesis keep = 1
    wire		S_shifter0_VS;				//synthesis keep = 1
    wire		S_shifter0_HS;				//synthesis keep = 1
    wire[23:0]	S_shifter0_RGB_data;		//synthesis keep = 1
    
    wire		S_shifter1_DE;				//synthesis keep = 1
    wire		S_shifter1_VS;				//synthesis keep = 1
    wire		S_shifter1_HS; 				//synthesis keep = 1
    wire[23:0]	S_shifter1_RGB_data;   		//synthesis keep = 1    
    
    wire		S_shifter2_DE;				//synthesis keep = 1
    wire		S_shifter2_VS;				//synthesis keep = 1
    wire		S_shifter2_HS;    			//synthesis keep = 1
    wire[23:0]	S_shifter2_RGB_data; 		//synthesis keep = 1

    wire		S_shifter3_DE;				//synthesis keep = 1
    wire		S_shifter3_VS;				//synthesis keep = 1
    wire		S_shifter3_HS;				//synthesis keep = 1
    wire[23:0]	S_shifter3_RGB_data; 		//synthesis keep = 1

    wire		S_shifter4_DE;				//synthesis keep = 1
    wire		S_shifter4_VS;				//synthesis keep = 1
    wire		S_shifter4_HS;				//synthesis keep = 1
    wire[23:0]	S_shifter4_RGB_data;  		//synthesis keep = 1   

    wire		S_shifter5_DE;				//synthesis keep = 1
    wire		S_shifter5_VS;				//synthesis keep = 1
    wire		S_shifter5_HS;				//synthesis keep = 1
    wire[23:0]	S_shifter5_RGB_data;  		//synthesis keep = 1   
    
    wire		S_shifter6_DE;				//synthesis keep = 1
    wire		S_shifter6_VS;				//synthesis keep = 1
    wire		S_shifter6_HS;				//synthesis keep = 1
    wire[23:0]	S_shifter6_RGB_data;   		//synthesis keep = 1  
    
    wire		S_lvds_rx_clk_out;
    wire		S_lvds_rx_clk;
    reg [3:0]	S_rx_clk_cnt;
    wire[7:0]	S_lvds_rx_l0_data_out;
	wire[7:0]	S_lvds_rx_l1_data_out;
	wire[7:0]	S_lvds_rx_l2_data_out;
	wire[7:0]	S_lvds_rx_l3_data_out;
    
    wire[7:0]	S_lvds_rx_l0_data_inv;		//synthesis keep = 1 
    wire[7:0]	S_lvds_rx_l1_data_inv;		//synthesis keep = 1 
    wire[7:0]	S_lvds_rx_l2_data_inv;		//synthesis keep = 1 
    wire[7:0]	S_lvds_rx_l3_data_inv; 		//synthesis keep = 1            
     
	wire	     S_7b_clk_lane_valid;	
	wire[6:0]    S_7b_clk_lane_data;	
	wire	     S_7b_lane0_valid;	
	wire[6:0]    S_7b_lane0_data;		
	wire	     S_7b_lane1_valid;	
	wire[6:0]    S_7b_lane1_data;		
	wire	     S_7b_lane2_valid;	
	wire[6:0]    S_7b_lane2_data;		
	wire	     S_7b_lane3_valid;	 
	wire[6:0]    S_7b_lane3_data;	
    	
    wire		 S_pll_lock;				//synthesis keep = 1  
    wire		 S_rx_rst;
    
 
    reg			 S_pll_lock_1d;
    reg			 S_rx_dphy_rst;  
    
    
    
    RX_PLL u_GPLL(
		.refclk		(	S_rx_parall_clk		),
		.reset		(	1'b0				),
		.lock		(	S_pll_lock			),
                        
		.clk0_out	(	S_clk_1x			),		// 100M
		.clk1_out	(	S_clk_3p5x			)		// 350M
	);
    
    
    PH1P_PHY_MLCLK #(
	  .GSR          ( "DISABLE"   			), //  "ENABLE", "DISABLE".        
	  .BYPASS       ( "DISABLE"   			)  //  "ENABLE", "DISABLE".        
	)u_PH1P_PHY_RX_MLCLK(           		
	  .ce           ( 1'b1         			), //  1-Bit input.                                
	  .clkin        ( S_clk_3p5x    		), //  1-Bit input.                                
	  .clkout       ( S_clk_3p5x_mlclk	    )  //  1-Bit output.                                
	); 
     
    
    assign S_rx_rst = ~S_pll_lock;
    
    
    always@(posedge I_sys_clk)begin
    	S_pll_lock_1d <= S_pll_lock;
    end
    
    assign	S_pll_lock_p_edge = ~S_pll_lock_1d && S_pll_lock;
    
    always@(posedge I_sys_clk or posedge I_rst)begin
    	if(I_rst)
        	S_rx_dphy_rst <= 1'd0;
        else if(S_pll_lock_p_edge)
        	S_rx_dphy_rst <= 1'd1;
        else
        	S_rx_dphy_rst <= S_rx_dphy_rst;
    end
    
    
    PH1P_LOGIC_DPHY_LVDS_RX #(
        .DPHY_RX_LOCATION              ( "DPHY0"           ),//"DPHY0", "DPHY1"
                      
        .S2P_RATIO                     ( "1:8"			   ),//"1:8","1:16"
        .SAMPLE_CLOCK_SEL              ( "PLL"       	   ),//"CLK_LANE","PLL"
                     
        .CK_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .CK_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .CK_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .CK_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .CK_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .CK_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .CK_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .CK_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"
        
        .L0_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L0_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L0_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L0_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L0_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L0_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L0_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L0_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L0_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"

        .L1_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L1_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L1_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L1_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L1_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L1_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L1_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L1_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L1_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"

        .L2_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L2_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L2_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L2_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L2_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L2_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L2_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L2_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L2_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ),//"ENABLE","DISABLE"

        .L3_SLAVE_DESER_CLK_OFFSET     ( "16ps"            ),//"0ps","16ps","32ps","48ps"
        .L3_EQUALIZER                  ( "0dB"             ),//"0dB","1.5dB","3dB","4.5dB","6dB","7.5dB","9dB","10.5dB"
        .L3_VGA_GAIN                   ( "0dB"             ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .L3_IDELAY_ENABLE              ( "ENABLE"          ),//"ENABLE","DISABLE"
        .L3_TERMINATOR                 ( "DC100ohm"        ),//"NONE","DC100ohm","AC100ohm"
        .L3_VCM_COMPENSATION           ( "DISABLE"         ),//"ENABLE","DISABLE"
        .L3_DUTY_COMPENSATION          ( "0%"              ),//"0%","1%","2%","3%","4%","5%","6%","7%"
        .L3_DUTY_COMPENSATION_POLARITY ( "DECREASE"        ),//"DECREASE","INCREASE"
        .L3_INTERNAL_AC_CAP_ENABLE     ( "DISABLE"         ) //"ENABLE","DISABLE"
    )u_PH1P_LOGIC_DPHY_LVDS_RX(
        .io_clk_pad_n            ( IO_rx_clk_pad_n  	),
        .io_clk_pad_p            ( IO_rx_clk_pad_p  	),
        .io_data_pad_n           ( IO_rx_data_pad_n 	),
        .io_data_pad_p           ( IO_rx_data_pad_p 	),

        .i_pll_to_phy_sample_clk ( S_clk_3p5x_mlclk	     ),			// 350M
        .o_phy_to_pll_ref_clk    ( S_rx_parall_clk       ),  	 	// 175M  
        .o_fabric_div5_10_clk    ( S_lvds_rx_10b_clk_out ),     	// 70 M
        .o_fabric_div4_8_clk     ( S_lvds_rx_clk_out     ),			// 87.5M
        .i_phy_rst_n             ( 1'b1					 ),		//
             
        .i_ck_rx_en              ( 1'b1                  ),
        .i_ck_idelay_value       ( 6'd0                  ),
    
        .i_l0_rx_en              ( 1'b1                  ),
        .i_l0_slave_deser_clk_en ( 1'b0                  ),
        .i_l0_idelay_value       ( 6'd0                  ),
        .o_l0_rx_data            ( S_lvds_rx_l0_data_inv ),
        .o_l0_rx_slave_data      (                       ),

        .i_l1_rx_en              ( 1'b1                  ),
        .i_l1_slave_deser_clk_en ( 1'b0                  ),
        .i_l1_idelay_value       ( 6'd0                  ),
        .o_l1_rx_data            ( S_lvds_rx_l1_data_inv ),
        .o_l1_rx_slave_data      (                       ),

        .i_l2_rx_en              ( 1'b1                  ),
        .i_l2_slave_deser_clk_en ( 1'b0                  ),
        .i_l2_idelay_value       ( 6'd0                  ),
        .o_l2_rx_data            ( S_lvds_rx_l2_data_inv ),
        .o_l2_rx_slave_data      (                       ),

        .i_l3_rx_en              ( 1'b1                  ),
        .i_l3_slave_deser_clk_en ( 1'b0                  ),
        .i_l3_idelay_value       ( 6'd0                  ),
        .o_l3_rx_data            ( S_lvds_rx_l3_data_inv ),
        .o_l3_rx_slave_data      (                       )
    );
	
    
    PH1P_LOGIC_BUFG U2_PH1P_LOGIC_BUFG (
 		.i( S_lvds_rx_clk_out ), 
 		.o( S_lvds_rx_clk     ) 
 	);
 
 
/*     
*/    
    assign	O_lvds_rx_parall_clk = S_rx_parall_clk;
     
     
    assign S_lvds_rx_l0_data_out = {S_lvds_rx_l0_data_inv[0], S_lvds_rx_l0_data_inv[1], S_lvds_rx_l0_data_inv[2], S_lvds_rx_l0_data_inv[3],
    								S_lvds_rx_l0_data_inv[4], S_lvds_rx_l0_data_inv[5], S_lvds_rx_l0_data_inv[6], S_lvds_rx_l0_data_inv[7]};
    

    assign S_lvds_rx_l1_data_out = {S_lvds_rx_l1_data_inv[0], S_lvds_rx_l1_data_inv[1], S_lvds_rx_l1_data_inv[2], S_lvds_rx_l1_data_inv[3],
    								S_lvds_rx_l1_data_inv[4], S_lvds_rx_l1_data_inv[5], S_lvds_rx_l1_data_inv[6], S_lvds_rx_l1_data_inv[7]};
                                    
                                    
    assign S_lvds_rx_l2_data_out = {S_lvds_rx_l2_data_inv[0], S_lvds_rx_l2_data_inv[1], S_lvds_rx_l2_data_inv[2], S_lvds_rx_l2_data_inv[3],
    								S_lvds_rx_l2_data_inv[4], S_lvds_rx_l2_data_inv[5], S_lvds_rx_l2_data_inv[6], S_lvds_rx_l2_data_inv[7]};
                                    
                                    
    assign S_lvds_rx_l3_data_out = {S_lvds_rx_l3_data_inv[0], S_lvds_rx_l3_data_inv[1], S_lvds_rx_l3_data_inv[2], S_lvds_rx_l3_data_inv[3],
    								S_lvds_rx_l3_data_inv[4], S_lvds_rx_l3_data_inv[5], S_lvds_rx_l3_data_inv[6], S_lvds_rx_l3_data_inv[7]};
                                                                                                            
    
    always@(posedge S_lvds_rx_clk or posedge S_rx_rst)begin
    	if(S_rx_rst)
        	S_rx_clk_cnt <= 4'd0;
        else if(S_rx_clk_cnt == 4'd10)
        	S_rx_clk_cnt <= S_rx_clk_cnt;
        else
        	S_rx_clk_cnt <= S_rx_clk_cnt + 1'b1;
    end
    
    
    assign	S_rx_valid = (S_rx_clk_cnt >= 4'd10) ? 1'b1:1'b0;
    
    
    rx_8b_7b_conversion_wrapper u_rx_8b_7b_conversion_wrapper(
    	.I_7b_clk				(	S_clk_1x				),
    	.I_8b_clk				(	S_lvds_rx_clk			),
    	.I_rst					(	S_rx_rst				),
    	                                                	
        .I_rx_valid				(	S_rx_valid				),                    	 	
//    	.I_rx_lane_clk			(	S_rx_parall_clk			),    
    	.I_rx_lane0_data		(	S_lvds_rx_l0_data_out	),
    	.I_rx_lane1_data		(	S_lvds_rx_l1_data_out	),
    	.I_rx_lane2_data		(	S_lvds_rx_l2_data_out	),
    	.I_rx_lane3_data		(	S_lvds_rx_l3_data_out	),
    	                         	
//    	.O_7b_clk_lane_valid	(	S_7b_clk_lane_valid		),
//    	.O_7b_clk_lane_data		(	S_7b_clk_lane_data		),
    	.O_7b_lane0_valid		(	S_7b_lane0_valid		),
    	.O_7b_lane0_data		(	S_7b_lane0_data			),
    	.O_7b_lane1_valid		(	S_7b_lane1_valid		),
    	.O_7b_lane1_data		(	S_7b_lane1_data			),
    	.O_7b_lane2_valid		(	S_7b_lane2_valid		),
    	.O_7b_lane2_data		(	S_7b_lane2_data			),
    	.O_7b_lane3_valid		(	S_7b_lane3_valid		),
    	.O_7b_lane3_data		(	S_7b_lane3_data			)
	);                   
  
                    
	lvds_lane u0_lvds_lane(
		.I_clk_1x				(	S_clk_1x						),   
		.I_rst					(	S_rx_rst						),   
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane0_data					),                                              
		                	                    	        	        
        .O_shifter_bit0_data  	(	S_lane0_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane0_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane0_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane0_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane0_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane0_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane0_shifter_bit6_data		)
	);
    
    
	lvds_lane u1_lvds_lane(
		.I_clk_1x				(	S_clk_1x						),  
		.I_rst					(	S_rx_rst						), 
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane1_data					),  
        
        .O_shifter_bit0_data  	(	S_lane1_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane1_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane1_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane1_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane1_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane1_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane1_shifter_bit6_data		)
	);
    
    
	lvds_lane u2_lvds_lane(
		.I_clk_1x				(	S_clk_1x						),   
		.I_rst					(	S_rx_rst						),  
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane2_data					),  
        
        .O_shifter_bit0_data  	(	S_lane2_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane2_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane2_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane2_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane2_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane2_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane2_shifter_bit6_data		)
	);
    
    
    
	lvds_lane u3_lvds_lane(
		.I_clk_1x				(	S_clk_1x						),  
		.I_rst					(	S_rx_rst						), 
		                		                    				
        .I_lvds_rx_lane_data	(	S_7b_lane3_data					),  
        
        .O_shifter_bit0_data  	(	S_lane3_shifter_bit0_data		), 
		.O_shifter_bit1_data  	(	S_lane3_shifter_bit1_data		), 
		.O_shifter_bit2_data  	(	S_lane3_shifter_bit2_data		), 
		.O_shifter_bit3_data  	(	S_lane3_shifter_bit3_data		), 
		.O_shifter_bit4_data  	(	S_lane3_shifter_bit4_data		), 
		.O_shifter_bit5_data  	(	S_lane3_shifter_bit5_data		), 
		.O_shifter_bit6_data  	(	S_lane3_shifter_bit6_data		)
	);
    
    
	lcd_shifter_packet_wrapper#(    
	    .PROTOCOL 			(	"VESA"	)    
	)u_lcd_packet_wrapper(    
	    .I_clk						(	S_clk_1x					),    
	    .I_rst						(	S_rx_rst					),    
	    
	    .I_lane0_shifter_bit0_data	(	S_lane0_shifter_bit0_data	),
	    .I_lane0_shifter_bit1_data	(	S_lane0_shifter_bit1_data	),    
	    .I_lane0_shifter_bit2_data	(	S_lane0_shifter_bit2_data	),    
	    .I_lane0_shifter_bit3_data	(	S_lane0_shifter_bit3_data	), 
	    .I_lane0_shifter_bit4_data	(	S_lane0_shifter_bit4_data	),
	    .I_lane0_shifter_bit5_data	(	S_lane0_shifter_bit5_data	),
	    .I_lane0_shifter_bit6_data	(	S_lane0_shifter_bit6_data	),
	    
	    .I_lane1_shifter_bit0_data	(	S_lane1_shifter_bit0_data	),
	    .I_lane1_shifter_bit1_data	(	S_lane1_shifter_bit1_data	),
	    .I_lane1_shifter_bit2_data	(	S_lane1_shifter_bit2_data	),
	    .I_lane1_shifter_bit3_data	(	S_lane1_shifter_bit3_data	),
	    .I_lane1_shifter_bit4_data	(	S_lane1_shifter_bit4_data	),
	    .I_lane1_shifter_bit5_data	(	S_lane1_shifter_bit5_data	),
	    .I_lane1_shifter_bit6_data	(	S_lane1_shifter_bit6_data	),  
	    
	    .I_lane2_shifter_bit0_data	(	S_lane2_shifter_bit0_data	),
	    .I_lane2_shifter_bit1_data	(	S_lane2_shifter_bit1_data	),
	    .I_lane2_shifter_bit2_data	(	S_lane2_shifter_bit2_data	),
	    .I_lane2_shifter_bit3_data	(	S_lane2_shifter_bit3_data	),
	    .I_lane2_shifter_bit4_data	(	S_lane2_shifter_bit4_data	),
	    .I_lane2_shifter_bit5_data	(	S_lane2_shifter_bit5_data	),
	    .I_lane2_shifter_bit6_data	(	S_lane2_shifter_bit6_data	), 
	    
	    .I_lane3_shifter_bit0_data	(	S_lane3_shifter_bit0_data	),
	    .I_lane3_shifter_bit1_data	(	S_lane3_shifter_bit1_data	),
	    .I_lane3_shifter_bit2_data	(	S_lane3_shifter_bit2_data	),
	    .I_lane3_shifter_bit3_data	(	S_lane3_shifter_bit3_data	),
	    .I_lane3_shifter_bit4_data	(	S_lane3_shifter_bit4_data	),
	    .I_lane3_shifter_bit5_data	(	S_lane3_shifter_bit5_data	),
	    .I_lane3_shifter_bit6_data	(	S_lane3_shifter_bit6_data	),    
	    
	    .O_shifter0_RGB_data		(	S_shifter0_RGB_data			),
	    .O_shifter0_DE				(	S_shifter0_DE				),
	    .O_shifter0_VS				(	S_shifter0_VS				),
	    .O_shifter0_HS				(	S_shifter0_HS				),  
        
	    .O_shifter1_RGB_data		(	S_shifter1_RGB_data			),
	    .O_shifter1_DE				(	S_shifter1_DE				),
	    .O_shifter1_VS				(	S_shifter1_VS				),
	    .O_shifter1_HS				(	S_shifter1_HS				),
        
	    .O_shifter2_RGB_data		(	S_shifter2_RGB_data			),
	    .O_shifter2_DE				(	S_shifter2_DE				),
	    .O_shifter2_VS				(	S_shifter2_VS				),
	    .O_shifter2_HS				(	S_shifter2_HS				),
        
	    .O_shifter3_RGB_data		(	S_shifter3_RGB_data			),
	    .O_shifter3_DE				(	S_shifter3_DE				),
	    .O_shifter3_VS				(	S_shifter3_VS				),
	    .O_shifter3_HS				(	S_shifter3_HS				),
        
	    .O_shifter4_RGB_data		(	S_shifter4_RGB_data			),
	    .O_shifter4_DE				(	S_shifter4_DE				),
	    .O_shifter4_VS				(	S_shifter4_VS				),
	    .O_shifter4_HS				(	S_shifter4_HS				),
        
	    .O_shifter5_RGB_data		(	S_shifter5_RGB_data			),
	    .O_shifter5_DE				(	S_shifter5_DE				),
	    .O_shifter5_VS				(	S_shifter5_VS				),
	    .O_shifter5_HS				(	S_shifter5_HS				),
        
	    .O_shifter6_RGB_data		(	S_shifter6_RGB_data			),
	    .O_shifter6_DE				(	S_shifter6_DE				),
	    .O_shifter6_VS				(	S_shifter6_VS				),
	    .O_shifter6_HS				(	S_shifter6_HS				)   
	);
    
    
    lcd_protocol_dect_wrapper u_lcd_dect_wrapper(
		.I_clk					(	S_clk_1x				),
		.I_rst					(	S_rx_rst				),
		                		                    		
		.I_shifter0_DE			(	S_shifter0_DE			),
		.I_shifter0_VS			(	S_shifter0_VS			),
		.I_shifter0_HS			(	S_shifter0_HS			),
		              			                    		
		.I_shifter1_DE			(	S_shifter1_DE			),
		.I_shifter1_VS			(	S_shifter1_VS			),
		.I_shifter1_HS			(	S_shifter1_HS			),
		              	                            		
		.I_shifter2_DE			(	S_shifter2_DE			),
		.I_shifter2_VS			(	S_shifter2_VS			),
		.I_shifter2_HS			(	S_shifter2_HS			),
		              			                    		
		.I_shifter3_DE			(	S_shifter3_DE			),
		.I_shifter3_VS			(	S_shifter3_VS			),
		.I_shifter3_HS			(	S_shifter3_HS			),
		              			                    		
		.I_shifter4_DE			(	S_shifter4_DE			),
		.I_shifter4_VS			(	S_shifter4_VS			),
		.I_shifter4_HS			(	S_shifter4_HS			),
		              			                    		
		.I_shifter5_DE			(	S_shifter5_DE			),
		.I_shifter5_VS			(	S_shifter5_VS			),
		.I_shifter5_HS			(	S_shifter5_HS			),
		              			                    		
		.I_shifter6_DE			(	S_shifter6_DE			),
		.I_shifter6_VS			(	S_shifter6_VS			),
		.I_shifter6_HS			(	S_shifter6_HS			),
		                        
		.O_shifter0_right_dect	(	S_shifter0_right_dect	),
		.O_shifter1_right_dect	(	S_shifter1_right_dect	),
		.O_shifter2_right_dect	(	S_shifter2_right_dect	),
		.O_shifter3_right_dect	(	S_shifter3_right_dect	),
		.O_shifter4_right_dect	(	S_shifter4_right_dect	),
		.O_shifter5_right_dect	(	S_shifter5_right_dect	),
		.O_shifter6_right_dect	(	S_shifter6_right_dect	)
	);
    
    
    
endmodule   