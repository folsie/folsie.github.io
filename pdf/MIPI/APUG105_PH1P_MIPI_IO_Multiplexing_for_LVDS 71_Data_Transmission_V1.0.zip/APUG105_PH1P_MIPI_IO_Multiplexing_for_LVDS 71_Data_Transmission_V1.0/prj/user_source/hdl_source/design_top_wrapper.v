module design_top_wrapper( 
    input	wire		I_sys_clk,
    
    inout 	wire      	IO_tx_clk_pad_n, 
    inout 	wire      	IO_tx_clk_pad_p, 
    inout 	wire[3:0] 	IO_tx_data_pad_n,
    inout 	wire[3:0] 	IO_tx_data_pad_p, 
    
    inout 	wire      	IO_rx_clk_pad_n, 
    inout 	wire      	IO_rx_clk_pad_p, 
    inout 	wire[3:0] 	IO_rx_data_pad_n,
    inout 	wire[3:0] 	IO_rx_data_pad_p		
                   
);
	
    
    localparam PROTOCOL = "VESA" ;		//协议 ： "VESA","JEIDA"
                                    					
                                    	
    wire		S_tx_clk_1x;				
    wire		S_tx_clk_1p75x;			
    wire		S_tx_clk_1p75x_mlclk;	
                                	
    wire		S_rx_clk_1x;			
    wire		S_rx_clk_3p5x;			
                                	
    wire[23:0]	S_source_data;			
    wire		S_source_vsync;			
    wire		S_source_hsync;			
    wire		S_source_de;			
    
    wire[7:0]   S_dpa_ready_rdata;
	wire[7:0]   S_dpa_ready_gdata;
	wire[7:0]   S_dpa_ready_bdata;
	wire		S_dpa_ready_done;  
    
    wire[7:0]	S_source_rdata;
    wire[7:0]	S_source_gdata;
    wire[7:0]	S_source_bdata;
    
    wire		S_tx_pll_ref;
    reg [7:0]	S_tx_rst_cnt = 8'd0;
    wire		S_tx_rst;
    wire		S_tx_pll_rst;
    reg	[29:0]	S_config_start_cnt;		
    wire		S_config_start;			
    wire		S_8b_clk; 
    
    wire		S_phy_to_pll_ref_clk;
    wire		S_pll_lock; 
    wire		S_rx_rst; 
    wire		S_pixel_clk;
    wire		S_sample_clk;
    
/*
	TX
*/
   


	tx_pll u_tx_pll(
		.I_clk		(	I_sys_clk		),
		                            	
		.O_rst		(	S_tx_rst		),
		.O_clk_1x	(	S_tx_clk_1x		),   
		.O_clk_3p5x	(	S_tx_clk_1p75x	)    
	); 
    
    
    PH1P_PHY_MLCLK #(
	  .GSR          ( "DISABLE"   			), //  "ENABLE", "DISABLE".        
	  .BYPASS       ( "DISABLE"   			)  //  "ENABLE", "DISABLE".        
	)u_PH1P_PHY_TX_MLCLK(           		
	  .ce           ( 1'b1         			),                                
	  .clkin        ( S_tx_clk_1p75x    	),                                
	  .clkout       ( S_tx_clk_1p75x_mlclk  )                                  
	); 
     
    
    always@(posedge S_8b_clk or posedge S_tx_rst)begin
    	if(S_tx_rst)
        	S_config_start_cnt <= 30'd0;
        else if(S_config_start_cnt == 30'd100_000_000)
        	S_config_start_cnt <= S_config_start_cnt;
        else
        	S_config_start_cnt <= S_config_start_cnt + 1'b1;
    end
    
    
    assign	S_config_start = (S_config_start_cnt == 30'd100_000_000) ? 1'b1 : 1'b0;   
    
    
    video_source #(
        .HTOTAL ( 237  ),  //937 == 800
        .HSA    ( 20   ),
        .HBP    ( 40   ),
        .HFP    ( 77   ),
 
        .VTOTAL ( 98   ),
        .VSA    ( 2    ),
        .VBP    ( 8    ),
        .VFP    ( 8    )
    )u_video_source(
        .I_clk          ( S_tx_clk_1x	    ),  
        .I_rst          ( S_tx_rst       	),

        .I_config_done  ( S_config_start	),

        .O_rgb24b_vsync ( S_source_vsync 	),
        .O_rgb24b_hsync ( S_source_hsync 	),
        .O_rgb24b_de    ( S_source_de    	),
        .O_rgb24b_data  ( S_source_data  	)
    );
    
    
    
    source_hs_de_test u_source_hs_de_test(
    	.I_clk				(	S_tx_clk_1x		),	
    	.I_rst				(	S_tx_rst		),
    	
    	.I_source_vsync		(	~S_source_vsync	),
    	.I_source_hsync		(	~S_source_hsync	),
    	.I_source_de		(	S_source_de		)
	);   
     
    
    lvds_screen_wrapper #(
         .PROTOCOL		 	(	PROTOCOL				)
    )u_lvds_screen_wrapper	(
         .I_pixel_clk       (	S_tx_clk_1x				),
         .I_dpll_ref_clk    (	S_tx_clk_1p75x_mlclk	),
         .I_rst_n          	(	~S_tx_rst				),
         .I_vs  			(	S_source_vsync			),
         .I_hs	  			(	S_source_hsync			),
         .I_de     			(	S_source_de				),        
         .I_rgb_data 		(	S_source_data			),
         
         .O_8b_clk			(	S_8b_clk				),
         
    	 .IO_tx_clk_pad_n	(	IO_tx_clk_pad_n			), 
    	 .IO_tx_clk_pad_p	(	IO_tx_clk_pad_p			), 
    	 .IO_tx_data_pad_n	(	IO_tx_data_pad_n		),
    	 .IO_tx_data_pad_p	(	IO_tx_data_pad_p		)
    );
    
    
 
    
/*
RX
*/	
    

    RX_PLL u_RX_PLL(
        .refclk   ( S_phy_to_pll_ref_clk ),

        .reset    ( 1'b0                 ),

        .clk0_out ( S_pixel_clk          ),
        .clk1_out ( S_sample_clk         ),

        .lock     ( S_pll_lock			)
    );


    assign S_rx_rst = ~S_pll_lock;

   
   lvds_rx_wrapper #(    
	    .PROTOCOL 				(	"VESA"				)    
	)u_lvds_rx_wrapper( 
   		.I_pixel_clk			(	S_pixel_clk			),
        .I_sample_clk			(	S_sample_clk		),
        .I_rst_n				(	~S_rx_rst			),
             		                         	
   		.IO_rx_clk_pad_n		(	IO_rx_clk_pad_n		), 
   		.IO_rx_clk_pad_p		(	IO_rx_clk_pad_p		), 
   		.IO_rx_data_pad_n		(	IO_rx_data_pad_n	),
   		.IO_rx_data_pad_p		(	IO_rx_data_pad_p	),
           
        .O_phy_to_pll_ref_clk	(	S_phy_to_pll_ref_clk),
           
        .O_de					(	S_DE	   			),
    	.O_hs					(	S_HS	   			),
    	.O_vs					(	S_VS	   			),
    	.O_rgb_data				(	S_RGB_data			)   
	);
   
    
    

endmodule
