module rgb_to_lvds_packet #(
    parameter PROTOCOL = "VESA" 
    )(
    input wire      I_clk,
    input wire		I_rst,
 
    input wire      I_video_vsync,
    input wire      I_video_hsync,
    input wire      I_video_de,
    input wire[7:0] I_video_r_data,
    input wire[7:0] I_video_g_data,
    input wire[7:0] I_video_b_data,

    output reg[6:0] O_tx_data_lane_0,
    output reg[6:0] O_tx_data_lane_1,
    output reg[6:0] O_tx_data_lane_2,
    output reg[6:0] O_tx_data_lane_3,
    output reg[6:0] O_tx_data_lane_clk
);


	generate

	     always @(posedge I_clk or posedge I_rst)begin
	     	if(I_rst)
             	begin
            		O_tx_data_lane_0   <= 'd0;
	        		O_tx_data_lane_1   <= 'd0;
	        		O_tx_data_lane_2   <= 'd0;
	        		O_tx_data_lane_3   <= 'd0;
	        		O_tx_data_lane_clk <= 'd0;
           		end
            else if(PROTOCOL == "VESA")
            	begin
	        		O_tx_data_lane_0   <= {I_video_g_data[0],I_video_r_data[5:0]};
	        		O_tx_data_lane_1   <= {I_video_b_data[1:0],I_video_g_data[5:1]};
	        		O_tx_data_lane_2   <= {I_video_de,I_video_vsync,I_video_hsync,I_video_b_data[5:2]};
	        		O_tx_data_lane_3   <= {1'b0,I_video_b_data[7:6],I_video_g_data[7:6],I_video_r_data[7:6]};
	        		O_tx_data_lane_clk <= 7'b1100011;
                end
            else if(PROTOCOL == "JEIDA")
            	begin
	        		O_tx_data_lane_0   <= {I_video_g_data[2],I_video_r_data[7:2]};
	        		O_tx_data_lane_1   <= {I_video_b_data[3:2],I_video_g_data[7:3]};
	        		O_tx_data_lane_2   <= {I_video_de,I_video_vsync,I_video_hsync,I_video_b_data[7:4]};
	        		O_tx_data_lane_3   <= {1'b0,I_video_b_data[1:0],I_video_g_data[1:0],I_video_r_data[1:0]};
	        		O_tx_data_lane_clk <= 7'b1100011;
                end
	    end

	endgenerate
    
endmodule