module dpa_ready_data(
    input wire        	  I_clk,
    input wire     		  I_rst,

    output reg[7:0]       O_dpa_ready_rdata,
    output reg[7:0]       O_dpa_ready_gdata,
    output reg[7:0]       O_dpa_ready_bdata,
    output reg			  O_dpa_ready_done
);
	
    reg	[15:0]	S_dpa_ready_cnt;
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_dpa_ready_cnt <= 'd0;
        else if(S_dpa_ready_cnt == 10000 )
        	S_dpa_ready_cnt <= S_dpa_ready_cnt;
        else 
        	S_dpa_ready_cnt <= S_dpa_ready_cnt + 1'b1;
    end
    
    
    assign S_dpa_ready_done = (S_dpa_ready_cnt == 10000 ) ? 1'b1 : 1'b0;
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	O_dpa_ready_rdata <= 8'd0;
        else if(S_dpa_ready_cnt < 10000 )
        	O_dpa_ready_rdata <= 8'hb8;
        else
        	O_dpa_ready_rdata <= 8'd0;
    end
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	O_dpa_ready_gdata <= 8'd0;
        else if(S_dpa_ready_cnt < 10000 )
        	O_dpa_ready_gdata <= 8'h8b;
        else
        	O_dpa_ready_gdata <= 8'd0;
    end


	always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	O_dpa_ready_bdata <= 8'd0;
        else if(S_dpa_ready_cnt < 10000 )
        	O_dpa_ready_bdata <= 8'haa;
        else
        	O_dpa_ready_bdata <= 8'd0;
    end
    
    
    always@(posedge I_clk)begin
    	O_dpa_ready_done <= S_dpa_ready_done;
    end
    
    

endmodule
