module lcd_shifter_packet#(
    parameter PROTOCOL = "VESA"
)(
    input	wire		I_clk,
    input	wire		I_rst,
    
    input	wire[6:0]	I_lane0_shifter_data,
    input	wire[6:0]	I_lane1_shifter_data,
    input	wire[6:0]	I_lane2_shifter_data,
    input	wire[6:0]	I_lane3_shifter_data,
  
    output	wire[23:0]	O_shifter_RGB_data,
    output	wire		O_shifter_DE,
    output	wire		O_shifter_VS,
    output	wire		O_shifter_HS  
       
);


/*
	shifter_bit0
*/	
	wire			S_shifter_NA;
    wire	[7:0]	S_shifter_R_data;
    wire	[7:0]	S_shifter_G_data;
    wire	[7:0]	S_shifter_B_data;

	generate      
		if(PROTOCOL == "VESA") 
    		begin
		    	assign	{S_shifter_G_data[0], S_shifter_R_data[5:0]} = I_lane0_shifter_data;
		    	assign	{S_shifter_B_data[1:0], S_shifter_G_data[5:1]} = I_lane1_shifter_data;
		    	assign	{O_shifter_DE, O_shifter_VS, O_shifter_HS, S_shifter_B_data[5:2]} = I_lane2_shifter_data;
		    	assign	{S_shifter_NA, S_shifter_B_data[7:6], S_shifter_G_data[7:6], S_shifter_R_data[7:6]} = I_lane3_shifter_data;
			end
    	else if(PROTOCOL == "JEIDA") 
    		begin
		    	assign {S_shifter_G_data[2], S_shifter_R_data[7:2]} = I_lane0_shifter_data;
		    	assign {S_shifter_B_data[3:2], S_shifter_G_data[7:3]} = I_lane1_shifter_data;
		    	assign {O_shifter_DE, O_shifter_VS, O_shifter_HS, S_shifter_B_data[7:4]} = I_lane2_shifter_data;
		    	assign {S_shifter_NA, S_shifter_B_data[1:0], S_shifter_G_data[1:0], S_shifter_R_data[1:0]} = I_lane3_shifter_data;
			end    
    	
	endgenerate

    assign	O_shifter_RGB_data = {S_shifter_R_data,S_shifter_G_data,S_shifter_B_data};    
    


endmodule
