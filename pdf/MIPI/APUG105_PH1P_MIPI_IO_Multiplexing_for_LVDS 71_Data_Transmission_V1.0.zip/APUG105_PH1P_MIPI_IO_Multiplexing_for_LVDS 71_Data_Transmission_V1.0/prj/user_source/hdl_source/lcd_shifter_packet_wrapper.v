module lcd_shifter_packet_wrapper#(
    parameter PROTOCOL = "VESA"
)(
    input	wire		I_clk,
    input	wire		I_rst,
    
    input	wire[6:0]	I_lane0_shifter_bit0_data,
    input	wire[6:0]	I_lane0_shifter_bit1_data,
    input	wire[6:0]	I_lane0_shifter_bit2_data,	
    input	wire[6:0]	I_lane0_shifter_bit3_data,
    input	wire[6:0]	I_lane0_shifter_bit4_data,
    input	wire[6:0]	I_lane0_shifter_bit5_data,
    input	wire[6:0]	I_lane0_shifter_bit6_data,
    
    input	wire[6:0]	I_lane1_shifter_bit0_data,
    input	wire[6:0]	I_lane1_shifter_bit1_data,
    input	wire[6:0]	I_lane1_shifter_bit2_data,
    input	wire[6:0]	I_lane1_shifter_bit3_data,
    input	wire[6:0]	I_lane1_shifter_bit4_data,
    input	wire[6:0]	I_lane1_shifter_bit5_data,
    input	wire[6:0]	I_lane1_shifter_bit6_data,  
    
    input	wire[6:0]	I_lane2_shifter_bit0_data,
    input	wire[6:0]	I_lane2_shifter_bit1_data,
    input	wire[6:0]	I_lane2_shifter_bit2_data,
    input	wire[6:0]	I_lane2_shifter_bit3_data,
    input	wire[6:0]	I_lane2_shifter_bit4_data,
    input	wire[6:0]	I_lane2_shifter_bit5_data,
    input	wire[6:0]	I_lane2_shifter_bit6_data, 
    
    input	wire[6:0]	I_lane3_shifter_bit0_data,
    input	wire[6:0]	I_lane3_shifter_bit1_data,
    input	wire[6:0]	I_lane3_shifter_bit2_data,
    input	wire[6:0]	I_lane3_shifter_bit3_data,
    input	wire[6:0]	I_lane3_shifter_bit4_data,
    input	wire[6:0]	I_lane3_shifter_bit5_data,
    input	wire[6:0]	I_lane3_shifter_bit6_data,    
    
    output	wire[23:0]	O_shifter0_RGB_data,
    output	wire		O_shifter0_DE,
    output	wire		O_shifter0_VS,
    output	wire		O_shifter0_HS,  
    output	wire[23:0]	O_shifter1_RGB_data,
    output	wire		O_shifter1_DE,
    output	wire		O_shifter1_VS,
    output	wire		O_shifter1_HS,
    output	wire[23:0]	O_shifter2_RGB_data,
    output	wire		O_shifter2_DE,
    output	wire		O_shifter2_VS,
    output	wire		O_shifter2_HS,
    output	wire[23:0]	O_shifter3_RGB_data,
    output	wire		O_shifter3_DE,
    output	wire		O_shifter3_VS,
    output	wire		O_shifter3_HS,
    output	wire[23:0]	O_shifter4_RGB_data,
    output	wire		O_shifter4_DE,
    output	wire		O_shifter4_VS,
    output	wire		O_shifter4_HS,
    output	wire[23:0]	O_shifter5_RGB_data,
    output	wire		O_shifter5_DE,
    output	wire		O_shifter5_VS,
    output	wire		O_shifter5_HS,
    output	wire[23:0]	O_shifter6_RGB_data,
    output	wire		O_shifter6_DE,
    output	wire		O_shifter6_VS,
    output	wire		O_shifter6_HS
    
);



	lcd_shifter_packet#(
    	.PROTOCOL 				(	"VESA"						)
	)u_shifter0_data(
	   	.I_clk					(	I_clk						),
	   	.I_rst					(	I_rst						),
	   	
	   	.I_lane0_shifter_data	(	I_lane0_shifter_bit0_data	),
	   	.I_lane1_shifter_data	(	I_lane1_shifter_bit0_data	),
	   	.I_lane2_shifter_data	(	I_lane2_shifter_bit0_data	),
	   	.I_lane3_shifter_data	(	I_lane3_shifter_bit0_data	),
	   	
	   	.O_shifter_RGB_data		(	O_shifter0_RGB_data			),
	   	.O_shifter_DE			(	O_shifter0_DE				),
	   	.O_shifter_VS			(	O_shifter0_VS				),
	   	.O_shifter_HS			(	O_shifter0_HS				)  
	       
	);
    
    
    lcd_shifter_packet#(
    	.PROTOCOL 				(	"VESA"						)
	)u_shifter1_data(
	   	.I_clk					(	I_clk						),
	   	.I_rst					(	I_rst						),
	   	
	   	.I_lane0_shifter_data	(	I_lane0_shifter_bit1_data	),
	   	.I_lane1_shifter_data	(	I_lane1_shifter_bit1_data	),
	   	.I_lane2_shifter_data	(	I_lane2_shifter_bit1_data	),
	   	.I_lane3_shifter_data	(	I_lane3_shifter_bit1_data	),
	   	
	   	.O_shifter_RGB_data		(	O_shifter1_RGB_data			),
	   	.O_shifter_DE			(	O_shifter1_DE				),
	   	.O_shifter_VS			(	O_shifter1_VS				),
	   	.O_shifter_HS			(	O_shifter1_HS				)  
	       
	);
    
    
    lcd_shifter_packet#(
    	.PROTOCOL 				(	"VESA"						)
	)u_shifter2_data(
	   	.I_clk					(	I_clk						),
	   	.I_rst					(	I_rst						),
	   	
	   	.I_lane0_shifter_data	(	I_lane0_shifter_bit2_data	),
	   	.I_lane1_shifter_data	(	I_lane1_shifter_bit2_data	),
	   	.I_lane2_shifter_data	(	I_lane2_shifter_bit2_data	),
	   	.I_lane3_shifter_data	(	I_lane3_shifter_bit2_data	),
	   	
	   	.O_shifter_RGB_data		(	O_shifter2_RGB_data			),
	   	.O_shifter_DE			(	O_shifter2_DE				),
	   	.O_shifter_VS			(	O_shifter2_VS				),
	   	.O_shifter_HS			(	O_shifter2_HS				)  
	       
	);
    
    
    lcd_shifter_packet#(
    	.PROTOCOL 				(	"VESA"						)
	)u_shifter3_data(
	   	.I_clk					(	I_clk						),
	   	.I_rst					(	I_rst						),
	   	
	   	.I_lane0_shifter_data	(	I_lane0_shifter_bit3_data	),
	   	.I_lane1_shifter_data	(	I_lane1_shifter_bit3_data	),
	   	.I_lane2_shifter_data	(	I_lane2_shifter_bit3_data	),
	   	.I_lane3_shifter_data	(	I_lane3_shifter_bit3_data	),
	   	
	   	.O_shifter_RGB_data		(	O_shifter3_RGB_data			),
	   	.O_shifter_DE			(	O_shifter3_DE				),
	   	.O_shifter_VS			(	O_shifter3_VS				),
	   	.O_shifter_HS			(	O_shifter3_HS				)  
	       
	);
    
    
    lcd_shifter_packet#(
    	.PROTOCOL 				(	"VESA"						)
	)u_shifter4_data(
	   	.I_clk					(	I_clk						),
	   	.I_rst					(	I_rst						),
	   	
	   	.I_lane0_shifter_data	(	I_lane0_shifter_bit4_data	),
	   	.I_lane1_shifter_data	(	I_lane1_shifter_bit4_data	),
	   	.I_lane2_shifter_data	(	I_lane2_shifter_bit4_data	),
	   	.I_lane3_shifter_data	(	I_lane3_shifter_bit4_data	),
	   	
	   	.O_shifter_RGB_data		(	O_shifter4_RGB_data			),
	   	.O_shifter_DE			(	O_shifter4_DE				),
	   	.O_shifter_VS			(	O_shifter4_VS				),
	   	.O_shifter_HS			(	O_shifter4_HS				)  
	       
	);
    
    
    lcd_shifter_packet#(
    	.PROTOCOL 				(	"VESA"						)
	)u_shifter5_data(
	   	.I_clk					(	I_clk						),
	   	.I_rst					(	I_rst						),
	   	
	   	.I_lane0_shifter_data	(	I_lane0_shifter_bit5_data	),
	   	.I_lane1_shifter_data	(	I_lane1_shifter_bit5_data	),
	   	.I_lane2_shifter_data	(	I_lane2_shifter_bit5_data	),
	   	.I_lane3_shifter_data	(	I_lane3_shifter_bit5_data	),
	   	
	   	.O_shifter_RGB_data		(	O_shifter5_RGB_data			),
	   	.O_shifter_DE			(	O_shifter5_DE				),
	   	.O_shifter_VS			(	O_shifter5_VS				),
	   	.O_shifter_HS			(	O_shifter5_HS				)  
	       
	);
    
    
    lcd_shifter_packet#(
    	.PROTOCOL 				(	"VESA"						)
	)u_shifter6_data(
	   	.I_clk					(	I_clk						),
	   	.I_rst					(	I_rst						),
	   	
	   	.I_lane0_shifter_data	(	I_lane0_shifter_bit6_data	),
	   	.I_lane1_shifter_data	(	I_lane1_shifter_bit6_data	),
	   	.I_lane2_shifter_data	(	I_lane2_shifter_bit6_data	),
	   	.I_lane3_shifter_data	(	I_lane3_shifter_bit6_data	),
	   	
	   	.O_shifter_RGB_data		(	O_shifter6_RGB_data			),
	   	.O_shifter_DE			(	O_shifter6_DE				),
	   	.O_shifter_VS			(	O_shifter6_VS				),
	   	.O_shifter_HS			(	O_shifter6_HS				)  
	       
	);

	

endmodule
