module lcd_protocol_dect_wrapper(
    input	wire		I_clk,
    input	wire		I_rst,
    
    input	wire		I_shifter0_DE,
    input	wire		I_shifter0_HS,
    input	wire		I_shifter0_VS,
    
    input	wire		I_shifter1_DE,
    input	wire		I_shifter1_HS,
    input	wire		I_shifter1_VS,
    
    input	wire		I_shifter2_DE,
    input	wire		I_shifter2_HS,
    input	wire		I_shifter2_VS,
    
    input	wire		I_shifter3_DE,
    input	wire		I_shifter3_HS,
    input	wire		I_shifter3_VS,
    
    input	wire		I_shifter4_DE,
    input	wire		I_shifter4_HS,
    input	wire		I_shifter4_VS,
    
    input	wire		I_shifter5_DE,
    input	wire		I_shifter5_HS,
    input	wire		I_shifter5_VS,
    
    input	wire		I_shifter6_DE,
    input	wire		I_shifter6_HS,
    input	wire		I_shifter6_VS,
    
    output	wire		O_shifter0_right_dect,
    output	wire		O_shifter1_right_dect,
    output	wire		O_shifter2_right_dect,
    output	wire		O_shifter3_right_dect,
    output	wire		O_shifter4_right_dect,
    output	wire		O_shifter5_right_dect,
    output	wire		O_shifter6_right_dect
);
               
     
    lcd_hs_dect u_lcd_shifter0_dect(
    	.I_clk					(	I_clk					),
    	.I_rst					(	I_rst					),
    	                                                	
    	.I_shifter_DE			(	I_shifter0_DE			),
    	.I_shifter_HS			(	I_shifter0_HS			),
    	.I_shifter_VS			(	~I_shifter0_VS			),
    	
    	.O_shifter_right_dect	(	O_shifter0_right_dect	)	
	);
    
    
    lcd_hs_dect u_lcd_shifter1_dect(
    	.I_clk					(	I_clk					),
    	.I_rst					(	I_rst					),
    	                                                	
    	.I_shifter_DE			(	I_shifter1_DE			),
    	.I_shifter_HS			(	I_shifter1_HS			),
    	.I_shifter_VS			(	~I_shifter1_VS			),
    	
    	.O_shifter_right_dect	(	O_shifter1_right_dect	)	
	);
    
    
    lcd_hs_dect u_lcd_shifter2_dect(
    	.I_clk					(	I_clk					),
    	.I_rst					(	I_rst					),
    	                                                	
    	.I_shifter_DE			(	I_shifter2_DE			),
    	.I_shifter_HS			(	I_shifter2_HS			),
    	.I_shifter_VS			(	~I_shifter2_VS			),
    	
    	.O_shifter_right_dect	(	O_shifter2_right_dect	)	
	);
    
    
    lcd_hs_dect u_lcd_shifter3_dect(
    	.I_clk					(	I_clk					),
    	.I_rst					(	I_rst					),
    	                                                	
    	.I_shifter_DE			(	I_shifter3_DE			),
    	.I_shifter_HS			(	I_shifter3_HS			),
    	.I_shifter_VS			(	~I_shifter3_VS			),
    	
    	.O_shifter_right_dect	(	O_shifter3_right_dect	)	
	); 
    
    
    lcd_hs_dect u_lcd_shifter4_dect(
    	.I_clk					(	I_clk					),
    	.I_rst					(	I_rst					),
    	                                                	
    	.I_shifter_DE			(	I_shifter4_DE			),
    	.I_shifter_HS			(	I_shifter4_HS			),
    	.I_shifter_VS			(	~I_shifter4_VS			),
    	
    	.O_shifter_right_dect	(	O_shifter4_right_dect	)	
	);   
    
      
    lcd_hs_dect u_lcd_shifter5_dect(
    	.I_clk					(	I_clk					),
    	.I_rst					(	I_rst					),
    	                                                	
    	.I_shifter_DE			(	I_shifter5_DE			),
    	.I_shifter_HS			(	I_shifter5_HS			),
    	.I_shifter_VS			(	~I_shifter5_VS			),
    	
    	.O_shifter_right_dect	(	O_shifter5_right_dect	)	
	); 
    
    
    lcd_hs_dect u_lcd_shifter6_dect(
    	.I_clk					(	I_clk					),
    	.I_rst					(	I_rst					),
    	                                                	
    	.I_shifter_DE			(	I_shifter6_DE			),
    	.I_shifter_HS			(	I_shifter6_HS			),
    	.I_shifter_VS			(	~I_shifter6_VS			),
    	
    	.O_shifter_right_dect	(	O_shifter6_right_dect	)	
	);            
               
               

endmodule
