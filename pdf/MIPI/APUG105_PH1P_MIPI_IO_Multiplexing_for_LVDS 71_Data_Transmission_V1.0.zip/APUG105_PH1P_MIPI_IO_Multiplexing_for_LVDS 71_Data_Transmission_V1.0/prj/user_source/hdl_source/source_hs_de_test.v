module source_hs_de_test(
    input wire       I_clk,
    input wire       I_rst,

    input wire       I_source_vsync,
    input wire       I_source_hsync,
    input wire       I_source_de
);

	reg	[9:0]		S_de_cnt;
    reg	[9:0]		S_hs_cnt;
    reg				S_source_hs_d;
    wire			S_source_hs_n_edge;
    
    
    reg	[7:0]	S_valid_col;	//synthesis keep = 1
    reg	[7:0]	S_col;			//synthesis keep = 1
    reg [7:0]	S_line;			//synthesis keep = 1
    reg [7:0]	S_valid_line;
    reg			S_HS_d;
    wire		S_HS_n_edge;	//synthesis keep = 1
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_valid_col <= 'd0;
        else if(I_source_de)
        	S_valid_col <= S_valid_col + 1'b1;
        else
        	S_valid_col <= 'd0;
    end
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_col <= 'd0;
        else if(I_source_hsync)
        	S_col <= S_col + 1'b1;
        else
        	S_col <= 'd0;
    end
     
    
    always@(posedge I_clk)begin
        	S_HS_d <= I_source_hsync;
    end
    
    
    assign	S_HS_n_edge = ~I_source_hsync && S_HS_d;
    
    
    always@(posedge I_clk or posedge I_rst)begin
    	if(I_rst)
        	S_line <= 'd0;
        else if(I_source_vsync)
        	if(S_HS_n_edge)						
        		S_line <= S_line + 1'b1;
            else
            	S_line <= S_line;
        else
        	S_line <= 'd0;
    end    


endmodule
