create_clock -name {I_sys_clk} -period 40.000 -waveform {0.000 20.000} [get_ports {I_sys_clk}]
create_clock -name {MIPI_CLK_LANE} -period 13.470 -waveform {0.000 6.735} [get_ports {IO_rx_clk_pad_p}]

derive_clocks

rename_clock -name {S_rx_pixel_clk} [get_clocks {u_RX_PLL/ph1p_phy_pll_wrapper_fe53a3c83fa7_Inst/u_PH1P_PHY_PLL.clkc[0]}]
rename_clock -name {S_rx_sample_clk} [get_clocks {u_RX_PLL/ph1p_phy_pll_wrapper_fe53a3c83fa7_Inst/u_PH1P_PHY_PLL.clkc[1]}]
rename_clock -name {S_tx_7b_clk} [get_clocks {u_tx_pll/u_tpll/ph1p_phy_pll_wrapper_d8cf02616d56_Inst/u_PH1P_PHY_PLL.clkc[0]}]
rename_clock -name {S_tx_dpll_ref_clk} [get_clocks {u_tx_pll/u_tpll/ph1p_phy_pll_wrapper_d8cf02616d56_Inst/u_PH1P_PHY_PLL.clkc[1]}]
set_clock_groups -exclusive -group [get_clocks {S_tx_7b_clk}] -group [get_clocks {S_tx_dpll_ref_clk}]
set_clock_groups -exclusive -group [get_clocks {S_tx_7b_clk}] -group [get_clocks {u_lvds_screen_wrapper/u_PH1P_LOGIC_DPHY_LVDS_TX.o_fabric_div4_8_clk}]
