/************************************************************\
**	Copyright (c) 2012-2024 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: Dec 13 2024 10:52:53
**	TD version	:	6.1.117420
\************************************************************/
`timescale 1 ns / 1 ps
module w7_d512_fifo
(
  input                         rst,
  input                         clkw,
  input                         clkr,
  input                         we,
  input   [6:0]                 di,
  input                         re,
  output  [6:0]                 dout,
  output                        valid,
  output                        full_flag,
  output                        empty_flag,
  output                        afull,
  output                        aempty,
  output  [8:0]                 wrusedw,
  output  [8:0]                 rdusedw
);

  soft_fifo_al_1edd9e9c7338
  #(
      .DATA_WIDTH_W(7),
      .DATA_WIDTH_R(7),
      .ADDR_WIDTH_W(9),
      .ADDR_WIDTH_R(9),
      .AL_FULL_NUM(508),
      .AL_EMPTY_NUM(3),
      .SHOW_AHEAD_EN(0),
      .OUTREG_EN("NOREG")
  )soft_fifo_al_1edd9e9c7338_Inst
  (
      .rst(rst),
      .clkw(clkw),
      .clkr(clkr),
      .we(we),
      .di(di),
      .re(re),
      .dout(dout),
      .valid(valid),
      .full_flag(full_flag),
      .empty_flag(empty_flag),
      .afull(afull),
      .aempty(aempty),
      .wrusedw(wrusedw),
      .rdusedw(rdusedw)
  );
endmodule
