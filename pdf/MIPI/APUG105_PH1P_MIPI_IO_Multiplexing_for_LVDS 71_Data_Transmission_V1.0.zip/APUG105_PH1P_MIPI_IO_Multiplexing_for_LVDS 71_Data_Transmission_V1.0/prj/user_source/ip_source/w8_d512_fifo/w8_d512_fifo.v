/************************************************************\
**	Copyright (c) 2012-2024 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: Dec 23 2024 12:32:43
**	TD version	:	6.1.117420
\************************************************************/
`timescale 1 ns / 1 ps
module w8_d512_fifo
(
  input                         rst,
  input                         clkw,
  input                         clkr,
  input                         we,
  input   [7:0]                 di,
  input                         re,
  output  [7:0]                 dout,
  output                        valid,
  output                        full_flag,
  output                        empty_flag,
  output                        afull,
  output                        aempty,
  output  [8:0]                 wrusedw,
  output  [8:0]                 rdusedw
);

  soft_fifo_al_1edd9e9c7338
  #(
      .DATA_WIDTH_W(8),
      .DATA_WIDTH_R(8),
      .ADDR_WIDTH_W(9),
      .ADDR_WIDTH_R(9),
      .AL_FULL_NUM(253),
      .AL_EMPTY_NUM(2),
      .SHOW_AHEAD_EN(0),
      .OUTREG_EN("NOREG")
  )soft_fifo_al_1edd9e9c7338_Inst
  (
      .rst(rst),
      .clkw(clkw),
      .clkr(clkr),
      .we(we),
      .di(di),
      .re(re),
      .dout(dout),
      .valid(valid),
      .full_flag(full_flag),
      .empty_flag(empty_flag),
      .afull(afull),
      .aempty(aempty),
      .wrusedw(wrusedw),
      .rdusedw(rdusedw)
  );
endmodule
