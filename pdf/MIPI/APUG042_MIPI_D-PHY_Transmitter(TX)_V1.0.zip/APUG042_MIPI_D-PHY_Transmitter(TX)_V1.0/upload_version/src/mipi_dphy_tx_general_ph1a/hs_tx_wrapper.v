module hs_tx_wrapper #(
    parameter LANE_NUM          = 4,

	parameter HS_TX_FIFO_TYPE   = "BRAM",

	parameter CLK_LANE_MODE     = "INTERRUPT", ///"CONTINUE","INTERRUPT"

    parameter T_DATA_LPX        = 4,
    parameter T_DATA_HS_PREPARE = 4,
    parameter T_DATA_HS_ZERO    = 10,
    parameter T_DATA_HS_TRAIL   = 10,
    parameter T_CLK_LPX         = 4,
    parameter T_CLK_PREPARE     = 4,
    parameter T_CLK_ZERO        = 10,
    parameter T_CLK_PRE         = 10,
    parameter T_CLK_POST        = 10,
    parameter T_CLK_TRAIL       = 10
    )(
    input wire                 I_clk,
    input wire                 I_clk_x2,
    input wire                 I_clk_x4,
    input wire                 I_clk_x4_90d,
    input wire                 I_rst,
           
    input wire                 I_tx_valid,
    input wire[LANE_NUM*8-1:0] I_tx_data,    ///[31:24] -> lane3  
                                             ///[23:16] -> lane2  
                                             ///[15:8]  -> lane1  
                                             ///[7:0]   -> lane0
    input wire                 I_tx_last,
    output reg                 O_tx_ready,  

    output wire                O_clk_hs_p,
    output wire[LANE_NUM-1:0]  O_data_hs_p,

    output wire                O_clk_lp_p,
    output wire                O_clk_lp_n,
    output wire[LANE_NUM-1:0]  O_data_lp_p,
    output wire[LANE_NUM-1:0]  O_data_lp_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
S5jFkJpz+MJDn5artz/lgKmM0PBhnoLWNSlpzXuppHucufD1EpEjTU0tGVbUZEKf
WgJ6ZwWOOP3TW8j+hgaNhg9hk41hWyCP33i+tlvZZn8fILFT437F3CJK1+QfAZ4c
V8ZFr+n/BOSPCfqG9puA6Cs2ujqxldHpv0gDd3DlyU8=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 880)
`pragma protect data_block
ZGpZRU9OU1VjdTc2QjU4eLTFmiU0hzPq0xuW8y5TKB68x0Prk2c+oWR9l4UFteKk
Xl9Z7QMOvbU6axsNrGlHz28JGC3fls1P0I3POA2hxhavb5/Z9TtT06aELTHD17XZ
Nn1PhLqGee39wZz3WxUVccSUWml8600uKXaYTHCe7fTWAktL3IfvgY/wTQwmWD2s
MuXB1zbVnL6ewpMG/ADzwghJulUUyodxRgc/+p6ZNI89/toHwNgNcNceCQD4SZot
F5sIuPTohAlBfi0f0ra7kGROxFjKRwTNjrSFAz/xMztSzhAkvflfTJW9WEqGZ13Y
f7+6c6TfDqiEX3AyCrHrf8JAvhwLgqk1ZcVlDmvXb4o5/uO28HH5DwVFukALg0Ly
i4BJNUS7BCur52ytLOhFmRldNnQnFDZwbOBnKNEiK1lpwCOT1XPq6jgB9rjvDeXp
VS3r1y1HperB0UzlrtT8i6hD1JCGahnKQ8WP4qbyKUwGqyFPhYonYEQ3EvcW5jQa
DoYCJ4dM37RSACQZfV1mmKscu9Fkl/HMFLMipsPah0+XNVRHEkpfINidTJlSI5sy
Iz5IrTSjeepdGket29WUblRGOL7HMYcaWlrDmQdJT8duUEYKYUA/0MW2jpI/hLw7
RvhNFsvf8e89pWC199o6tNYKu7gYH6p1AgxTojzOJzTTpvuYOXTZoYIFMXK+y29V
jQOp97asBdqZe3rHa/7NM6FgCFFMj93E4JXo2RlsUcYZIVitoQpZmemC0JdWTAor
v8RgMNNcVOF9j9lg1m8P2DGe8LVtLTK9BLeSGYkCPgMEet50LdWisJU2NHJbduws
VSNIHSi/jXgMkpDrz+2oyWLklFvRbrZAU0p1pqsml0iamFM51dn3B2IRiSuegyjq
UZr3woXCpg0RfMkvTCQZfzjmWz4BbmbTLz5bU+P/IvdGDazMr8X5rTEcrAkyJ9E4
XXRfFzpbK+2xmE+k/aBlihscNkEA/aOTaoGLuOUgCpHMqHVQEEc4mZPrWiR95GWp
RDQfqZyKP99R8uGR4wFaAasVJfQ2koxHCmGuDB640hRWQCAtxxgo0iGH63M8dFj+
TWhs3djbXzsGOmeVr3FlbUl08M2UnQNAZthYS1RnaeCaIsMEnpP/H5BDvuW0w3U0
Mh2rnPcQDRfhi1y8ZjLhvQ==
`pragma protect end_protected


    hs_tx_controler#(
		.CLK_LANE_MODE     ( CLK_LANE_MODE     ),
		
        .T_DATA_LPX        ( T_DATA_LPX        ),
        .T_DATA_HS_PREPARE ( T_DATA_HS_PREPARE ),
        .T_DATA_HS_ZERO    ( T_DATA_HS_ZERO    ),
        .T_DATA_HS_TRAIL   ( T_DATA_HS_TRAIL   ),
        .T_CLK_LPX         ( T_CLK_LPX         ),
        .T_CLK_PREPARE     ( T_CLK_PREPARE     ),
        .T_CLK_ZERO        ( T_CLK_ZERO        ),
        .T_CLK_PRE         ( T_CLK_PRE         ),
        .T_CLK_POST        ( T_CLK_POST        ),
        .T_CLK_TRAIL       ( T_CLK_TRAIL       )
    )u_hs_tx_controler(
        .I_clk             ( I_clk             ),
        .I_rst             ( I_rst             ),

        .I_tx_start        ( S_tx_start        ),
        .I_hs_data_end     ( S_hs_data_end[0]  ),

        .O_lane_state_code ( S_lane_state_code ),
        .O_tx_end          ( S_tx_end          )
    );



    clk_lane_wrapper #(
    	.CLK_LANE_MODE( CLK_LANE_MODE )
	)u_clk_lane_wrapper(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_clk_x4_90d      ( I_clk_x4_90d      ),

        .I_rst             ( I_rst             ),
                                               
        .I_lane_state_code ( S_lane_state_code ),
                                               
        .O_clk_lp_p        ( O_clk_lp_p        ),
        .O_clk_lp_n        ( O_clk_lp_n        ),
                                               
        .O_clk_hs_p        ( O_clk_hs_p        )
    );

    genvar i;
    generate
        for(i = 0; i < LANE_NUM; i = i+1) begin :   MIPI_DATA_LANE_GEN
            data_lane_wrapper #(   
				.FIFO_TYPE  ( HS_TX_FIFO_TYPE ),            
				.DRAM_DEPTH ( DRAM_DEPTH      )     
			)u_data_lane_wrapper(
                .I_clk             ( I_clk                ),
                .I_clk_x2          ( I_clk_x2             ),
                .I_clk_x4          ( I_clk_x4             ),
                .I_rst             ( I_rst                ),

                .I_tx_valid        ( I_tx_valid           ),
                .I_tx_data         ( I_tx_data[8*i+7:8*i] ),
                .I_tx_last         ( I_tx_last            ),

                .I_lane_state_code ( S_lane_state_code    ),

                .O_hs_data_end     ( S_hs_data_end[i]     ),

                .O_data_hs_p       ( O_data_hs_p[i]       ),

                .O_data_lp_p       ( O_data_lp_p[i]       ),
                .O_data_lp_n       ( O_data_lp_n[i]       )
            );
        end
    endgenerate

endmodule