module dphy_tx_fifo #(
    parameter FIFO_TYPE  = "BRAM",  ///"BRAM","DRAM"
    parameter DRAM_DEPTH = 40
    )(
    input wire       I_clk,
    input wire       I_rst,

    input wire       I_fifo_wr_en,
    input wire[7:0]  I_fifo_wr_data,

    input wire       I_fifo_rd_en,
    output wire[7:0] O_fifo_rd_data
);

    localparam DRAM_ADDR_WIDTH = DRAM_DEPTH == 2                        ? 1 :
                                 DRAM_DEPTH >= 3  && DRAM_DEPTH <= 4    ? 2 :
                                 DRAM_DEPTH >= 5  && DRAM_DEPTH <= 8    ? 3 :
                                 DRAM_DEPTH >= 9  && DRAM_DEPTH <= 16   ? 4 :
                                 DRAM_DEPTH >= 17 && DRAM_DEPTH <= 32   ? 5 :
                                 DRAM_DEPTH >= 33 && DRAM_DEPTH <= 64   ? 6 :
                                 DRAM_DEPTH >= 65 && DRAM_DEPTH <= 128  ? 7 :
                                 DRAM_DEPTH >= 129 && DRAM_DEPTH <= 256 ? 8 : 0;

    generate begin
        if(FIFO_TYPE == "BRAM") 
            begin
                d1024_w8_fifo u_d1024_w8_fifo(
                    .clk        ( I_clk          ),
                    .rst        ( I_rst          ),

                    .we         ( I_fifo_wr_en   ),
                    .di         ( I_fifo_wr_data ),
                    .full_flag  (   ),

                    .re         ( I_fifo_rd_en   ),
                    .dout       ( O_fifo_rd_data ),
                    .empty_flag (   )
                );
            end
        else 
            begin
                reg[DRAM_ADDR_WIDTH-1 : 0] S_dram_wr_addr;
                reg[DRAM_ADDR_WIDTH-1 : 0] S_dram_rd_addr;
				wire[7:0]				   S_dram_rd_data;
				reg[7:0]				   S_dram_rd_data_1d;

                always @(posedge I_clk or posedge I_rst) begin
                    if(I_rst)
                        S_dram_wr_addr <= 'd0;
                    else
                        if(I_fifo_wr_en)
                            if(S_dram_wr_addr == DRAM_DEPTH-1)
                                S_dram_wr_addr <= 'd0;
                            else
                                S_dram_wr_addr <= S_dram_wr_addr + 1'b1;
                        else
                            S_dram_wr_addr <= S_dram_wr_addr;
                end

                always @(posedge I_clk or posedge I_rst) begin
                    if(I_rst)
                        S_dram_rd_addr <= 'd0;
                    else
                        if(I_fifo_rd_en)
                            if(S_dram_rd_addr == DRAM_DEPTH-1)
                                S_dram_rd_addr <= 'd0;
                            else
                                S_dram_rd_addr <= S_dram_rd_addr + 1'b1;
                        else
                            S_dram_rd_addr <= S_dram_rd_addr;
                end

				always @ (posedge I_clk) begin
					S_dram_rd_data_1d <= S_dram_rd_data;
				end 

				assign O_fifo_rd_data = S_dram_rd_data_1d;

                PH1_LOGIC_DRAM #(
                    .INIT_FILE    ( "NONE"          ),
                    .DATA_WIDTH_W ( 8               ),
                    .ADDR_WIDTH_W ( DRAM_ADDR_WIDTH ),
                    .DATA_DEPTH_W ( DRAM_DEPTH      ),
                    .DATA_WIDTH_R ( 8               ),
                    .ADDR_WIDTH_R ( DRAM_ADDR_WIDTH ),
                    .DATA_DEPTH_R ( DRAM_DEPTH      )
                )u_PH_LOGIC_DRAM(
                    .wclk  ( I_clk          ),
                    .di    ( I_fifo_wr_data ),
                    .waddr ( S_dram_wr_addr ),
                    .we    ( I_fifo_wr_en   ),
                    .raddr ( S_dram_rd_addr ),
                    .dout  ( S_dram_rd_data )
                );
            end
    end
    endgenerate
    
    
endmodule