

module clk_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_lp_p,
    output wire     O_clk_lp_n
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
kWp0U+0St0IDOrxWfXVjaWoGUzoa7WBGChLTKOslvQ9/2k8eOydINZE7yQ5iUAKb
KSV7Swq4ZMcWAatMu0gNP57x8QPLKRHNTR0L/cAzGdjsQaojJXGA+ButuhbsSKLE
VFc9dFWcl6f6MV9rSW0hFUx2KCxiy8m9VZKEI442j+o=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1824)
`pragma protect data_block
TmVCaUJIVUhHN05oTlpxVU2/HyIC+i/0GsrfGa1LQFgAuCXCpdnGMx6UbFFQTVKC
FWxWk/SLETmvHDhW0QCNTnn5I+qSYzi7b6mMfJeMCzr8nSDs3ZXRsuU/tu4UYtpz
5Sp0VAV5Gnqvh4aIINA5Eqz/jPwvUcC897GLv3rLqM+Ct/sQV8L4JZEdFy+Wia8h
SDO+CJ0FFkuwIWQH3aZLqVhwnVlAtxaH5MX6o+/4sKwW9C/coI4F+cmVczaYhGgY
Jm3hMBqPeLnR9vYoMjYzqSI693pymTRbust3L0GftzXQHvScgoGs9XVUGZ8HL/50
W0MtkZNpAakRC2lWv0SIG13q8fEdJzicJHw/xOFnkNqdkHxyvB12gCW2bqObVhF9
VEoM4QUPMElrf4aQ/SFDwaUXRiXfPURiHpQfJ3KUhYKC0qmL24D0jC9gVNx0l5LZ
5F399EV2fIaAAISQje/4A4MUxzIPx+RX6NiCVrj7MkAlmn0ZXg6U9iHoo3GP+mrc
06ocoGTMdgrcLCrUuDsbCdrmfJxwNsGhanZNFe1U94xdFe8LS2HpXBD5tERy2U3k
pwdzq9Qe8PWQd2k78mAbArqnSAkonq1LYeq1sp24WiITbUcq7pKMXhYo59YzuRiO
6OZop6HwW21k3/8ZLZk6QowHY5lnirfyrKnClvXQLk5DM+bYB/kIuZ/9wzBsT1LD
1xaN9nSwQSGsaKc/ZF6vuw3cvFx+swZz3cltXoVozqxxsbIL9lfb5XMl5fZby8Te
SuB2O5ZgEHdDKKTjoY/5cINMYNjX26MDnjbzIqNhFO7qdHM2jKClqPF8lgtv649m
/ehXbZ81qINXPdBgYYVKfu39OaGaP6J+ocReiNkY2iyFq+NPSW3sm/OnV1bmQ0xZ
A1piYch9tgriRkG4wV0yW8f9t7w2BbEpS9+0EXQqcaIwBdGjLxEMz/XGJZzaMuqd
V9ty4NFOq2ZcWCV12pOTLv8nfW0agAE2M6KdHAXwtrwwgUCdy4NcivXZ+QEfr8UG
yn1rM+5OZWikxaiWt3NvTtJc8pbefPtWCMRzu2HCzmzfn0BWVc8Mh9d4Nojfjvbj
8JU80PZ0Zf9O7FfDK8H5X7FEFbvpo2aJKEUTbBWmf22YIk6mkaKrT5kvIs2U0o/z
NWDK9I0mVtubLBWF52YiDMaDs7yDKkCPIQvKqEILgcAHP91i2umyeiw7MWszHBsH
59x2Y8NQthW8O6hH61AEjZJRfn87jNG3O2a9e4WTapfiYJ/B7COQrHpNcqrSitz6
n3jMu34HE8PgHRv+TsML5fxKcZiCbijgWqCokp0c4GXeOEqMlfF3Lo8MDeUhLe+r
Gxug0/h6i81Vvqf/uzJBfa8FKDtCm6lh5MaYL+N+6nKiZh19riNS07Klbrsx/ePz
Ai1o4wKv2S+LH3Wnh9yP5YIOHhmCZcuC0XnDvwLOllTxvI4r54B8LojO9BUej2uf
YZPMA8tYMwzvnvZAZsfZEodDZQrclsyV57DX4cX/CrLnR5X+UxlH4NcEAjc6Fyw8
8JJQ86j4kiblD2jhiPB/sz50xrvaDtLZaAFJCUkNHOUDPduBAuYBlOyLwZ5boi5V
BpyL5sw+WVUn0MHuhRu+sDyAhsiHOJmTY0Bst6FsqaZhQ51KOrcF4SEI0ZP94Edu
mQOq5F9jT8sXhuARo0ne6flVB5UPvSCyvSVrkuJASpHR9eNWQmrSdsbKkc5Bn8K7
k4J/n+08J45WUEEIedUh9lNSj6X5ICFr1zcx/2/slqlnAEpUaxqZRvUQ9Tjt1u/O
ghfBjCwwKvLVKWvcwDCEotU6WXmRqevEESSkNFU46i+l72ybk2+Sph1x+sAg5T3v
lRi2mC28aPdh7GgVUWbQCycqQaC1jPIo19u13BLsObZ2Ff2BIO/G8vnV/oGW8vEG
CTEkt2Z2pmjsMCqfzmwjFVHdqQW6wHLdtytmiEW5kbbCSr6kEZe4tu5lNUF3xLvu
gN1OOyhnZ1VXH6wrOl/eO0EU/s0eK4PMqnZ9pXGZqGx49427btwWV7uBijl/jXzD
xUOHYxTasDJMQtgNve7MXoJVWW13rrkPX5Ouo3hj3bo4w3i3drDZ8MFy8T6xzd1i
G57ZhBjQueNG6LSRpJC4lp8jg0dEMt1KxyzvJeOS8O7jkINeDjliz3F2TQEO5qIw
YIcYSaoLxUI656F4OXOudmO6h8ZHMjkzxQLTecUYrwo9ZfELgg+qs3D9hdliSbez
zZkl+SaJyaKPYt+EJz8XqT0MbJX/7azIr1fRRMtJuAizE9woesw+XMZzoZ9LpbLX
Cq474e9UAjz2K8Hl2v4V9bx7H9xUkVg9NGRQYWt5wCo2gVMKp3fNUQLbyXW9BuMe
oLDcXhq/ww7grs2HCrn4fB070UUPIckk3Q4tVXG4ama7oSS/AyLehOXFkKEuM8Er
`pragma protect end_protected


endmodule