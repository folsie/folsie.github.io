

module hs_tx_controler #(
	parameter CLK_LANE_MODE     = "INTERRUPT",

    parameter T_DATA_LPX        = 1,
    parameter T_DATA_HS_PREPARE = 1,
    parameter T_DATA_HS_ZERO    = 1,
    parameter T_DATA_HS_TRAIL   = 1,

    parameter T_CLK_LPX         = 1,
    parameter T_CLK_PREPARE     = 1,
    parameter T_CLK_ZERO        = 1,
    parameter T_CLK_PRE         = 1,
    parameter T_CLK_POST        = 1,
    parameter T_CLK_TRAIL       = 1
    )(
    input wire       I_clk,
    input wire       I_rst,
 
    input wire       I_tx_start,
    input wire       I_hs_data_end,

    output wire[3:0] O_lane_state_code,
	output reg       O_tx_end
);
    
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
c3fOXMBxUj/X+IeZyYvmqNyjdRsOvuITGgQVjFVgQANmc2QBE/60X2KUFf2geeP5
9o1PO1LgSrDhQBjf4Gm2CuRZ+YzA0yST8Pmh05MZRvWfAmK68vM6H/DQRwx3BX2u
lyuNZBTP507Mt5NIYT8XBBAsbnhyCn96CSEBr6X4Ato=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 4448)
`pragma protect data_block
bVo5MU9hT1kxNkJUa1NLWkC7VfI5nMOgSjHp3FS2DrNHku+3RuoCVyaJnbsoQYmw
Az4kxHpe8wjJI+CzuGr5bbyiALTLnmczPqZrTvECV77pi4UX5jf//eSki8kLp6FZ
/8HKc7BZLtLCaj2ivW4hE/GqMXPmIHDDh5wGx0goihbM/fdpqzH0SQSWJajzitLy
lg2QKzP9Iz4uZ8AtDc4QFaYN55C77knCwP6s3bGjcxfyAgpn/2EGOT5KTBQFOQml
xts6MgcrGCUgpikifp5whJr92wJABUHa6CPbZuvqzL2EfQerhE9NhYu9xDZhPLN9
o3bQzvvwjP8iRy7e8eG456N7Z+rEAGpeGN3Op9lgAYBxMdVECkaTc5hAI+Rq/BdM
cv/avMVoZDxT92a6XSameF89npEiMi5Fa4CCD7ZUtG9MU4rYWekNr4x9kVCRskoY
EOMaYg33l3jjjhlObvYsa2btLZxCPXJt0KsH56cLjT0W4r4ioNyY3d98N85MHfAM
rsuI8V9O9yQyM44K2TH5zxe+qhtKbL7kbTEMNnF6+pyIYpkzRcETV2h3ctgxVELU
bjYpiMIg+psZ08TnZkfTfdM1FY2Vl4JxN0op/n1/bPmShfee8q3OvdwIWvf3tcfp
S6XZJw/8ahcOOAVOtTjLW6xvj1f0hItWsDDxlDq/dc1ErUeDRpalJFeWh5gwtEbI
WuzvQmpOHEAp5GBtRazU0w31oPHEW+iWCXJtwkBi7Lcfh7y18LVlYfglqDxjPAJB
CN/u1TVWNi1afcMEqBqRhC/12XSxELXPG3gHk8Mf8RmuR8/70nbib+PCkuMf8Mbq
eouYmEnxd2QkmAQSc16UVTooJp2SvhzeDNFB7S0ioF7+nl7a3DX7pP9NlzpEWWv3
Kl6Cl4Di71IaKkGi3E10XdwKcwFJIwvZ2dkcqK3uZkV+FP/cnJJfOlBxzaTinDST
FNBCNEa/SOpBRg6kkeFLS+GScfXu6Ut3ODR9qLU0YszK4sDPuxvPcatN5gvN+VAE
kUXkTXbOhPukBOyMOyP6a08ZnKFSpeOyzVkQFeQrZ8PFcsNyWqgeFZyrD/ty7gi6
T4/WyeIHLyD/HVHSfQ+Tfanvcq3PkIkEg4nXx43oLYDTTY4sxRY4zgs3MfHiI1Hi
P66jw0KuQFSAmcca6vB8RyxmZ0aVJL/05KfzXmWA88Zp4O8SFLTLbMm+3h8rJEkJ
6z6GIw/l22K5FxNW1BuyU+zTR+JexTqXoUShau5JjSxYTCs/AAtbz9mvtx4grEzZ
hKB+bt44ltwpmsJ0i3grPJ/6Gb7NCd0AWrPPdNU+/KKNzYByOAYwCB4GgqdyCl+s
vqwFiuMnrEJlLafLGBpL9BgEmIP/vR3ZELZSvAT4rFTYfMK/g84NkGdzwFVAEpRu
X/xOj7/Ih9gPtSnVT0wBn5kLxka4OxLEnGI+AWEGIonCY0UYDXjJfvZiERcsjRx8
4TNrkScJMXbrtpbQfqgsB6Co3TBPfifXqzkLGPBKF1ECLwsnlX43gbaCXeMB+XKT
bzwuVamTR6wZCPXBYUas6P/30KizAOMV0FSHZ+MsQubi3YGPyYjF8oJWvLY69viA
0MtSSSlb3VDAP3Key/HBl+yDmP4cErYIxDPvq819yF1zd1Xo5XWKJBUh505rlwHK
NmJ1vWw5rnbTJhHBBba9uPRZLsaw6Y4VY9VvyvYWCLGF+ybcpqiaYXGgm7XHEBWt
7DsLZRsUtw1Vh8CT9/oP2uvYzkeyPaTmcDAv7LW9KH668J1fNPM0j0oOERYKjkMJ
xcgQ8Ehs+rcZS+ox3E/jtfoBoALXtF26CeTL/sqv/xJ233e4vDwZiACrwfkfqyeP
kFy3v5W0kNX8q8hVhyt/cfutKdWxZYPcNHrbwytyCVmszdzxKdcL1aBdzrTwSpfC
e/IHK+JGTCp8k3QGs+0K17G8Q95Mvq5OACy2JsFqACY99pvJV/w1UtWcTwcvW/UQ
XvtYEI3WIrQ8NgyMXbD16LXc6lWrCUG0N9hT+gnz+QX4VNETquC2DU9D4IMlJawo
bYnLzFxyWenNxXKUWBNsiFQ27jaSY+l2gkKPdxCWWfcpfzehMdn7Aj0TcBuYV1g7
9iklhYkSgQKSyR/UuZjbMoSGWx7l4uYNSTMYqTdx7RW5Un6tI46ASxPzh8MwHLnb
oV+2CUmKKvYNvpOvKLT7UAJLrjf+kIrxzXB6bo8udT9woYhULyHZD/RUrIoy9X4L
fBQKNUMRZcFScKHpwdQ33Tu1jhELRO6hi+e9gBtOh86sRSh6n8qE3kYXCzh+WVKC
kS0B6vuYSZ4ifShCFpI2jfsn6q5itQsB5Onvkzo9CbJoNshtsBbbSSBsJDNBPJ5r
lV5naWB2DK26M9Yqfst0xUz3u8QQB8TrfxSwx1g7wYYaiS8pcZDf+sFj84XgJWc8
D70QSApJLSA2J+cj41uLerUSQUOS4TzrCLdENk01S9Xq1rQaXBfdxpqUNvviSO6j
L91BmKfV4LphPc6WjhXrzysP2rK71k7U9Ee021Gek7JBKu/GKf8vhDrMCvJcQzyF
nBequXqxHE1AlKK66q3tHYkAVf8MRvw1HyUeWqmEemlVDaZNg9UNso0cr674Ww8E
IEaqKqur4kvqvqJd9HTS2MSXFRuCCb89HS6qq2SgT1sl05zLF63kpq3vWoOIoA8y
rPDSYs52RCFmLq6GZ2Uyg8vvmg3g2frDamYidU4sa/9sQyxxbGf+BFKtpMVv0GUO
zZF3iAgobss+95+CQptIzUH55P98ajtVFzOsD2/wb11hVwu0VxdA0Y23aDEMI4g5
lMckXlmMNdazzsAoF4tfg9wY5+HaNeep+1aXft3mW6EsBn77l+clyIbFT/bWOlUq
bop1+XxrXl8hlQ95CMzH/YOtSjKmjf3Rb6f+pTd2VNeMEnY9cxQR+v0EfAcmtaja
f4icA1x8npnw7B2tQis7gY9aTelqRykLGZlD8L/s8TuJ5t63UKvOeoBJZ9r1fy0q
QjGq2ehKAoIWqbA9nx3PMGCthZft1urBM3cOjpH/MnhmaxRa0yMWl7ainjrtkdy1
n9Dgo9M4CZFgcJ13CJr3NnjtQYk+rtuSCz6rNVB6wPToDeM/0y1osdJaxpZNw2VJ
dZRgJetgVQ4wjk6FIkjR0GEvwevQSFwGgmz2Fttn1Y3G57OMWDFI0uhQYVo0VG2g
BFVJrZTeQ+1En1l++/urMHmOEiqweuMDPDi8+kQKl0ZDseCtbsag8AYZkmgEOx1c
rn/9e5QboZlbz/tPtDCxZACt8ozJkabLB81yApJKm+Go6+lbHO+87I5aHYRPbg83
4gUv600+SBaIeAQxPuqAT96SM6AxLUdOXZiap/m1Sx64aCF90bdkEJbY/nkOkeUM
arrNbF0ARmaU2k4ocVvD0/Mu7YTpXGBmfAEFX4luYjPCymi3/9Zcrdgo3vseUGEZ
4DF6mQQ0OK6EGdm2Uv6GP54TwYg1dZ21QZqG71iBciSaLNxJPRMO+wPUZMAwbWwo
30MyDLlLYyH71gNIXdhixhFDL2g/qufe87PV6fLah5cTifJs4sXG4fz2hnRJpc53
+JY8vR6mm27DwI71hr98XnFvzTomF3FzTMrGFb1vi+Sus2LACCbTg6iFj1yiZcHM
rVr/5cT99B5vbU5E46LVC/TWu8wL/HNDRfQeEn+DfV5F3rbAzt69ESX9NQeOl5oW
ONPziG/iDafq+RVupcFFPNV/P2X0M1Iz/qboX4IE8bjdLhRw83qYuWZ+PQXhiREd
Q8Qf7MgLloJjKPljPjqikeq4YYTL0JcWaKrIZW2duZ0OsAsnqoIxP1IE9AbICmPP
+MGEOrpLykhxyqVbQFNoqhWgwLpCM+Hv/r5irUIhNrRsNiqfGfOLKI8nRrTshI/j
cxbfwrVk02v/cZC2AO0azMIQE1rWQ+QTUZ8pVOw+ZsfgTUbRwRgb9dTrD8I+F9Lr
d/6DXHB781Mwa60sMlMBLUJy6HIxfm73PtUQ09HM9/xsTPYS7UdY5qGnu9IPgn6J
yEq2FqNJtYuHSRChv76YuR9PTqRU3unD1BXqVzTIQLFT9HipD9BEHGzB0R2gBq80
F7wh5NOammgnRnLj8lW2Tf1bZAswHING+kKObsdN45+d9kGeB3tnKVnZTLNWz5tz
0nD/FVu/xKup8dx8ko7M5/WhBG4K2FQaxz1fjTNYDWWS2nKu5v5tkgE3Ssc8LQom
68jUoqakFly0BnI9GyZq0D0c9IqovyBUK2GWl1MNaS2QRZbqg48tcyEGrCWVziWk
3YRVvUINtmbqwS++DDaO2GA3a91tZmc8zLz5y9bh90UI8uTyo20XxbChTQK4CXnq
dyRLS1LjOJr7U7NxTHpOzo7DOZ5pl63CExbo5XqEiV5onCgj9BYzSfDQYlSR4k1b
x/xNVcjcgycaPbyZz1eagQ25gxl+KNiFSJE+9g+3qO1udUIxh22/vX5MaQnTNOax
7Ao//0H4TF3Ndw3k3H/unWv+pHvw9jjFk4NWjiyvRvvDrPDbRzrrd5sGeBbB2KEQ
SMk0tJgJ5PcHSVOrmOhisv6CVznpKlRJFy1YoQTU3jnKDHrN4xWFalEGKlOB/+30
8EH1DCc8WA5RV4cKJgOEzQcDX/RgSbkYn4C7Eu5lp9Y1uf8G7WepWLgvGz+ELt3T
XNm7V7elFjxebRpq6LgC//m2OjaNn5SGKcf736D/8OVgJ9FYzoXpHc3tLrmuaTeF
LKsEqrPrW5y02TJ9K45N4Irq6B7PloaWAMH/X5ZkUaC6C95roxK4hI4gCI+rqEd6
0ui/OGw07keRnhIfOx0JPoo4LOumrfOXEOkZKszseBZwYgeEVdfDRGDBYpqFhWXf
sN5ExMM9nkmE69Rx8Q5bp/dOWk+OsToxm7urU5G5dopE0NHpk7FndmykCxNuZ1iN
sxXit78Ld8zlbBVf8yZskPGfp/Yppg71BwaVcJCfIKHTmSYfBC2eQAtLAoP3F5XG
uG6SJWDWn7NhEUDy/F8N5tWLY89VCWvJ4AgH6j3UK7tXkXxzN1I6Z8qI3n0XQrwm
qNoWL+qw4VlL2BEEL3quVDWZwzev5l9MfB3Tq8bG0Bx/D/I0Mb4/erbot8+tKoFs
Kzb4IZxdbclV1Qf4I9sEPb3njMQ9fQNonPB9drle1PVZKURR7gn6yknrac+eLmsm
y1g/JM35qCi0mNn4H5Gj3nm6sazvVw8o7/myjkkDK8rFXQasHSzj2beYqRr1YEUd
ZAJjVMoI9fpulcMwT42R2o9pAopmYTNnBTioHyeHPA1s7m6MJLigJbXl5U6HtRu+
mTabJVnbl6sFrJXq8ZQFqxbdDqx685P56JARRmUfEzy0NBBqjXNjnq8+kkTZQjIw
JBJTnX4cEV9t+AN0g8tuc8UKrkBKZ2L4DJpDO4beevrof4p+9xfiGDaZewCquFHm
qmOVJgEIrLztgHw+BKQBcEepFNnNQFKfDNp2WJR8TnDuVrMeszCLpifap8i1BD6Q
kkOpxuuPRz7zUDlFEkUGkehMW0HFCTrdVMWVYFoBHhyLlj0btrrlXL0bCJRhzTZm
11Mrl0lWt0ZTr4OUfllPEkCNCqYzBsuRXzjrtQTb7qUoSQk5ZIw4r54Jnfmdf34R
/BWxr6KwM6P76jpVLoeznKb2q++RTEfx4I/z3Y2UQ1eBz4/KvNitG1uVWKDPVmL4
crVwhA6rkD25Tqq44ELEPfjGyIkBdSY+UOSHt3LWvCxhwYabQK6xtLyBqazB3KYH
shEMHRl2Z63WmsFhxRKzWg9vhFFY/bLEbSabCZdTIH86jBmkGxQoBMA/FWcbIfJn
jXcJydxtWVTJfcLsJPIZP+XIz3UK8B9g7LIAgXCVLxQplNHviWGyRXv/aU+UxZNv
2C/F3eKQtEvYb71iL/gqgxLe/Y940C/fCDLn0vRckDE=
`pragma protect end_protected


endmodule