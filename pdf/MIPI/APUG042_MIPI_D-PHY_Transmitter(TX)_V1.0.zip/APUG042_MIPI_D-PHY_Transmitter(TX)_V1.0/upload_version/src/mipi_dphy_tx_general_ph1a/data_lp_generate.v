

module data_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_data_lp_p,
    output wire     O_data_lp_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
EEUDqB3T0x2a69Uc/7r24Vw146LMQkvnAY3x1QrXh+CPN50xtmvVebpNff2YUfXi
lnuEA36VjoK6DzQKtMnVliTEtX+NmKSgqlcMRJ8LCRnu6wtnevy4oIgFmLcByZ9x
Qjf1FXE3hhkZ1jSPqjpCmW8wgWGY4ol01+dySltUNfg=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2496)
`pragma protect data_block
M3c1UmlYRndUNXJTNjcxaGKT6956zXKHIjMe/cu53us+61NWik1vwUrfk6sczgbA
y5lh7GtWHz6dImDmhy4ehRl90iPKKhTgbSqCskcSnhpRlqF5camteqZUDlCRsERI
JZzRX4w4yNpTri6HRh7+UjjVjWkRcF9ebtrcQQjd5y/3xOvaNiyEtgkCSZYnJgy/
soq3bfj5d9fvPtWP3GQi09No5oI6vvaAIIA4ehUZaLhz3UD915hbIBWpbEJfCIrz
2VrTADLHvZ1IEqcpLMAvfosxChKAHB5peYUq5DUpHYR56wGUhhDUgGEXlGektYK9
YLzUrONeF6A8iuOo/a8MMnqpOAAw6B8b9isUz4GDNEX/ku+dg7uheGAoNzYs3iKI
yOIr7hazTZkcdOFvTDOjufoAzOF72UsBE38paRPkkZym1Qbzm5a6IMmISwX/Bt5C
e5avxSGCYKmsLyrlX38MJlleKmN6+H5W06cuHCZ2WjkdpwdrlJaBBTZ8VNhV8ch6
0zurtefKzwiwzNisJWCDj8yb0/t8jEh6ceM0kfiABGRXDh6MRHLiDlMA0wkIeCJY
PBVYGTNEmQfH9HvbJcb4r7pYDobINPntLopOYNuPORbSeb+jjLt5moXB7UjUd9Rp
+EGYNIEs1IYyyADR5l5rNP3IpCpyQBj0FJuP+TCszN5n1XkrvEVhw9glPYP37LkV
wUxRwCK/kfnhEQtAkneXyvOWCUfNKytVJLQYev8eU4bIxSMG1Pdddwp+OdZJaMd4
5x1ixziMADEBVya6mjARHC6/IjBWY7h5FLBW9qrcjjlYXktCqjPgLV6KWG+GUZlX
B+nezZ9aWCKmxK07cPA0T13Cr1P63C3u+U7YgobF3WZY1s8Ma5v9TGTfKaNHJ1YJ
r/AVJUDj42pKVHrtPibCueUfJxTereSH0bW8kbAS2ixnI44ZKlMrNa9peS3Sc8ij
W23TOEDnRlNKgDv8f4wUTE19XAPzdy0lropO7q/etnkiWzsR75FAlYHO+IYjJgEw
FULAunQ6r9D0Ks7oSMFjoEBZebDXP7qtz1nyeFPR7qxQOdRxDns1M3zMwac5edZQ
41vhqEHWGCDg1SrAU1zmKZT4DFV9cxAC1fGJ4Asd0t6t5EFkZyBcTTrTJkHeszO9
IOGVRFiuU1Fnh83B15KE7jTBB+2U4Aw8fm8NffSjPZTjeUuIFlbmnEG739I9vRJv
uev17rMPk9wgY3WLQNWqrIaHzozeX0bwMsnZ2jlPTonAtFBQdbclmI07Pn8hui1c
2JJGM+lCMA/vTnGJhiMC/xUPGJzjymJQI4IFokysAq+F/FkVj5tKDfigtjEEDMA3
HrHEvgJofdcGvf0U623Y1ijtodeVaqzdJYNZ1JDcjQnzF8bx5KSFoXXUgIThkKTh
5BMttxbEj7UHr0pDQoyeRE5Tl1u6FVnQPphnT1Sd/Ov6kWb4J0qafUsBfJIBOHyg
JnQ7qdVOBxiHWSKPtz2tqvMCn0bC7+Z+ZxrWqZpTcj1LyPLBkdebnwZGPMW+MINJ
7EJulrjKrxFZbwb0sh1hkGqHtvtTZ0o89NwjcSVD3ipZ/3EmlTzFAVGBL0/ncqC0
vqfQVGstyFyiXZEiv+Yrlw//0d7DkqckZ4eUmEp2pK2yKe39TEKqv6ZBn1E19FpF
rsxTx5IGk+AgYfZAIL2WvHYuKnggGLBk02+MtpSBqyyhtuZqLHR7yBvyrCcchT+N
Y6qZFIYpbPQxXd3nZBqU9shNZW6eDdW/7/lCzTPUplnnIjo0goJZj0oDCe/vJ4CV
7mK27NGFLqpx0XgRjh1TzwQ8C7/bNP2Cm07wRQUy4vimNemWmZTivlfopXf3MwoK
TD1GsBHbcOyXtjxLjEyqT7q5gbkEmfErillHHnNx+YWFkik3xaboOEP5w5dXIwqm
7ECzYxWZElKOJX/uuPCBilpHAY9mHJH1naBr4f1Y2ipi/6ZirtJC639GK5cO0jeb
99S/eaTANmM4AU1F8tHdvQq0kMOwhREeJDwpzEirR6bsg/RuXIb3Vr7JyeChmSpp
TXP1NKCs5nvgm5Ip39pq0Uk7CGa5HaWVY7QWMoKJwIUHcaU7LY6/oheBa0kuMlyM
n/r+IAx3MmGoFZ9ulmKySIcctpJuaBNlNhIVZdvVZJnKQtNxpfpL33KFATR+rw1q
7UQL/gbHZ/5MnVpG+r9ibNXJB8OJFlGwj0A6KN0NjDQVSdZ8xtiFIrB/Z3VgaOja
jch3J4LjQ8DcLL0xx2K5FvmRoBlVkCMtLgxd55gFrhxqpBtBlEzdvkAWWomTa13D
8F/J42XUNcztHWHVCKW4dlGavgZksX80qlNifBDTj/8Q8PT4nAgbS0ZEaBjJ8B/t
Oa4S2ImjtKpS5wbeT5IYuxRJXAUmTNEXjo3ehJ/c9HU8YGPk/Anymif08Ni5wMf6
UDMvco9GduaIYCF93XAlTpYmadpcou8T1x9FHRRTcGLO7GvWO4qlAjGs5BbuR+EU
xaBzXRy5okB71levT/TZaEsa8l0f8P489xC6NbvFy6K8fm6hTvYXzt43OrqYrw57
lqYobW8dSQprrvcOaG+j6GevjokEbjg2aARQ0R6e6+mxFnJn9Uw5PQ/gcHAZx7+/
KPw2Hmec0e8Ijbd1W5bUVTgBH4MSmzGU/zbwhAwNMznW6alnJKJ/8mhjjHtEcjc7
Yw5H3tnpQarvTeJueMNWNuHQgxKQ2+9znazUisCDebGTmaUeGYv8ZBwKbKXlwSlh
feZGQ4bUzaSbA2MxHY2JQBHnbK6c4efVRjAdOHUMFkIMOqNQgBCLjasxvIYQ+FaU
VwlL+qNAIbpS491q2HjKcVrbSzNUKz7vvZJJftWXTrqyLvdI4M3vBwiqb25fsKaG
+483cqKRBd0DsvxgbAalRIY/dxK8YhdrLF07nqaQDErJgq3Va+fW3iRkOzm0BVqq
oeUdX3PKp609DJ1Ud3bBbJyiAVy3D8vPnM9UeryQns62CHrPXCWuK5nsrM+cr2Oa
dp7DMHMei3ssM/RvQV852O1MrWKJtbJyv59F698tXGEVwXQV1GiVW1kRJKDZ3mDZ
kWbhHMOkSNH/+gVRrisieeXbZcJzhv+PrnkzuqHfvowTXJECOO0FwX6AYp+c5q2M
/oo6VWWYHcCcbDfRwA0a7aprlG8njx2E/elbhoSyR7W6F1xf8skA8WoZCokmza6m
H/6HxdHoLN+7aHLMRvatPifhwsKKB4NO9MZB2jFuP1vrMHD24AWfzJUm6yVoguRt
Bnt9Gh9isrEvKB8osVKkZ20TGUdFUl8hmV1JIrZKn5GfLPgxlpHaYysh18k+PNMi
`pragma protect end_protected


endmodule