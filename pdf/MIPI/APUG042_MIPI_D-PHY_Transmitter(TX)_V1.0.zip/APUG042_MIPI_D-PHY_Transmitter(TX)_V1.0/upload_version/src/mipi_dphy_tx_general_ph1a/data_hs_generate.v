
module data_hs_generate #(
	parameter FIFO_TYPE  = "BRAM",
	parameter DRAM_DEPTH = 50
	)(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4,
    input wire      I_rst,

    input wire      I_tx_valid,
    input wire[7:0] I_tx_data,
    input wire      I_tx_last,

    input wire[3:0] I_lane_state_code,
    output reg      O_hs_data_end,

    output wire     O_data_hs_p
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
NCnF9O5NtDb6cZEQ1u6Etcqm0o9qowN2B448zRJiBzBcNALRP4kNApTKDtE0y/NR
AW9pZ7LuFxP0ggx/JQQxvYZnwYhWzX+MrceWnlwVEuHt7J+cgXmzIyQ20+sc9E9I
jzxkhKxNRUZjwnYEHCP31yOyhfrBsMnjx2Ri4y1vqv4=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 3296)
`pragma protect data_block
RXhCVWc4V2dYY0xOT0hSZEAVOqADcYp52XebKwP6IYz529q7i23Q19egXj383AGu
ehHlyW9+zw6vGRERW9Vf3Pe78jvUbsFkif14yNjdakejQaLqqUY1oBuckS1+CQwB
pHIL/4tHG14HvMxoovkYrXaHwGsFCFPEYOpeXjHKt7Wl2TYpSxZCDKQhOUa9Ximv
BaD+BB/CAEeT+VqpLJr7sa1D6hGX9nGQnXR4Yl5FuqL6zP+8rzp6dkFG4klq87Eh
rFCPADcQIhWzDQQ1zhpzzyDdbe+ln4AYcbFoSbj1bPTNQHXwEKALWap44R/uGxCX
uTQZhOyL8E/eyNr2eDXuJLDOTBdxK9Gc8dPWFTsCswzGV5cLy7rpll2CdRmobiQy
8o4aVjKmrRk3JjchjMJsvajcRuODxiMT6LnO0K9CqKJ69+9CcVs9L8gqnMN2zLzf
xEvo9MiOl3av4RpesrAwlCDEQ+izNYiwjiiWMEUv/PP8FR81snNIBfh5/QM4oQ3O
Hjdwhy1K3492Lb6KXsmx3M4BJ5Z+7JV/liB6Y0PGeNvoA0OUWRCD+wqrXE2lX08V
7WB5UCv5zlooH+rtgKGj/p718z5+VGEr5uMojVo5SJPk2INzCi4/OCMscoes1ltk
JfW3Bfh51s4TgOuyGNwgPg/J/kGYUZvhb6WCOZg3rLVJSmxLx9t9oWRflxUhieUh
6sJ5VV/bZiLxf9BkqFhK49fasftLMvOlPvN3+GOVTCiyrr2nM941Sxt8fT/ADYlY
8Q1JcsdQucdPskDfq2ari2+VUwHE0xZYWk0M+R+htcLWcALn7fQnpopk3/QAbAI0
w5Cl1eCZ3JjWrKdQkA3PEbCxjvpgh5LTh6o8Ed6qmuiYlxiPZEVziwjZLl5C3nz/
yfnzZMjOzvurUE+L0lXcRAF5M7Gw+pYFh/XAPKMzGxFEk5hHgzXxB1/ch6xg5E7L
oTWf+RBEYa3w8iKQPWndmh4ZqnGS8o01q7FtGcc8i4RdCGCnwr7kbFgxSyFZsGLt
Vp5jMdpa62yjnkrk98ooFZwafNWqvSD/p3x2szf1ZLrit//wdI9RPaSRBroVTAIU
8h2iIrnGRlhE3+JXwS7hVvlBdI2m9R4b9w8t+pEYOzc7+Zx52Z6eVxEOEP2k7ys4
UXDsFDnGKkYsyuJvFzGdhRU8/RnXAVjZI7aAgkPNs49/HldIje5bViXyVWygRuld
uQoNFzv8V4fNU80FafSQDEDpIuK8hipcz2IfCYS2WJi1Ki+fpwQZ+/AgoD6/itQf
oyRky1F/FDHln1YmJN+FJ5ZlYoKHBE8GNMrFXGwrJ/kVOhllVW4tGDamJCbepLal
2r9c9YtBynvaiFCRoAgG3en2TfjRfi+UaQWIffEDGjdo1bZv510DaCIH9tvzu6mc
XJUqvulrzk01bIwlgM2ohNCdB7fNRXg9kzERlPG8JsxJCOX0s7Vp0GsD2NZy/BRj
f96Fth/f2Ir0Z6ssGgnk9+fhox0nq/e7s1pZ1cfnM56EMcIOZKH6DIz6SIPRSyBW
gbTcd4trUvxmNl5LAZVWwOiuas/MY632EgxwRXwR0EwEMQrzSebfRckWjd2Ddvbh
XrPRTOHYzUQhMdLm7fZALhn8eIRspDoTRQtB4LTNc6u8ERc3VOxrVPSsZ1LY32V0
iwCi0DcLEsvWayzAjj+0CB8fgvVr9n/GvVHfk6kylSn5r40kDLDQjqPD7/encdeR
+sH2MEjVcbCAxt/YeDOzK8ydQ4EaPNd3vZ+T/SSrTzTmG23kVOvIg4YGNJwCemoX
L1ou8dlR0rxCIMh1HW8xBDOo+ZCq/1HQqIB7LehAuxF6RNoN/sjKE4c81wdRnwTd
htmzg8XBJCb86TFPpv2+2JmJjptXgC1YmCWExQyi+S3bt5zznbNBS9xnFUphhb0I
3geJg8D1Efshp+hwMoEavzWmpOHVNFyTGg9UzVKuqxEL7TR+3rT8DKEigSY6RxSk
8PSOLF5hCs89lfc4KFT7apmkTRxLUO0KIy+jkz8AOiHeZhi2injYAsBNc1rekt4V
506b1Mk8d2W60EtlBdmuUyZuoypEpaeIT7VNrtE9b7zzHXppF/RjgyDsjju0OuQR
pqfWE2M82XIE6QElTVLOd8zwZCUWiXU5V5ow/aqfDsYVnAMwGXxMZ77jasMn1dCK
EUQsbcNWbOfKEfJYrGnYc16nMNVOMemPMToa0yp4zl9Ys/hFLDi+rMoXWDNvDc1r
4+xoS/SvTTDDupQMN3njhSppZUu1P7qLttzSxVgwkYMm+3V7piS4McKiYVZCKlGi
UfBMoPyBH8LyZz4EDuMPwu6wptWAv/HnBBULoLT1rSUSnrCHVgu8JCE9vwgyyXqD
ABcybNtKIdLP+iRaxlYO7WZ/dvGasCw8+kiZOJqAUyL8UY0WEWIq9QuUwDtPTHyt
u3X+joXrq4Ajow1Jo7Q8eue/cGTUVfa5NQc/4FpSQww5MwyPIFpvua0ZT7lNxG2Y
tdnrzfvDoeGc4NacMGH/eB09cFVCfZ/a7it3hZmhTK+flWPUl6vgb4HYovSEFoBD
R/l2NOodT/rK185X1ae2VN4oNXTJiWt/MiABFM8H9X6tfC6QWVPRM7y9ZO2sSrsw
m2aN0+kBnJ7LWJRiZqTKB7FtkPaYm49v8fuN3FCeUhSPZPs5sGc0MqnRDSZ6lp5w
OOaVlGD1RHRSDBsO4tB0jfnXXznWNbimxXosyno3SgV9LCzBsJC/nadR3yuIpTYm
tBqcAi63VxiA2LuRe3JwgdvEbfXzboRqZLh7MXjAL573C0SU66ePCRDauMSxVBHq
OlQ27S2saLbiIBLVQuUXvVIn3RdWDgCtIatFk0L59xCi20M17mWgIy0O6SollF1C
9OgGdVJ30KG0b0s5fqoxckWGsVJBaTkPKczHFzvJWiG0avBzmZtHghej8ID7sDSv
eTdF+OeoijFT+eQ2mg6giWU3jqoVfVvkFAIVPKSzCfGbqvQC99XET9L7x+hlFlv5
ULdPOb6FN0XsULxtrgZB8GbFeaXSydP1bSFyqDxseyOQAj2bH9dMIpHihM2TNhEi
1rGVS8rbXIDb9CMz0dMXIpBhu60Ct3eiJyrf3LxY4KozBPn0wY5P7orTKwU7qiR0
rP70lnnRg5HU6r1QVjl1ghE3sXAnQws7DegLikhphMixCJlPFypxXbUfBTDIASuE
NWZSIK/bu7R9Ol5frkFIApoUMEni4+zgr1frSpZc9L+OmZv6ZN7K2O0+LBJJnUsb
ZzOqyy5oPs2raKk/AeR1Nr4CumrmGdqxS8S7v0W9tdLVpGA2mWjEGzhsCAUulbBI
N68/Yy5dTT4pMm93o0G4a+uvWTlMRc1/rpDU+mUcBqeQ2aWjQ7N/ofUbVRiAumPt
hpSq7SEKhiRW+G9/hCjKCq7Gc45O2KRi2gmP0RI04sktN3LJVhyKkzPMwj4onqqM
2BilrVsF9a9e92klTXHya25r0Xei8BcuIt8dFx84RDZkoNIApvRPFi8jFgzTfKD1
1dfTqsyGyxF6FX6+bQGadJwGu5/bBcdTdaw4pcHEN7Jpfr32l54WG/IKmjuGEUEr
oWW0vqsKFPoMCle4whWDyREnTs/Z6vtj+FpbTDULPeGrqvdBlHu0OEcMVXT2Dbht
8fV3hr9GoQHLKaaCYVzs3Zhpk43iijFAToSRVDD5SstNkY6lzPlTfHfsXhjnkFI1
OdYaci7VZSDCGJiqHqlnvJ81EkbjG28yEw9OIf0CQclVn2PAAIMsg3q293v5yYfU
JeOhasHeRNGk++I4O7q4Mvcd74Y2H/SqKFBQxutlvXXW5wIcjAThJh8ls3zszjnz
FSeZPCgjOpwirlk/71MaV+whI10WXSIc6ogkJu0xVsUn8tKepTst6XBwRFXmfuMe
HLsd4BwsDQPCsAsjAg79IrqmcdYZLd98jiIk99hVek3VQjCaxBVJtIkmT0TNa1Sv
ACPiYcUa6qztuxOz0HMDAyx3YzRTPXNandeP1KpMRFL4CxypAT9/+44SCWKuWTS2
mAWHClHiHOyn2TsXAepZEDursI4vguIdzIPKqGgHQoaTH3G3Fqau4bqpRno4NW1X
/zTVzDrIcQHQxpi1H9SqOgu12/lRUVaQMCxWZW3uAkchfmoOTTydLUX0k7EEiUCJ
OCglYKhzSUvYv5bFywy0FsksjsHJLSJwr1pEFs+aYPrdzn15+npxqzxXm55JGp76
JM0RqRBrAc/+nShxuhLvELK/K+cgHsU/iM8SjauC1gt0iFK6FCOpH9MsBzFTtuog
wbAfatOWWmR5neambm4H+MD4ClDgHVzJMBgxIRxASCNAl5EDuhfX97tHQwGJRToI
9W0+ndBny+PHF6gHA9snjkRg4Jn0XztgGCZESU+sjgw=
`pragma protect end_protected


    dphy_tx_fifo#(
        .FIFO_TYPE      ( FIFO_TYPE  ),  ///"BRAM","DRAM"
        .DRAM_DEPTH     ( DRAM_DEPTH )
    )u_dphy_tx_fifo(
        .I_clk          ( I_clk          ),
        .I_rst          ( I_rst          ),

        .I_fifo_wr_en   ( S_fifo_wr_en   ),
        .I_fifo_wr_data ( S_fifo_wr_data ),

        .I_fifo_rd_en   ( S_fifo_rd_en   ),
        .O_fifo_rd_data ( S_fifo_rd_data )
    );



`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
TLIWqlCEGX+E1Lu3W/yNApdDgQssE+ylQdbdY4XeT/rCpa6WzPewREyhbbGm1bmL
TOcJVzBZRA48Jb06rIfuVuANudk2g4FFtMYSW9WdqvqDriqxnHHNQ8cxKc9U8OKI
n/O6H1D1I9dcMJNTU1g4qvF4/qmH6fDwdlooj0mT4OE=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2576)
`pragma protect data_block
T1F0cmdLVGY2RTJxYjlaWfximvugGMOCyGwCusfCeZY1ICQMVAi4S8QQ2ve0NX1x
2yi0i1fLZ9nao6g/aI08rYlyBqrPRf5TpYQDVl1nCZPy+QmR6qAfJUjADsnvTf0/
BuLiFMiNi2qOgiz9pIk2k9uHIxvBzlr1oV8EfvhChceq25Z+qNrs0qQXxtIEhoyM
3ILBKN65lrqsvq+Ph0m64bsWAX+Yk0nq6W003LqDyNylsBFmIiuryOowqj7douSW
Ooaf+rDswEE6i/vMlPPbZOYPdPFsIQBePIhdsjLQCDBPrX+u2PtDWuNKvIuFZZ3k
d4yJcQujQOYt63DDJSr+jq6jdeP5wWCrfRbGuJVR5aJesus2rvN5BTERo+mirEwH
tospLIAp+ko4/y8yD/rw3g/9FWma7jJaAcM8QapP1ezuQGn9XYcCgkg+g03c5DJO
HzWv8H0N2NcXU2HZnS8IUvS4JLAIabvJxt/43/CYm0NXYYSeJNYPlWn/hj1Vzzva
opkJgoZn2NzD0F78o6UdXlZjCHJQrN41zmpWXVRlK0d5WgMsVNMJqTk3QNG6DUKh
9hNOHFcur8221dZggJ2a9Eh6l7VhuY/GRMFqD5+DOExZm79X9YuS+O8M/iQEBUKy
hXCbOqpNI5PuMU2/za1wrVL8MgfSLI/YTemxUNXWcsxqGwXFlpWkXWAx/MLiMEkZ
UvU97+dpLSPTu0lb9xCmPTzJyK41lLme2gr06CLU8Hsb0UDejNC89mLaAf1G3AUy
MojgboW+2s3Qb8FaI26Hby/wZke/QkDiYOc+1qilhr+9ldxMdExKNs/4XIJEaPXU
K0FCccD7gyfnWAFfkkW1h8M4SYFag161FnjKBn02KKu/18VxwegY/alS8KXTGNd+
NzXy3rstUNCPHU8K6M2/Rwf9mHTdKphQE8Lz9i1azEZ4N2NaZaKIWf/tvlxjaiEK
PpICD9Jhk2Cn+5yAlhL5VMQRvR1l99RWTPOX6tMlDY1VhmAgEAm1iI3nQN+AXhbd
yeIq/jtgk+A8AFS0/Alj5nXg5Rg0XhzjQs5oZ1Mkbcjx36PjFxNigop9JHWhsROz
xPaH7cpxl8ZK2ttm/8mvgjzPtIQD5q9uxarx+GOtdGP0zTWvWfieKFK+q2Vlqliu
JIJ3TF0sWUw+pYV97w/dpewwLlBKAgQwbQaI9U0HODYATU1QSNFa7kGgX8r6SgNG
PUCZHR3y7UBsQHF9iejL15YYjEvGVk01uTWwiUycEzUnohJI/2M01Sse1koLNBeQ
AE+1WW/IpP3kcR1SRQSYNtQliJwIpoADqXBF8LCs+stCOYC3Q4X+siQgtM+AXwVG
SrSq+IuoiagAGkHGDDGkmaKmXtlIS4AubtA5mlxFC7JbbYJluOoqjsHoUimjNY9T
g5R1W68bIjpcw3RkeRlISchqu5bQC8Coc+rxU9ENHK5xu0N/za/99WfUTS/gO1XD
kmFT2IIPcsWmkR84m7udTJ8Fjx2CovItjbtmtfD6L6bAwq9x8KUn1S84IsnzbIp7
bgJ7cSBs2v5/GfxFB/zDdbcHtkArJX+B/Qmpfm2aMT8Uyh8SFj86ixtGac2LlT55
9Gd+5ZioxTh4qnDooaUkQg36X7UppGUmwAqz184X7o1bXv/x5O67nVI8Sz2O2kWE
SOFOxhYyOwZqMe1famxRjnxYsHLywjZwmiX7sE8sqpB+heWbGVqtxo1Dh5fwH2nD
SewBd4bTigchK4RbM7/0jdLsaH+nqHxANbzGyMYxzSuY4tDRs1rO2NfzgFmeCAwA
K+J1FAhjVlWkkNssOh5qheXN84Z1qwtD8+1y21hLdPD8hj/Bc6M9mhXpXNp6/e4W
GFKu3Qi3S1L4HDEFqbqb2+1j3aRlhB9OWf2EkiiFx1hLGYwhMIEtHwXM7ll6dcAa
lyCGVTRgo13NUNSF6VkmdZVJPttLbsLvfX5vTX67Z5xtHkq04mFfc2kZVWkVOBsX
iPRQqhH3g2ox6vFX6wR47SP0USg7Sj1DYSE1nXhVn6AXzv6/li5icP7HsBaoORdX
VNbbRm5AyvzWSRyfoVKAdYidlHINrCLtiY0cicZsMOajNjK9cNm1JcsQAkmcEwz5
ja2n4BUQdcB3Ikk9ShNrTA6a7cxZoJDU5Gm86+NL9EtwGvgzP4P0IMFqUlFR1BRr
uGlQq/5+xQpxGBfK9HTTUrUKR8B2WAsIDq4n1Srfyb0jJskTAGmbaGME21eET0Tr
12NiiXa0Fg1EkiGOx7uCrzaFfsxsbhj3RKhZ/Deeic4K7Zeee6c34wIlH45vso/B
Gi3yykCI9QwYORhE/35VFiVILWuKOrEk1sLklx+KrMB0YsN+iWyFfHf2H2Sfoul2
MKUApO+Or9refP98ZVPqL1NTrSE5Zt/Se8pFITIL783KoF/y3C/bpKPKoJq3b1vV
k4GwXCMN6wXp/Ichmyb2z8Hh03ThTEmIcZcZPff8uMZ+y3WhGVqf/y4KmQQGauJq
ZQdE9QDXuFFe4RNm5fpIsYy4u+KYWJBW1MkyAQ0w/+aGLjvrZ0gcOvcVTUS9hL/Z
CoAfnEMC0YxtTlCdPDoM+Jd34roqVab1TLB0RPnWe8+xGGtK2OSCNmd6Ot4Nl9ps
RFsnYT/dr3RQcXeVsiKNnmykTrXu967EndOeCVFG3yGY3L9FmckyWGqtC4mvlLpE
f5MpXBPA5enDHt0W0bEknkWVJZiUHiEjkjEQY+1IEsfh398dtybrROVs6wN2N0WH
MOMJoi5v0NLuhSVaT8pdhGZta4XYlgdNUv7QWw+aEc527K7z9aO8yh/OD67n9MG+
SJ6AecIz0snjvvYIfm0813WUzPZ3VdonA17lnVsTLUuHrGngoPvthaYAnuIq4VJW
EqhbrrKr44TZe1HlIqyiuiYZgycvMarThKxLqDcj/lz08NRAf8gAGNiQ5k+8WXDr
/irUp7OiOfnuHBK7BvNNbF19DiSCl1wBibbDh7aX6neMcFCXpzl5VxA+RQv9X8nN
f+1TVO7PbHlr5yEcHHVTL6yhQnjF8z5/QL6/HtHP8DKStZbj0xHgyPZTCxDOXzUS
kO5i+WVAARy1hLaizmT4zywdQ5wWkxLhHjdVFi/BtE66JJ3ss9gi4t5oimvgv/+N
KfAR94WoS9ykVwhG/slBE6+1HE65tIAf3llDNXdr1scjZvMvzguLuUyIqs/mnwJT
d9JlSk+/m7TT3IpeHYLmzGlH/Po/hlt4AI/ka8uQ9rjYQGFjTlWZ7waDD7bomq71
Qwl0uXWsSuGVThRtNrpMJclKyQjvRz2aR9evjp9dxlCb+GSdXOWLlodnTfvj7K/3
58LGLcWJG8DGkNoeS93Doh/LozSVxeu1dN4i8/ZWsVAY+V7UxMxi7mvxZGjTqGTm
I5DK+pb4rcZPqtvZA3vbnSJWQlCGLkw8uymTDyY4has=
`pragma protect end_protected


	PH1_LOGIC_ODDRx2  U_oddr_x2(
	   .sclk ( I_clk_x4          ), 
	   .pclk ( I_clk_x2          ),
	   .rst  ( 1'b0              ),
			
	   .d3   ( S_data_hs_oddr[3] ),
	   .d2   ( S_data_hs_oddr[2] ),
	   .d1   ( S_data_hs_oddr[1] ), 
	   .d0   ( S_data_hs_oddr[0] ),
			   
	   .q    ( S_oddr_data_p     )
	); 

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
ZInXh2eR6hJ7R2UjNoliOeBcEeJtX9CDUZpNGJRGHtFauuRrUSEyxm3b63EfW0kQ
bz09IYVIwy5o6JtgGWQsx0uI0L3g+0t8Rc+E1cYwCVV7zxfBg549aGYfJ07UIDBF
6quJBZRnM1E8aD5IgVft8+4f0VYiMp5h8Xts601bo+c=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
SEcxNGlFSXNsM3hLWHJoUymmn52jyt19UaVOqfmad36o0hCKy78eyOqRKqhqxuYl
jzYxucyJesBpJIFYK1zYtusBu3WzGIU73oiteHgJURCZs1HKYulSbMD2X2QPhFDw
`pragma protect end_protected


endmodule
