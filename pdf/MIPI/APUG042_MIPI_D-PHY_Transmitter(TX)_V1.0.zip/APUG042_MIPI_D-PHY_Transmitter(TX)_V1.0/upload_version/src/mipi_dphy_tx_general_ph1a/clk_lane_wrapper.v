

module clk_lane_wrapper#(
	parameter CLK_LANE_MODE     = "INTERRUPT"
	)(
    input wire       I_clk,
    input wire       I_clk_x2,
    input wire       I_clk_x4_90d,
    input wire       I_rst,
 
    input wire[3:0]  I_lane_state_code,
 
    output wire      O_clk_lp_p,
    output wire      O_clk_lp_n,
 
    output wire      O_clk_hs_p
);

    
    generate begin

        if(CLK_LANE_MODE == "INTERRUPT") 
            begin

                clk_hs_generate u_clk_hs_generate(
                    .I_clk             ( I_clk             ),
                    .I_clk_x2          ( I_clk_x2          ),
                    .I_clk_x4_90d      ( I_clk_x4_90d      ),

                    .I_rst             ( I_rst             ),

                    .I_lane_state_code ( I_lane_state_code ),

                    .O_clk_hs_p        ( O_clk_hs_p        )
                );


                clk_lp_generate u_clk_lp_generate(
                    .I_clk             ( I_clk             ),
                    .I_clk_x2          ( I_clk_x2          ),
                    .I_rst             ( I_rst             ),

                    .I_lane_state_code ( I_lane_state_code ),

                    .O_clk_lp_p        ( O_clk_lp_p        ),
                    .O_clk_lp_n        ( O_clk_lp_n        )
                );

            end
        else
            begin

                PH1_LOGIC_ODDRx2l  u_hs_clk(
                    .sclk ( I_clk_x4_90d  ), 
                    .rst  ( 1'b0          ),
                            
                    .d3   ( 1'b0          ),
                    .d2   ( 1'b1          ),
                    .d1   ( 1'b0          ), 
                    .d0   ( 1'b1          ),
                               
                    .q    ( O_clk_hs_p    )
                ); 

                assign O_clk_lp_p = 1'b0;
                assign O_clk_lp_n = 1'b0;

            end

    end
    endgenerate


endmodule