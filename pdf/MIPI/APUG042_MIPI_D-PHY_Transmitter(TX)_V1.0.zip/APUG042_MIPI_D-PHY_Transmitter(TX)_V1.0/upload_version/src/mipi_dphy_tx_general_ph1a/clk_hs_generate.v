

module clk_hs_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4_90d,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_hs_p
);
    
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
hgr4ltI6RjcXEj28oQhd6kENMtMydKZO3XgXs5UiC9MsenBAjFW0jiuHZlB2ffFU
RYP7GMwf8jFCFjBSP1bUn/q9DDwRBgYiSI20RX8N0xXkgAu+qupoDhi4WqN9qUsm
wKTcWl8fzIiuRPfw/zsxLpMo3/XdMITrdyC9RyiOZG8=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2448)
`pragma protect data_block
VFdkb0RTaVNsVHVONkNqSnDsq3dUhlvLMoO0/dAYhkRe5OF4ZT8EQryZAADmQe0v
617TqDrJdEERef3oIrzY9uahi/dyia45CVc0lApeZzkdQgJcgoeVAmzEmMiKw7eG
mT44t9eUyow4Q65ir1dbmN2O0gJ4pXJse0g7DQ8I89fJDIwwLpsKaqRCfjAyd8ht
VtbP++ddC4+fCV/IeYCq/tKQnnQJ9FrKRnv9LNxm4coOj/q6qgdsTSGZ7MN1CF2H
U8OTUYTb9tCErihkTaXF5g6hjB3ILuvi+WI9I4Ss1Ch6t3mCYt7uf+Q25ifBTAeF
ziTo0qt9yWTfuRHy3mKsY0VGto7kNj2f7/OOnl36j9SMjsixGaieJjwoYQeXk3UY
veG9zpyt2jgRqZMyawSXb8288k4Hq1LvOemmM2UwebZ3tvfFTdow5VqNEiwPFQYy
/XWCj4Vo1FYC2kl3MUxa+RDzyNsDrly9opElIlPOsOdUgPvmQOPaGYlkvugj50xc
b+AWi3j//ddDh2fryPtiznhwEk5k5XnDL5jJwETN8ajD+nWYjw6ygW+8pmFgMBRU
0FMM1QrmOGqXuh1vv2QUpukDXjN//Uz3mr6ebAsju6u/rnXRo4Dkr0mOWIZFVStM
O/6XuabTE/AqyqNWdYcyB4sjX111arZAxFRAWI1l7XT3u7qWcIvPqhGzs0haMuOb
tX/XF9xURVi3J3ckSsApNo3KNZMjiTNnM2DFN1e0HZvgjbeDxWfu/BwX6OuiWUMV
aByHCO4DQTmh3QeCM8/hUvh2HjrTxTL16HXCiDX3+0z/FGqWP1sUOkfgS2eDsC6Z
UV+Kk36Q1ZXS4kZuwckuFjgUuqSyaoeiB3DIpjdxBGJXKqlJvzMcA3Os1AsMOMN/
JiCj6/W3nPeAHHoKQeDBoqnd9HHJgCZ8hxNxnqqqIHdHq7Vj+EKK+ZT9olhrJUXJ
xih/Zma1naw/4tfYefhfT6eSMOjcLH8rxO5safDMelKmD4ay61QLWN2s1XiaXXmn
Sqaw8Xdvu3Rg37jKVhPu4zJEiKRj9zkxzQCxnoGye/QFmXfaz2V2ttXf7KH/j2QC
YHrac+C38fZRtfOip538NunjNiNN2CIbRQPpHWQXcNcrFoY0Sk2D6v01sOIwZoF6
rEo9SPsn5erRjazzh/weOGlkpddx5t0QDQ2T6mpeZTSV/URly/QSTBFIYm8PWkiE
inmt9CZYl9i04oRuv00ddhaX4ejTLmWAtAmF+bABoKfcwRGX1rpaxXN1mD/qboDJ
V/PXsOETk9AsFMNJjhqpz2Ym81dsPf8cfzKGOL2+N0FTcmEbdRrRMXmV2XeTYAY7
Ww4S91k6Xx56Sm9cm5DK6Ttt0Vtl2vVUN2wg4fQQRFTTTdnWY8FadnJ/byb83DLq
4hRmru4KEF3Hi6HWzYfS4L7YUXUA5pTMrZMdPFWSddrXb7aqqc0fEuibIK7juKhq
UAVle+vYZczFyepGukL8aChvnPuqS6guF3Bh21F66hH9dS8Qr1hKIB9NoqUN1zSr
EPda5yiGW5PJ/277AukoOIKuexx56Bd1k0u1sxYoUHfD8RFuzr2STo7IIxRYCIZ1
jYoyfZo9sF2q/BilNHTXSj0xILgakQS2g26HBlrhbxDXE6aKlocgatcBbqEEnX05
teQBlHYij6cHYYQ5ALzYbwgHLriWbuamUz+QxGL0uWjdC5LWlRN6sk92pKq7VY/C
aJ+C0Ml9Z6WNL5HXJ6gyWNY1ECyM/Cq8Qw/0IUB753uthsETRqbMy7QtZOA+67ds
U5jbdpgYXxXinwZMp8B+COts4sHmoFaZdZxjq2HtWgmvyofQNpfCz/QyT3W7Mm/+
AB/kd8WV6SSA9ETgVLJq1LcQQEyAuNvdWvih1kEpAvqRwyBElEY6S+8d6Ro/4pB4
JjAg9MAphDVhM2729bWj4bHegie6XPGJgUW7sBBJZ2NPcW5inkNwghRbC+VOnrwI
MiQJHTwPjbJk7Sw6EUjMxH83vZrMmkmdIEhw6AXImqkn2xO2Y5y+MVmpz7L7Z/US
K/5tX2DOXhqrLGhiRGvWJxJh4/O8sOZOcu+uKwuszplPULh5EHQQAC4t1ZqLEZqr
Qc9FLRC2syHngJCAtyUWIiqkeYISegVc5Ua2VbojuRem2Qv7NnK/5piyMknz0FsB
zW1UFxEayae2w6byr7EKcDVmtgGAOSAo823Sqf5m//xaPFqooVfhs/0IWCmbvuz1
J3Rx1frfrGEEmLd4x0toco05MfTyMUjP/XgK1NtG4PWAxoKahL04RcMdPPpcJyJX
bXE0GqmmLUO8KkvPlJip9o1ybf9V7cPymYF2LKkFe7sj4N8PK7yK4Pt3eeLBNoZf
qM/X9DzVSHvXdDY44qZG8Lw5OXYoDTA5Za7PIJt9Wyclo8J+fJ0sDSWslYucR01I
zJ/W1U6NE5Un0WS0qCBWzyymV65izVLDOZugqCzu7ONmJ+d5WQW5e4IhW6Dxz9Id
P7uR2rWOoUjvE6uOKvvW2FbB+BwlCmDz4FBLcfoBc3q3xgqDd4t4Ik24F9NrkWMo
EhPT9jbmZznJ0SbPTIp+ecEUVQ8Qu3SkdMXvlAiUqaE/fEYtPgSgEBHzXtvwsQDx
+dN673yBzYFijZIoW8N3u0qv1UygbK9E6J2fZ7iHng1wBbGVeWRrr9oP0Uyg62ua
v19MvHW+e63kEfOqY5K3Z5O5QBzQITJ9fcqeZhZrorFnIzi1+quA+MZ/7eNFnRDq
S7xUbJNqtxQ0hbZSxOFwi2v7oLT9sMs1iSJdp/sGcUBFGizFTo0NnKS5KCL1FJyL
VO8QzBntAMJ3fxQt+btBqa6LQB2AEllXPhhCzfWIiVwp555VSndbV0C2HVx8GFV9
nXr6VwsUB9zuRazw2JObJIkSVX3HoyseW1dTEDBQYHDaYyGD1/6+FofqSSbdT+H1
QEvlW0oIJYMO4ijgvUfaXVnsH+OSJSooYNGVNf5SJo2z8j9NE34EZVMvnS9jijz7
h0JN0UF2vjfJzmJYxaVeiJE3FOrOXhsQ5DbF1pJt9XoOMJfsXAUd9B9S3F7tj2Sp
1rsrY7sIRsgbcDkGf0qpGEy9OdZsNTDT8X0GyBrnjFqOdvg1wOdR6w6NYP/SlPEY
B6Di/lOWC44lOyLAUEIfixWkS7R6puyZBPjV/52ZZXcePicmgDCRZthVI2Wn0/ab
se8JFgBEjPdRHD6Ceqrq/BRWmYrR2JGpPNkkKei6M6n9u0hzrgFKWcce2Wi3IolB
`pragma protect end_protected


   PH1_LOGIC_ODDRx2l  u_hs_clk(
	   .sclk ( I_clk_x4_90d          ), 
	   .rst  ( 1'b0                  ),
			   
	   .d3   ( S_clk_hs_data_oddr[3] ),
	   .d2   ( S_clk_hs_data_oddr[2] ),
	   .d1   ( S_clk_hs_data_oddr[1] ), 
	   .d0   ( S_clk_hs_data_oddr[0] ),
			   
	   .q    ( S_oddr_clk_p          )
	); 


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
mBC0QIXS3ArUs46X7fX3tM+ffiA3S869l4fxxklpdHmnEyMm79R4o+6pasb7c7jL
dTxHyHjHWaLWOzQPYknxrl51d00epm/nnWwemQ1QiB8NXajIAyPyl2xkqp54bt00
XDRtuWsnIX+pg4s+NeDQq+eFUknjWXK5/5lHoAlcVg4=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
U0haekR1UURlbVlxV25QOEAjz4tlI7nZ8jUWNJmyGYBBjmwk1TnszMfJT7M3Pfzz
l1+8zUTG5sagHTTYaMAJgbp+HR7ARwIVfvqUTBlR37rBaiKZ6xynbYcCqct+6k4x
`pragma protect end_protected



endmodule