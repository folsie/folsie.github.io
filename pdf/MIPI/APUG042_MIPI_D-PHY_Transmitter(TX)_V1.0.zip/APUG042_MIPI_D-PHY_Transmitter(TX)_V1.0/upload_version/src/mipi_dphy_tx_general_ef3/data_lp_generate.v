

module data_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_data_lp_p,
    output wire     O_data_lp_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
jYNeVJgR5AA/Om+p160svMCqqgctFDr3l0OW44296nz/elU12Qz4705NBBQceQnr
j+qsEztreI+WaNlNw8TwQtC/aTE7J+JSOqg8jz4HHXp+JrYd+ABVaXc728otDm+N
dv7VYVYd8yNFiCVxEHa9JjMQyrVunCkFQWYm+8TxbW8=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2496)
`pragma protect data_block
TE56c01sdTdxanhwdnk5VC0B+DaCCltqAclp9PqSBlMuHFLTKtxiSDb3U81MhYDi
W6BI8AV7Hn/wWQqvBmFPWH3FbowyrbofVToqQyunvku7b5ScVyTolVdI6AR5Wk/Y
Skw8SCw12SDWvlLd5QDcZ8NWfmtSmBpT6zrTgjKdS62pAnGbZ4zySeg5lVO1bkPt
n8MnJIXAPhdBHHamxQIuIcwHWT9ZJopVj2vrwDm51wLi5z9rnQxT482YxQcWk+3w
CVzYtS1VEqT+2+5zlaI24fAZc0/5JnFRo0BMgRGaATz28oHVLRiXHg959lKTs5oO
Hws+etCibWfOkQ363PhTvAe+SpjW6Lv6QMDAI+klTQbPiO95zhYrhWMajU72LR3M
/D5tCul260JyFNFi98aJI2EqmDLUj12l2jIQledM32IOiRvrI9F94BOOHfpV7kC7
YWiGqh/j8H6wlCBmmqI/RQYUQ+uu0a0lbPpuvRVR/opLYf8X561aj9OpBHjvokap
d9SJlS2mdF89yrC74FcwEuVrksZUibjyambFgtNnNZsNkzuRPz5uAZGbLuM8Hz+Z
cr7J1lS+frRoW3+m8oAQqntnQ3Pr/ppZi30vut4b8EfItyykPW5nCiJ0utFcISt0
uICYGrfmk/S3uhCtvn+cNanpTJXo2aW4f2A8LupMrLro7ytRX/RoI3P4TrSz3Rdq
44P02joEIro4cURa82ZkWAPNwrEmwQrNibb+Z5Mz1OOOtDEjUIvnC3nG6dUcjjMA
t6dJd/lYgjgfmmNEiIAI8Zn/ghBv5N2uT4X6qSheu1eFzqSk3QI5lNE+Yqe9bERw
gTNWvokggSmTLh7HLRhs9OsxsX/19xqy/wTSXOimtPSyVgCuuLHUp0m0+5MfrUfE
Wz071Ob30hraJ/xivstgHmfPcZCayyFC8tJXJn27VxWubdW0r10ZtDuJLL9+sZ+x
aPTuTW19DHznqGblGh39PLtZWrxQqTdfhq2yYz0lBrMKS55r9dS6P0HFfxCC8hDX
bp5/CROJ/70ocXXx1tBnEbgX0jC3UYA1t51P6nb7493brVNjv72P+vnIGdMfrI5C
kryEutIrpf5GHsOpGWuRaq+rJURwkVYbRVWUxG/DzIrUvl389CZXeOUV/nQlw5Pm
awrgpRRPv/qqDtTcoZko3s6lkbkduW9udOMbxZGPgiZ2VQtdGqODDOYQaOrMYg8H
rfVb//7O0m8tgNsiHBWEAipG1JI8QMyWH7iw/K+L9AFww//haCM1xnEbPNPJ2gsI
NzIvVfd5rwzoulBOggBmVaOmtMJGrh4THNyDM53c68D/XdC/MzLyYjcR9gHpc3Se
XvtrmSEwVWx1m8wN4/p9Q3NbCVPOw1pTJ5zll3k0qA8DHjWcS8KUn0FM5Qb+NC0g
h/69wHHH4Nbjcsu0tdt+JCe3rP5HKfX3NDehLeiJVJPibHWPUkf1TJozKZccLXmP
0OFOcO6AjD3XUaHeTh+CWNICwfsvs2BRBfeGzvjygpwwv04XflY8Grjfj/Ur9i+1
K4Srg9LghbH+642AX/Psi2dPaMNN/N42yvxwbHezbbInUDXW+6g/+s+fwH8M5rRq
3fsTyYlqBl0h2rgjxQBrD6D04/R5L1uRGw18gSl/jpGHQD5oefhlOyMQU21Gxu3u
sa2GC7Z1xilLBUhO4tdLVRSVqvpnwU2+H/kPhPwZJ7Fy1C2+R0DJio41IUltDEpv
m/60k7OJqAFbnT/XZcvFZUxhKaWa1VVjYxfUQHdb97iUVIEb+Fax1dfMOytOYk/j
BTg/hYsemcvjFTGyyPEi2YlDag1vyPERuvskfNCTEDrbl+7DeBEVEYFRJi/eV50d
6Xa5fqZgK8aijVZPtT6CBif8henrzov8RjoEcEDBprOt2drs8StxpftKlYGZ1QCu
MrNkIfi23OGmCMj+HUaVAb8dQD2i9/yl+rpRSPe1ef03CTpvxKNLo25gk2cNXroJ
BCcq39W0qfke9hhntzjMztM02Qb3rhxLmQJzYoi6/lKAap/s8h1MIHjtEdp0a26J
5Mw8EjOS2Ob6AX1pz2ZNrlBglAcUFWNSFXAD+5Y5i66G/wLrNp+3tRYB8JD9e9x5
9KNQ3a44tMhJZzCrOYj8UNv6da61MQlD+22dPi6iJiVkq8qfxmDhDYg8RDtw9tlE
EWYX6Yf2vF9ZtyKbWfHPn/cF+GN3Ea1MaLzOFigNdoiGg3yolSTPPhBOx1z6hq70
aHPKfrfbjtr6jPJqNahvW2GEcPhI/ASnFma6hvyg6vgfXk3XyIpTaxHCBNJkJmfy
7VEfDUFF3rIf7jzvSzeX0zH9zS7WmWD2DCrKXr+RiSiAx7nmbItMNcqPgyNOpX2W
xoMrnPBgYA0eWCTs0ANAqlzEKFUUXn9++Lczasygz6YjwTjBoMQr6lRLNPzoIQwb
abp6CB3Vwn70Qi6GvgP9lubgEgtTFzwlstTAVny+kj3GOIn/q2w0QLDyzbRyWimI
WYXAfzxElM4ouBCcXRSS643raPHovJGll5WEXhsu2CePz5CsPy4F696/7bmd13wh
jT3Ez9m75Z30btRD1j/JPi2TgXIxCjv81DNRLYkC4JNHKC99jglL5ii//FPIDfpz
EcCwLOf7z08SDLANq+e1umlhb2eytY1Af5JaE6eXQJFa1ibkp2K/7hVjuXbEmjQk
SuyU79KZ2itYWgw9mHDB+luTmGpuibGodCDNmFbYbImY9opwpECxouZN/xtaxPw3
D72/+Hdwv1KuIwBVmLI88rQaQHbuN7gxwYxUyHcFh52dyOKO4+La064MGJvvz5qF
E54VGAVK8fy9nIUjWGPo3lFtpyeEB7xNiC1s/lotaZvFtDzg9rC+gW94Sd1SUn4B
9xOuE6qi31nCd24d/frPLTBIhwDrJM24nMlqRUAXsbL3vPMqh8v1w6WiUsdidaNo
8o82mRBhaEVczO3jAOU3D3Bum7V1NAVlvkxqIAJ+thYYr/hwdX3CoMR3XWaGiXRB
Ug2/a/HvJ3mgbnsmmURioAI2046vPC8AwhIaT3XJl8LJH8ihchgk+MkX1D5twGFe
y0C1xt+w3S1346mETdklBiIiS+P379aRCiOrQYBq9x9vyi3ItSOXHUuzHKEMFhKR
1Q9bKY/2w6Rxn9jUhyHWv0KNjiUlRY26tb8dpPw4uYjZpeWFV0gspZw0Ndl8/Sau
84tKPzPilmZs2mbN6kzo4atY+GswbXBdNvHoj8IJv+nMeRQKo3IgjuBDlT+0GpGa
148zBafIqPH6JSdGvpr2xNIkkwtUvwnakT8NPqBOoKhFfTQ0HKWumVjUrPDat3W0
`pragma protect end_protected


endmodule