
module data_lane_wrapper #(
	parameter FIFO_TYPE  = "BRAM",
	parameter DRAM_DEPTH = 50
	)(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4,
    input wire      I_rst,

    input wire      I_tx_valid,
    input wire[7:0] I_tx_data,   
    input wire      I_tx_last,

    input wire[3:0] I_lane_state_code,
    output wire     O_hs_data_end,

    output wire     O_data_hs_p,

    output wire     O_data_lp_p,
    output wire     O_data_lp_n
);


    data_lp_generate u_data_lp_generate(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_rst             ( I_rst             ),

        .I_lane_state_code ( I_lane_state_code ),
        .O_data_lp_p       ( O_data_lp_p       ),
        .O_data_lp_n       ( O_data_lp_n       )
    );


    data_hs_generate #(
    	.FIFO_TYPE  ( FIFO_TYPE  ),    
		.DRAM_DEPTH ( DRAM_DEPTH )
	)u_data_hs_generate(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_clk_x4          ( I_clk_x4          ),
        .I_rst             ( I_rst             ),

        .I_tx_valid        ( I_tx_valid        ),
        .I_tx_data         ( I_tx_data         ),
        .I_tx_last         ( I_tx_last         ),

        .I_lane_state_code ( I_lane_state_code ),

        .O_hs_data_end     ( O_hs_data_end     ),

        .O_data_hs_p       ( O_data_hs_p       )
    );


endmodule