

module clk_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_lp_p,
    output wire     O_clk_lp_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
Hy5qQmp3lMdMMCN00lE4YqWqQxLsOb0orU63AOlyZaIlDInPgbzapxdzaLXlgX+e
NnhIxoRtUd2QvuIZq9fAZglgD3iuoA87sDJpHvFyBl+qBFsfAskfDV7V06jiiU+x
70DDb4+TR7pmXkK4tjrnmH0lDBV+GU94Ye+crphIJSM=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1824)
`pragma protect data_block
ODJFckVxZFM4TjdlU3dZVTM8GAafpmsWMDMlfvJrC4MWB+a+CiDLGLR+uytcIe0S
OT00eU2i/8WpXYMjDwoLRwajOXE/fakS667jUWtSILyAnPjTiUI4OE77PtMgXWJS
c1JFWDqj18G3a+390TSPwFMhya27As6EqNOAjhQFJJSA6Iy5xa5B2V2J68gnELNI
AZN9nLatnS5ybCpoJdHoBvg8eiUPgvA3SV9yDi2Fjsovtq5eYsLd1ME67swUvN7O
cgTGMnLiwq2mu8yb1rdqWDoFnDjoavkih+ezMbA/7+2+NuFCqD4hNKjR2li3NTFG
Mzid/p8E9P+3QUfTn/oWIysUchOOwkvMwrUTvvS/DjY3jrpsuDYlpxLpslFdguCJ
aHoidb+udnBgySaLm8P/5DPk0msYfECNdh0yokJemOkYzD8ZlHV0x5DMA0mLPiUO
qQx7mUvAs1TkWmp2jo+APsGWZIs3+odtGahqyBZ+gHIqeinTNvCAOAB2hyMKk1q8
+PcEcvhB0kzUu5P4yZzzcW5hRkT+WzIQWEj4+2BYa+US+giYant4PQOUSbhZr1RZ
I8+phPNSBDOUK3R5SBpEmesIBHMpQ/SO0aKJQ97A4umlZxpX8L66wG1/GtCmKPnE
nXX6Ht/pcStHYAYXKJE+PgL8xgv04KvKEC1ni13mJKghkwGhFNBe2N6vgYRxm2eI
YeCJRLZWXgCvGUbvcEikQI9y84ozQf5ae7gYvVp7bPtSagg3AGIYK7fVwaUHL8jL
Qwx7EtX13jPXYduBxEBQ18gI5a9/dIOBgmFQLmeobHu9GdE7Ozx0/2Sa2ss2PEDa
86bWJNqcxc7zNPZ0imL3ySonVSfu627MQi6fK1Y0OCQ67BW2tZIAEHC9x3jh5kB2
I4emS8gh4CCbiJs4yu7I2DIE621pdBai9xbloRw4V6/Lu0tox+j/OpjZilgaFHJ0
p9dTA5cImufSa6/aOPo1H509iIwK/oz97K0Z9+CmY9h0f2OZJeAWOep/A+vBJEae
ny8coeBx5mNgL5zyfFU+EVYDyMRcovT7eP+D5gpAuCfwxlZAIYJJSva+5mPycaaP
VUH+2BAnm8vU5TEiJVrWN+kfndB7By9O7NLMqvNHP5gli1wszAl9oWGVAimDjxsK
tXUOTkIY/L4pbkw8juPnKu7JelG9A7vlCpx7jmJm1i1hhhwblj+tGONyLrNewO1S
21Eg/yr6eYs+T7X7MUN/G7f7MjyePz0VGSCppHdR0nkT1qU7TP9khTKgZ4faKgx8
OXeeJMjSIXaQhM5mBfHiIbRe6h9PEjopCsgf9LgEgLwqNbD3B4ttoBYOXU1tonK9
FwWDNO4lVOzTHbnUuHX5gTpcBG1pgnR2DZncFn/OsHvFm3plWZboch+k1IP45TPB
iVHHM9AM9peLE3602J3FbZ83L3BEQjLOiTNGTgCD9Y4VxudJNGUfF61ktpHRA3xf
H3aCfPVz0HNguTKa66YuerS+ax/AFJp8D6hVeRTHCGGSq/szgN6URVYwIlafZi+S
5NZrW+vA80+i+LrTR2tQjgkagCemke4rp2Fwq06IaS3vC/3W+lkTG7spyTVNA/XJ
cyXgairgdu4uITM4vl2bfpSIsQNarJCTY2y7MQCUsibCxbxE9ut+hCsEAkbkut14
Y5TYDg6zkLRqo6t7rCdS/1/izFxUad6l3ZsgArfV62cnyvEIwyOGE/VlKyHIrfVd
QAQXy2SiTcnDrLyJRvyH8oFqztvqcr5Zrqttkf1V6dzYUZadVpmShAHuKJubu+/U
dNs1vr+o2TuWt9xAPo/LkmVWxXftCBZOZbQ2kpLGrA6mpJFGwtrPzKcRQeUh+9fQ
yUHaxu5YlP9b4WU+F97O2q5KBC4pc4j9Uzb7ki/G568fuoIR6Mx4qwxtgJeoUCIg
IxIyGyyXN274F0pBtgxsgCQ1bMQhyh7+cNa7WXXFNBi0+4EeM/LmUlunUr9Tg8rM
3Ap93vBIjjVDhL8yISq7baxV6qTVzLfaigPRcWrwYRyzKgF/xJZq9zwAkImdEh8r
GHzV+DtGoAqd43hNaDpxWlxGJ3gO3ixgJUnu9KkMS4duH0lakvF3hFHSOEmjwRRV
8m4+hrGdb74Jr2tHtD/+rHdJvCYnU3MsuiosSFfjnlbBb1+prBDfl6nE3+1wfMIv
e8vjddjfvA2oidKZuu8pRGM5lDL3W82yoMlgjGLfPCnnOWfs2pwTNFaTD/lNkeA1
xejQfRj694Fn/7NPFwA/KrWosBLFlPik/Cx80BHxhEQHaPPntN2NGYlPeXPzU0ZY
CjhVstLSxxGVXQSMEtoPj9VwEoZqxSjpcCO/NeSl1F5ZQoWtzElHVXDYAMUVBPcF
1aHRSFnhxt63k0zgQvDqmoAfNNdWjjR0yiY0Nttk3E76EbsGU0c1RQmkHyPgeJln
`pragma protect end_protected


endmodule