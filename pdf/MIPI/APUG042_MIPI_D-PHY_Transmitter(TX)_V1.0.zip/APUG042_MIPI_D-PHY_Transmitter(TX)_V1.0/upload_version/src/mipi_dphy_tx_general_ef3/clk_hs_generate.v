

module clk_hs_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4_90d,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_hs_p
);
    
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
LghLQJS33Q9T506caVfhO41gqhKxXYvQXRhzlxCkTV0Lo5lJCVPFCsukLpKDBkaW
gdVPvV9JxvNGI1h1dRq8U0KgDh/4YaTorxRg5ai8c2xeoNbWJHOu/r3027Qnui1e
tLnbnDOMZbuiEGGWDmyHAhbNyjTG31Y3A0G4cxPJVH0=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2448)
`pragma protect data_block
Rk0ydG54YUlRdVk4WnJvSHolSrB/E70cpaguHu9lxq0cwDATU6iIfxd+eXYkw8Uw
nWb9fISw87iQ0oM5H7M7bCq0fGA6VeGfHFJx5pigjoQuHLaUXHmAleTaaLQ3137Q
uxWOJG3QJIZLSLky6oefoL5n4CdHbWDnZIhg/sXotHQEhBYMlHNIIC2Ej7Tp9lEV
9ZotbiB8ENJ1HlxYHi2xhBkKWVvGlhr0jEKbwRtHB+Ih4lZCjYcO6umNvrfCrypz
wYIq3Xfp+fRecc2n+88Yzc2FEs0S1FZyfP/Ns0C0+32hq0Qhi67J/SMlxlWeKHeo
NsxwYKkr2UAMw7Xr9e2pKF/NJ74r4uOO31s0cyobYGBTWfFZqB4b7/Y9NwVdbDDo
BOnSZSziiP+ICg1ZV/0ieaTZ/66/2rIJ06huTrzuyevBNRNO/fEKHdxpwasPGxWZ
JXmOjr3uqG1Shn22gREd8JgnhK6fMSsj7sZvmM4syhuXv3xbzWZRbBsJg/IipS0x
D1gFQObYbTdIslXUwGocN18kgDHr0dIlBI+TH1XqyEuNX9YJ7ZqMhLG0LuaaE+5d
vKOf7yi7+ZLj+xDHEhdGcWNgEDF2IBbj8n4HzGwYKRD/W1qDMUQ6bdO7RvAKpyCO
laRAIOW83H2JE8a6FU86oE57YsU9qVjPmPcb+dE5nn6QCwoHyjOyu8PxpmqpYX/j
XG6sxMHNb1FMDOXM9Hc5M88kEOzyFsYx3EziExwZSl8ZSS00r49jEG2MqbUnM08z
n82yGg4UZvGxzvNvTycF0qqT1DZ6jt10G5aTSK6Vs/UT451so6xrp9Cr95FhunPR
rx8D8h0gYdqEmGb9Nlatd4/YXukSlWQZTyTkYMhkvqycqXQ/X8ap8MhVmouR6ISt
4/s4okoWwGCUTWxKNttSErw9mNUEXvIwDzX1YiNqGUjmGYQUCYNBfJoZ0HhSVi+h
ONNgMwi8A6VD1psCRT0yvytgVkCQX44v07A0M2ZDXyfmHHq1nIzp8O6LO2vaxBJ6
vnRGAEiOPk7njkyL5/A3VPKGBDnmsKft50XLHbpOx+jXDEx9feEqFNizDMk21RpS
15X1JXu17zXzc9r8UKcLTsgvEkRtdNIpq28AWki+HjPZyI6CP72HvZLf6Pbdynqr
lppH5Nv67GZQf0TsadoU9ZT9Mm2ZDKUvi0d4V99j27+b+JNlpcnwNKnyLxAMY9HJ
bynXeeHoQ4Oi5BsIeX1TKbJghaHtOi7YxejsUupoTKt7Gaj7McQ7gFuGmynJvCCZ
0rgHha/ig/jlMHr6AwPkMkHwQpp1i4+WY+oJ9LJFBjiDImpKNAcrUzT19qDtAJ+z
q8KR59IRcCzQWs7kEUcYxGkEeDadaUBAZijAizBO1sZYqljSvZ0TRijSV+Xs+J2B
yo10ooBAA2Lpd1Ofpj09jwuueftyJ5OA+oW0j5Oyf3z9zbCFp11d0IVZSejji+2E
CFbtdFt4qQZ1WZBuChE+w3+kJxabMn7ZyfwURHMg2eWwFNPH56WPZggqcuoTOd9w
IzP1rR59RdQF9KITDm3TLt4pbSUC7C0TdDNLXABdxlypOo4slPL/x8gau3qq1jxL
McYym2oWvu4mThD/ZbWAy0V5G7Ayvq3bQILwi1RXHalKHlSO3VyhZahoplsehsgN
g1tdu04zbPPQQXXaY58OO9mqnB3sYj621jzSUM1TXRKz3MezsxU6UL8FrVG3ZvGb
QI7TOUJ7ft2Dm7YzidNFs+GMurjw+dkJAxd1jiL2rzQXXCNnLOi8yGkktUxQLMnK
0EByGC+jjdUQnQ5MUvg7xRUnL9wW3auNX/xOpHA0wyDIk09eo4tHazFLSeEVOIij
A7WrXHOLKeUEiT+KhKJbrRHann2DiZ2ub4QLaho8OYrPeGFDpOl9eF+YMzlrBt2Q
WcIMmFj94dQafHHEfvZaODWSb/Y4wpr+gfrlAgNG6Ser7ZPO1WXvojPGpTHOoQqe
gE2+oQkgzQyW6OrFVCwvkpt3KIAAO6vILgQejxK9ofKJgM0yh0eYpo/BzRmSrL4U
6H9g5cPHxK8hpRI4HSZPLZFWLtFP0dGUJ7e492JVtU12fKlS9Fv+1BoFFxIHU3mF
KIimhs0J85dHpdTOgznMDc4vAMJeXIZDLOgKWFTTUE4yAmbrQVFpFam+YgTzcGUF
tJXf17nj6vHlvdHibcV4FmGgH9TOdI/DVt615T8b3BE+jn8hWPDXyhdA7jzugVTo
4+jHVfCn3ro26EFAsX+a4joB0SF6kOd9fCKIx12TzStae6dNJigxPYIBey01NifX
eGVGBBzVdW96vmFj4+Qb2Z8LmvhHwDa0UvcSOEEG/TiS18yTw1rd33fiJSylnTFJ
7FfAbzo1Bs/2yVwp/LKbcaYsASZyf+i1f25mpZSUVtfNXN4cYQxXiA/mhqJo4raG
Csem2E9euCCJ/W4i6ksFQE1KQaeo6mIhIiLTpioP8UIr3kh5JvGT86u0PI4BjXL9
+BEbGNfAQOybQGeN5lYWlDuvTfQubykXpZmbWaiQ4qfJdD9vbt/7fH8IPpb0jftI
fJ5F8q0sSia0giCNY2kLpS+3TUQbsIS1oxxhKLeUVY0P9ruzaMDBuEHZBVU60Mt3
PQ43BlaDrvex7M0FEMw/V0+houIuNKoDBEJlWWrMKpLEpIdqRGzs1Lv1c0B+1dxq
o/TRg1C7WLbyvNr/xna5fLhr5PCBlhaqUxL7wG2ovJdufS5NET09xWqmsJCsCXxF
GD1GLRwLDD65Ig3UK5EpaNZH0DqNPO7U+4MmxmJtAWRlsMdr+f/MDN+1i49oOeUf
A8K+R7dIb2hFPaQUejRKlWRLyC28IBsTez/XQ+w+Rvx8G4eDnhWMG7CL5DZShI9x
yRShOujQQGfqx2zbsP6MN7HdM546VWlvkUxFt6OlKyUsO1DSda65OB+1byzC4S4n
OjpKWoK853nsmnfIRqNrnZ+hLJxt0YIe/JOwh7sLbcM/OvJy9+zlzOcvIYTPk4uC
k/CY6GEFvANOjZUawtqDYZMVR1VKz64bGFioB9L46LMnbr59ylG/nm4Qnvjtyg/H
XJgT3vkl7CZxAr7d1t4dnlMJ2sNB+MvMtoWm26KNiAepd5xWec3O5UT5w/V5K+kG
7lVcD+4gqjnQgrDNZHAsa/c5n6iQPPBy5ncqLNNfmTagSJLTF2bejAy1k2ioQAsc
juLlypacXkvlGcAD4WydiJXyTJTj3cm/HTalex2swpKq+3+tSt59lgLlXyJLfWss
`pragma protect end_protected


   EF3_LOGIC_ODDRx2l  u_hs_clk(
	   .sclk ( I_clk_x4_90d          ), 
	   .rst  ( 1'b0                  ),
			   
	   .d3   ( S_clk_hs_data_oddr[3] ),
	   .d2   ( S_clk_hs_data_oddr[2] ),
	   .d1   ( S_clk_hs_data_oddr[1] ), 
	   .d0   ( S_clk_hs_data_oddr[0] ),
			   
	   .q    ( S_oddr_clk_p          )
	); 


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
BFIGTdPcRkuI5oo7pKygZd4FLNbCfov/m7sD7aVAhif8dPPFRilLL3LdC6FJCz0c
WXHOwN95ozClMpp4Tqb3AbuTh9qjVVAuK/ws6M6VIra7nK3LHxcBrSiwaZCpnhfG
1/q151Wu236Oxbygr6rggY5A/m16rk5zDS7ROPjVeJk=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
WGFwNXFDbE9TVkdwUURGN2zgN8hSCqr9rTakasmF8KChCyAPbgjbkztb3Lc99XgW
FqZz21aMs7bex6EEKvjupYR6sfrKgEE4Zeqgqks/Ohnnds6FuTKBYKlY4jldeMTs
`pragma protect end_protected


endmodule