

module hs_tx_controler #(
	parameter CLK_LANE_MODE     = "INTERRUPT",

    parameter T_DATA_LPX        = 1,
    parameter T_DATA_HS_PREPARE = 1,
    parameter T_DATA_HS_ZERO    = 1,
    parameter T_DATA_HS_TRAIL   = 1,

    parameter T_CLK_LPX         = 1,
    parameter T_CLK_PREPARE     = 1,
    parameter T_CLK_ZERO        = 1,
    parameter T_CLK_PRE         = 1,
    parameter T_CLK_POST        = 1,
    parameter T_CLK_TRAIL       = 1
    )(
    input wire       I_clk,
    input wire       I_rst,
 
    input wire       I_tx_start,
    input wire       I_hs_data_end,

    output wire[3:0] O_lane_state_code,
	output reg       O_tx_end
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
J10RfmI80zIlNd5KHmKANm/RlsQ8Z7EODZlQQ3JumSu7KTGvzdQNCBFBzsbtiGkl
MhpxcZ8i3jyAX71GBuRSWmasUbJ4+nF7wZP3EeUept1DAINSoZ1LsmTKlZy7TKTE
LYDj9AGlGzE0sLm9YRGMlkvRU0LeiE3zHc9TsXdmfxU=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 4448)
`pragma protect data_block
NkV2U3hRd2dEaHJlc3pIdpYHjA6ovCbZyPE1osYSBXIKeTKUSNYLxtE90hnSUgqS
+nJUhNmNp0qnhbu3E/2ihc4zZ4PQVivxhRgMe2YeSyfJkgKsfgqkUbd221U379E7
gMKBubAMFuTqVAd4wNlxtpfSZI/6JBFn/vC3W9qbeaiA8tbrJFgltvaFyIbSn1OD
uIxMP8/EB4d4qRObweufPDnd+hp6SF3+thdyLGW4wbo+tfY+iEE+N4funoK2Uv0a
NFSADuF4nOxAUmVEzOxRwvsOCi5ri93j3ZXKbaZMFvh3SmeoTi3YtRiVLvXOVx4J
KrrtMWvitmL85W3PO1CIJUF4M/FW2yULnEp63szphRmmiIYuIDzPVeoJK1m0uDym
mticKrvzUoJGPiU8tRzFxVoXP8qjrJwqPxM0iP3Bw5gWuZBH74NI58I+5dkO0KGH
8Eu/WiioeO6kI1ekbRm/tKf/eM3B8EKzDCCjXhFkVk+z6uRrtHyzy0bTj3Zv0SGT
CvYpyF+7k8qbX/LNdMqsYNK9FZ5FD8PyYZWZFpJ2PVwBWjTGZdGutVrqi9IX2EkI
MIB/Ig5S+96VcFxm2NuWCG/7N9kly1b+T+AOohpPt/rJTVnJC+c8NcS7AYxgKkP8
zmk7bsFBU1VlGbv8xrA5BHVi/S0V7WZ0nRovA9Bgc4iNoMR/HmdYievjppgZopgx
WlFSzZSLedRTuM0ZomurMsq+OMvDVMgDSeiPcVT+Xn/tAkb1VFyfznkBHKL0p7rg
ZPhDmML0/AIGkBuuoum7PGwsVzmqfAbA+QtalmaoQznrHLaxvGHsqzRcj6OYh6Wx
O1EPXb0DWni/UdpbBVdMW7/7ZsadKlomYK/BV2KwN0sVmlGBiYsY2VZAKGcil76S
nqWAm0Tvje+P6e2oWrWZbYO0lFPcl0wY65l8TkNczuO11x7tnst9N4WhSWeiT46O
KzJRoV6gAvKFbt2YRu8KDsV434yqdaGoWjuIostBluYc7HaOAzbCmAXZocfJjo6h
jSUqv7NLOGpD2LTOAmGC9/e2vgjLzPBiKtWgV7YF8iEZz8VgpOaYiYJlLj/28LdY
iATkUXJE341OG8ILONHZvOx2yFQ5E+NWQgbkEUU7SgS70INU63hsnMLM/xgdh0pb
d1s6Q/MkB7ton0NkJh0CDr2vFKwRib5PlE91I16Cz86LZBLMSPQQLKjtbo2rOA+z
nDKC78ZNaSWNsULhVOY2GbUVxAjy/l2CZVjT73q6EaG2W6L8SJgSv+fDXmjTU/X+
j72qRS9j4U4UpnFGINLF+mlff2VdWrbEYmaum9kgO1E1wYgv9iVWXSD5HhS3otuH
2COEwsduRvZrYBeqLUuprj9FCJe6miVUeM4cA5OmCVnWWFgre+0Ib9iJ8odzbSIN
JpO9m/+jjsGEA8tL6fVoTTRLvuBcxUBaDdqGqQTe4quzCAqqtgg5PPVZYFS3pUb4
22q8CuyE5kfEUdLRJ/83zFq4rR9QM+M9ZJtBK1cDlxcg8LYRwOHjrvAS7J+Op3La
0xiwujlPeaq6S7y6ns7OR+7s01FZh+TOu0FpR8GHajDhEezAaI8+aL9fqgHFeHGX
XtaEsgyt3c8NyWJmN3Sg5yIDCeGEsmID/mpayM1b/ya9EydCQpGjBjOC5XqI1RFl
jfhqCJuCyQfIVbhTMlRRcWXCzPa2GNl4Qjcg0/pjLr/LOeR8Osso40EjrNLvWqyZ
QXox1zinMqXiRM1SvJh8J/tNhAUsxeeQJETDi2MLcVZtuPoa9lXZy/ssm//GRiTR
4DOtK6y8cd04cTTBZqmVFFYAboryQEvjZPp/AJ1E1biWNCYrzA6lpqp80ex9M5KD
pH92oEuqn0AnlznPHZmVxigCEy637FpLvi+K18uM51QtPDaRTytd8SJAIzuPjxz7
JIVGZ69iePgS3ha2/MjFqH1vYyHczPIDWBegKH2wV63JP/YdBWkOMx4IwLJZsF/a
yMyDMy4SLCTyOTSah2yEOJCZa5V2YkH1KRt4rsmEoi+fIZmz+ZQ2i2ChUNuC+4fB
Ve8PbDpXgKY610/3ts+symo3sckvC+DUNL7n/xIO2qW0LximXaYSi/w2O2Vyq4ki
eP08hKQvAiSTfkpK3klrafDs7U6sO9k1LnZ07oStDbamYZC747rBjQcWw1z4W5ff
O1OZQYC7povSfxvFITjbJLOglIFGMJc0F7p0lfIFxcNttXubDxHntbTh/Uc/Xchs
f90T2/JzaS708JHi8TFyOPYJVCWXYipOrQC0Uw7GDHY2HT1VJzwOBF8WqZzCalk+
C7IXDyW1iN0KpkfeUhvSj0gdIllcDgJgCeyiamHGOhAczupkcOTQYA/cVlPmZ00U
PSCibxQefUFDfXE2XUtTpTd2FR5W9pjdSdNj6uoKiRHYLMJuCXMuV8prRLrsWlrV
gy0Of1qycmaZN8fvGryhled5wuF42meooOfCLgT/IDMnyHdMXY34VM28wDn0E0KY
pPKBzLxT09ywMcXRtkKWHB6c65sH2Z73xc9UiEfXx4ZuYBfQucNiQnLGTKA34Ktg
Pq1tYlt7G31DB2yNL2CYEBcDZnaYVqwhIM+KsIiwVLMy9yJo1hutjYmZIpkv/CDE
98cmOFRb2IpMHHtHN9gUjmkoqY/6dFmyMfN2QMrM9FRJ+u/+iDZRNCnu31KkvnpP
G49QeA+MxoJ+kLibUvOTISNGY4jM3KONI0iBlGQSdFefHr0DeYLJXmjgKr5vWuor
N8AbTgiY/3Ymu8rVc+YFz8e2FrJ/RzvtNE1TYY9rBcjMURJKjE17a9ybp4rg8UG2
gqPzdIi/DN9+rYSlSQL1OBQsulO1bbF2ghMb/S86/GxmpfQOganjZ8bQ3a4K2el4
UiumINK1LZt3wPZJrOl7hhntV8bymE+6cfdxnaliTsjyOa7lKwd/lSznjTx3v+A2
0gHBErsjqbgP7nLz2wtZUf7zq/ms2HVsK88cwvcStFB89m88hK8NpITnvxxplsim
+gYnYNtCVolakqR6ESlAta9u4eim8by29T7u0Mtih5qFgTerLEt4s31RFCicSQcN
94oLexNP9ZsyHwy2qQGM+HlzEanvg3/T270js5BYUHB11FLBpIJlytvdlxfIwDIU
vTqJ5frDnVTGcht8wSkdDO7psnfCvgwOrSKE8zPAMJ8OVmlPbMPgjSL3z6t8GzNR
XTf1UwlNOB9M3WngRrDOMr2yE/dQWGkJn4zk++AJgFJuqKEfFGyUBZZ6cKtPE8U4
0EdD+HrJp+1TH2cE6+bJ4oABICbqEx6nRtsjts98s2DFUFWTuUDjQewpTa7h7TXz
MuiXpZ6chuw5UBuIz+zJxN4PIBkOL0icmxEcDJFNLp50GfdwQ0NkadF/bRy/ET8g
COPC47vUAYL2yDfdAgEI8F2mKrbtLyOxtfkCT2tPXE4UrlmuSochy8X1tm7EUFdp
h/USJulkt8owGzTGcGyOymCPAhujMpNKHKoEepqc6q7w4eRRm9RNUYcecflkfPxA
Ty4BXt+qQi2cGj5cBqaffuQlmOU3BCE8nMIvif14IoXg9CuWrpgJs7Orm8jlzT+e
O36kBcl0JxrP0QmXFR/v9J/3qEONU36NVMeu0G4RSBVNNZWBTgAXHFEkgzJcYVUN
8RkVYvnebXXunodDIRwvBg6rjn5jum8Am/szU4NZz2kiQ03OTvEL50eb6BABK15w
dTZDZT1vEpndhG8vlKuaYj5MCzrNLqaAPbkksji6MZRjZpkUZ6PHJaN4sjftfVo4
ic0jQGZ/33BBzUQXtIL9EyT/kdjxVpdNkfz+ESGSh1Y8byG0pfbT4PT06YifxaU6
jVROwp49IHRKpTqaAg+qUnkJYtB+yHKq2IcXoj38sJe03ld7tkrUeKnLurY7NpoX
noInIWvfFPAjT13sGi/DmEc2z2SKTV+bNXkSgpjPM/6dzM8NYYxDbxaBvB2GWQJm
rxPtCov2J4xxHA7TEVCrxdgkWIGpTWKde/+/Ukql57bitkVxEaXbt52URmuYgJhq
WYh5l0OlgBDlHZJG3ejrd71OAYkqw4yUD0UudvfLswPpoyEhoKzhDy0G+y0p/csr
urcvPU2hIUpBwQpAg4Y+TiPTv3cIbhvTV5x4+CCw9GK0uFOVAYtZ5yY2LPYTJsIU
LtfixUMxGtH1fOcnn9zDZ3P/FyJ6DMjqo33+I5vy7wuIUao2r38araD1RuAmvgcP
aeBsYEDTgLkpmP+NHiNpkd92Jc5pVwWxUcCfLkp0VYsvM+1lie/64yK5QUoImbo5
atZDJHeLqnoRHrjpnp7kHq5B57G44+B5k1F00vGZNeTRcrZOtjPXEAKtbVdzwpWX
oeQYd9KuUrP9Tq9r6e/7cVODktkczeu8OLPGKq7oN6M3fbORXczwe/9ANtfgQ2mC
TWhx4mtXaKPH94n9fO6AEPe11Z4HQt4fSyz4IyAxG8L0eNAZTE4hAuwMLvTfplnG
xX24tpvtaF6M63gAo4wS7PGIoG4HH7hpzxn3FusrnsP4i+L72JHXtF3KGSmT57As
MEsrcgwYF20TTy5xlcPM5fy3D5+tDuphMhGRfEsNyiP2wcIbsGfo5YAFK/hOQ6x0
XHF9oHcutSFOIKVAU8R6pzgf2Nzvf1VgPyvksMcXxFFQfrRLy9pdojKuHw5ZmWwI
rINuuiEk73vlFk/z51BF0dR35DyUOFFl7vRbVRxGK2YjkejpDkWrtC5dGwZrqI8f
/l0JQax4dVKFPC/S0C4H01++bswuDoDoAVS5f5i2BaKNeJghGnIalvGwUtWQkpLu
q4pPcv7l+K7OjZJYHedy6u6VSpCSqeKdBxoR6AmgRrwr/jGbeTxXSOoZnSLNarDl
vRIgGv+yT+lzIORfjFi1GMHInVc9p/xde5cJbM/XMuYHUP+hzBXxGLrqSVVe5HpZ
B0LkSZKXICNpdrdHlCeVh51DwLokHFRJ/v4FMpKEZvLbV9DjmzMW+/YFZq8RaM8S
0P2dJSEPS20O/lh/7NYzbENCVVVUWCNCG0jQG+b/OWo+0A7u/qySGASEIlCY9tKv
uDSAJtUXw8qAY9/rRyRgOTqDfSKawxER4SVjS1BtNnuUcdZ4TEppj9NDOL5w1atx
oXB5xs8pm+tOZqzqn8ksWv1PXEucAwyrKt93s3RC4UmPZWmzJNAesjchQ6YqrL5E
s4BaMm1mhWBqfnDisH8JuZjlrkXMODz3oRfbs5nMEJErxDj6ciD9Q1Pf6X+++CVK
8d6I8dafJKvN8RTeObYvlUQ5gns/Ui61Y8PZW8WnrPhDH0Er1RENkScRz1UrB97T
cABa74LQqeGRvpuxZXNzAF+d3lLaKBh4o84J0n2c+Zf6jQ/JKuxAVTyxG72A8fSn
671+wulhPUC/MOJ+71eJAG47y4pfbkM1+2piYVvU8fiNnnwhLFa3z6TsoigCRldR
TzilGPZtadjTYUIcxY0x0jUYxwTdrD2ah2BjuC7Xh3hT9cGItpaEQixHRw7NmmEj
ayezLTMpZkW8YbhhQSVtl/i6LPJcRGuRvJzbRIdndC13QuXA9RkIvFQTi3je1PKY
0Rz+Ifa2+IjGu6pVaxN44fHW6tC6KwhDf/LT3MdxiL2eVo2Xb+xR847L4brIZ5Nv
LQc2vD9JVsyD+Yu4xi6svdBq5tjXNTZrPJ7HMn+rikJYud2KJp8dksqyDiKgS1CJ
U/J1NcPi7cdmMIEAuosjaDiLdrAcbn9Xqoi/YNIEWlUDdw7azohLRS+lDaPG46bF
7MAXv2yLLsEvkkyYIh5yu8M5He1M16QlLN4AmMeHdWsnodSvTnNu7l9dGHywoL5b
4kkrADp+OsRBfeHL/T6o1IBO0bCKRfjStNJlQbF9tI1vWq8kfeCpiSobAoyw9rtJ
kPb7Od//v7ByLtv16PJzUGX/WuMcIuFOQcLBWEgtRQk=
`pragma protect end_protected



endmodule