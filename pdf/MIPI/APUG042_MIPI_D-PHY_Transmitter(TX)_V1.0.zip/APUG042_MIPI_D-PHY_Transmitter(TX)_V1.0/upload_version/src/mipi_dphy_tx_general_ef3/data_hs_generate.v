
module data_hs_generate #(
	parameter FIFO_TYPE  = "BRAM",
	parameter DRAM_DEPTH = 50
	)(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4,
    input wire      I_rst,

    input wire      I_tx_valid,
    input wire[7:0] I_tx_data,
    input wire      I_tx_last,

    input wire[3:0] I_lane_state_code,
    output reg      O_hs_data_end,

    output wire     O_data_hs_p
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
eixsOm785P6lsLnwZEIQajXy6S2c36jajm79i5oN5TotGNgLMJL7KYbGTEFk418s
1o11YkPBS+PNfXhScoQ1+xtkyC44fVNjMnci9i23ftV5K+d0h8ZyzMF/bgdQ+zlM
FXufRzC8euVPTmDZJRMluhAq7JDVnQOBygdXcq0cj4A=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 3296)
`pragma protect data_block
d1p2UkZyZzFVcXBEVGFEdeQKGhR5d3x04DTozPijXIw0rx6B1z/gqPkhhPeLGCL3
LPZnQxsVZVouoUSPAy0q4oy3IWhFdADPrma1CtF5pws4HRwLMmx6qVLbZR45Bbc5
jODaLNfopKBH6rXYS3NcHjDqKeuqRqw7XHolcpEVhYOahK4bjrRcybzmOhE3axoh
uaairpEF92RQvyyRctFOHVXom8Jh8ObR9paMlksvbaQuteWmihvBR5d6fCmIwtGL
AubadwW7XMsgc6bW7cGmurgP49XgMrG/oYjPsNd1yx4OqlQ5pKwTHYvjLhqrxJhL
izjKw8JNzWVjZ8si0UFI1lPa6GE7hb+TZ2/CguAj/aZhHsQIj95pExccMejOfCTv
3Yky0RgJYlNSapTFjMZ/2zC3jMfqGqffB8nOQ5KSQ2/puhpg2Dl0fGtU7QKErEHJ
b8RBS1ExZofE15OeDjzbHBIALXZwHcRnAww6sVpIXI3COds6ttjPqb65KkIlHWFo
3vlgC4UkNvBcz6dG11RR0mSnqngi9HMRDYSLqv+EEO0m2sLdt6PfD6Be4HnU1vuN
Rt1Ux8DqTlBtGUGffiSrZMAbpsYySpouy6r11PcZfWE0ndi6XNpb4jyMTyGrwJ7G
DuKnt5pIN/TFSRhEUJnt+cifqvAvOEBS4LTt7JBHVCefBpqXvZGP1Ehc+0AhNCrM
fNokLURwOLxLazZDsgg87UWy63n7aNkqoVGhxrHmgOiXmX/3g8OQWrFid2BXePZ5
jf/KqubCEnBSP4yT+Zb+E6lOwmeTtLHJ7vVeHYOTLumXE7PbNfbrIGhflXC1FmL9
jewiuj39rc4b3YuZWmc6Vg9SIj6vGeXly+ELVj1NELwNZLg8ANpH+eOltd9rgqZO
gTRXrF8rDdRfau/4garKpU/xtcu6IIk8icMMbr8kONAGvqQpb63CQn3907jSzc3c
Xpz0Nt4AKnkbuBkUJvn5H3UoX1ICkEMgF9WXjDXIlfF1nXFiaGPYyhFlwcbAd4tW
ajswYZnMmQwvk/tZMZHV1alfVh0G97O+7IflK7uUDoR0dxWrR2X4k9tGTSYVwmmw
aKCScKGw+OPSW0IHhIT8IZ2aFrlN2saoMgMRdHdSCE2tquxWzakf6QwlPFzgMd0f
2fr8gQ/mQxQpXs/a/wDOnq7h8WlH3D+97XDolaamqjheGxmlp4firnkf/29a7WhW
rwviDz6YKcAMDK6VTvvqOO4FZWbWvUIqp7lBmLgFzgtCIyaGkhA/eFXQ94fXAdjV
McLfK5AMBNz5nrMA3Aj09JxNIMRGakd4MbhqE8U66kOmfeVDebLbThCUfAPI4Lnk
O4KU6oxg2106LxLolYbOn0VuEDmB6+W/gWwrnNCPiyWokjVQWsCyDHtC4BZyX2ep
7dCX0/ZCfy94YktGZG3kVfCOn0tWIHarzNXPQJ9r6n0qIlcr+xiX3bNQGrriDbPR
Mn7Ufun2o/8aT8H9r3Kco8e+DYSnKPxET/cz9zM7E/3S9urLMuJzXhkZpA0jlbK3
FUwQdDTl1RR1xhApBXt0N5gy5HNEwCyXXLVaYZPpM8aIXzbjuyFd3TVU+xwOlbqc
cxsFVdE4W/Y95DANNZbEPrWsDPUKBRN1RDNPArerS8XZ4mtzgUnbr4IUEIiKYbJZ
c1964YC1dZoAsOgxr2Lwf9zjflAAEK/jAWbd1gUc4CWT4fAiAUDiXmc99L9GwNH1
wppcBa/7PvZd/+ohQbGmWTryRrLMgLRIc40WQzlHLm3NNbMDrfiKSv+BNTxC2ero
4ZyMOKuYrQGo3rp0NkRJzdfrHuFxKriP3j1tg6mhaS4AWEtjN4UFFMhK/3gU6MQF
HuWFpHJGw/2+QdLeLlkLEkrbjE0+6MFowavWtElRq2TMITPatcl+cEwpa8hLIpxC
Bwj344D8ttWaEfvzYWn/lNFFaZegq9LHpnG3dVBu8SGSdH39CGcu3ELV929K2M6n
aiwg24zXQQHH/HnWv/GDMxlTrH+FIAbf1eVT6RJG7S2tRZWgBQ1sW0oWJBUsvZD1
zoRvR8XlDSS39ymm9K9uo1KIIJoX5/CyqmkXETgjqs4RSeKZ1V+jueTcWBwBnquP
oRe979Ll+IwOMG3ffknKXWkDNShIqp0ajdyY806MJVQGs8r89Xn2y7+cAr120Eb6
m9G86VjVL2dOLNf0MKtRblAJFoS+wA3YAuRXEGjd5Xed7AJ3fN06YQ+Sl8DFKnIQ
8V+cnc3QSbdFN5pgLTbk0wu5RHLK1Be4ac7OcsfV6qYaxOSbCKnSLCa4UuVUWSfG
vQVs71dURAOLq4K+p3AOQBQnkF00+bRV1Zs3lAE15ApPLHB7gxAaJnEXSXoks4ck
BNWMipAsuAjVySPfY69ByGBAfVWmdJNLjQYT9hBKT4uQxqvGb9rvHbaewxBTVxLn
bnNALZDZ+GM9tUNb8OZu+z/isQ53QVfvqoHFakXAOWiGZtRjdtEDNRwDHtxDjWHi
J9/JVTLxiXkUiRG3M0AXAW9ip2NTse2Jql9YUqlnGh/JKjLGjnRDgw/FfvZfWSJM
uMobLH7f7NHTguJbkQTunbPCZsQ0WAriBQ858kzeDiBVvVJCinWnOBTJtRYEjj4B
QgSL6hoFFUs4fsmgMj6n67h8xCrdE6wFYYiIMSAa0JO0D4PYSl6NkfKZNt7lF43Z
2EAENuFByBiKWz/SCGY74geUWTl/CXY0UexpYArups1Iy5Jvl4N5uWzy/TbGEiGJ
kBgujLpb7/b1f2gvh4Z7+doxU24q6YprdChh8hUr9SnlMbmd2uompZcJgtyJGIo1
As87Mf2msxs3pyH23yCbG14yRmefUMh3j7Iuia9joMMFD7n+YwbG+GpgtPD80mYj
x1b3kmm1hBlhA4zq142kAhnN2f/1K/IovAOWOIxjDHbda1SVIn90BubNImvjHAJF
irR2eRbNECoa+3TNZbID8HmY0dPjHLd/Fg2HeAK3kkrz5p2Mrnb0PGZhUQvVCo/7
vU5ov8GvtP94QfPwOtut2snG1+AvWixbvCChomfgRZvdJHKzrhORNQWywrXS7ehH
d4AMt33N8POSmtTEIjIeXcJ/8nN5PZO/L3GoxS7jJS32xdQ5Imhu4Ha7ygoHC8d7
TMjc1K16nY85etciVsvCayoaLRuvs1kMbzd1YhjCIn8oED14h1hRgib1UVX1grjh
e5XD99yqYlsayKs5nrCYToWd/d5tXT58A6MPjfgIvic/PNmTLjOyGE6AuJfsfvF4
sXnY4uFc9HjrjepySqYsQ9O376F8hLeA/pv3NYYN8scCuk6/w5cTBtYapWBG9YbU
BIKf4aEoOxbzxj7icldNjpp/N96czdq6SRfZ7aULkjSb9IT4UviL6zDvaElKdRQg
OXIAikMD3vjooRznMUVeTSeHuns1vhgsbCJUs2+hTgWzVZxBuCXgekx/un029g0h
8HGeJxqSrFJF+ByBRhA9ZJkfkt7cbiQPLOPpoT11kDmSxZbPaxbrwIYTogB0r/NF
K+hW+VZX8g/I3MHtKcjDA2L+Z+5JAKoE//SyEZEAIxYLpO6Sbq1p6rHtTU/+KzAT
5FAf2BF+RbQiROQrk/0lKCM1Ffse6IO7yJgJWcgRWK46L66wahJxLk8jF1tI6wEu
AW1jFE586ChZkfCaKX7HSg4stPFSATMPr2Wo1+3GuckK6qSWhyQYMPEN0Q1VkrYR
4t9QMZV4OLg4IBFj5ZXygWnev584mo4P/XFmrRmzP3rECdoWv6bhVj2M4uV+6AF8
HuZV89aBi7Yh2buY28STB910JWO1nBcr7Ywm5xDqcqStZalrOKUBW1Qlt1V6si61
1qFzV3TBvau4MSMIlqH0LnoDs9kDvwkeHf6nrmopvgUBH80ZlxMV/SZ6uybXcFRk
dLlnkQE7osUVkABxfl1ggFEzIf3cm6dvko6/C1RJa5wCt8/rWT9tqIGdVVXXio+B
IHDuQKvA32zqIZoNeZ2eT0ID82+3wVsL6U86EaEFNZs7H/r02ebOn0bxcoy4WFkr
h1aiYmr1a1NKtmWJueZtCq789q80u5rNFIGPL1nH6HhFsRwxu5LTEz0iRpZ5pYNd
a0ZUJajPneq8ZsnlB3c1j0VpH7rAtDH3m5MtcZMMdMqRhTOzO8J2Ja8q82Hhmzfd
th0LPhXrtZH2OY+v0y8KV3DVEpykcT1NdppERxN+MF1fpdmq2w1AbzjkSKN5ewSP
AhGPTUWau8Uw8FC0+i12Sph7K5I9xb7fL/xjDLB73SZqv6sRhqKV65oO4xLIrIEI
ACpl3KfSiULMZ1zLEUjK0Txz9vWBjTXvT8MGxG+LDfjww2KeDnDj1BZq1mAT5R1R
UKTrukUkyus8LezEwkQHIWflVUTGUowMGqtG1FN+h1o=
`pragma protect end_protected



    dphy_tx_fifo#(
        .FIFO_TYPE      ( FIFO_TYPE  ),  ///"BRAM","DRAM"
        .DRAM_DEPTH     ( DRAM_DEPTH )
    )u_dphy_tx_fifo(
        .I_clk          ( I_clk          ),
        .I_rst          ( I_rst          ),

        .I_fifo_wr_en   ( S_fifo_wr_en   ),
        .I_fifo_wr_data ( S_fifo_wr_data ),

        .I_fifo_rd_en   ( S_fifo_rd_en   ),
        .O_fifo_rd_data ( S_fifo_rd_data )
    );


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
OD6lOjHyiut0U9DpUstz+xlx0+I4NAeyoocwberWI8IZPyWuIFFQXoSGsX7C4l+0
Mrvh86tgs9sO8DBY93emVM6aeneXY+xqRNvZqVQgxNik6awSgCXqaWfs/QGOLyoP
MckcFRnOgb+WCpTDEWUfFtKTJZJ1vIly3wYjKqygNBY=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2576)
`pragma protect data_block
bzhBYkZ2czNLSk9iaE8yRvAKuCMgjOf3xuajD4H5BtdQRtFkxGsHnCHJLCZJbmYK
IUwmWtOs3lZTOCplIKyF1Upq866osi+sFCQVsK5KeVKJO0hKOyQdK5lnaDt9x0AW
cmoUdMINBwzsM72hFjhm67G+r8bB3/Hcpy3wssCILwx7DI8bBcNmwqEVck0N6Ync
Vo5gNU/Qv0VfQiUpeUFRbHIzBzQBnB+GIY258+s0mk8HTCPo3ilW4oiGgM6JqIWK
eak8ynfC9v25hfpZLklM+J3XBLl7P7QuNs/WM8jLrCF9F611MZJ4AMaj1xgH0Y5T
QHgjYfQxi8/q6+hjqPuhZdMAMWH11bdL+pEq4bfffazRK5tunH23rBJTKuDOclZ7
b/0JTE9XwOi9y2QQz/N0DvOivSXYD7uunxMStgnd08fPm8mr7sT/sWnKOs9zojJX
OGAw7wfobvjK+JncZiwz95ANYo24HLhoKnXnrsaBLuoMFrzzNyRQ0DNRd8MufVdG
cLhAxyoQxdPnxN2cITy0aFhF93H5HA4Vn7xnbyUupf3PCeiW2b92HqGgR0YUNiIH
R4xtRNeKLZUvjpjoOr6z7oNb5OYyjykueEvO0hFgRkY0V4pHjk61CDHny7kEfAvS
Kzce8gnl5TubHSXk87jN+6oFxkmkxPtElRPBEMC6xwIPjD4Gp4ua8ydizuiRiNBk
Jv68lFL8CrKL1OPXeHMSv4Pe73iAaIPqI4wb6bLhfnSnyPxAE9dQ3NUhyzIg6quu
wnzn8jqWlQeItkHHMkLqRsXzxy+nmfogRWDk+1kYVOCirEe1Rvr/Fec/mh5oPc3l
8qMpqSsaXCL4nnTGWy6oAX7Er6tnJ4B3jhGdeED2HvFiN+FdesOL3upRV6t8/e/E
3hbo8JSxwFHafoeA7yb3tDc+kdFHmPZoij8Ly37kX6Gu0rod8MJWa5915SSQlmkr
YUpzYedsMAjqQIkjfgeuWeafihVOZQCWxLj31tGFje2zrv29PidY1gt9tfLUwWog
OllnbOUqWqA0One/cdXK+vRpoIXmQFl1JpqA216qugL1kp3yomwX0elPQkhlfj5X
F9b4BzEgHl1FhWHb2asHxq6WeiadZz60F7nzOhAkpQbuldwy+EB+CeMz8p03KcJM
20fBAm+aXIldU+xtvSpJs5G4O50Sfnhz1pjk4YWnIrOV5L3DcXhhgkzngL5s2WLE
MxanpZHQfVAdD9xs/gpoisulkJp3kzbMg4NxT5vaT8hTAxbXon3Pzrtgmne03ewF
BEHC3zRO9UaZUxNBSC8I9Z62nxSeauk5XsWDwCtHRsSQ+3/RPdxKfupOYvcpX4EI
7UPJmqt+p8lo2VdSBEuWkkBaQGiQAD4rnmUvpMSdcyt/I7fDnCOHA8bVx7dbxw12
uKOpskqk2LPGwmo7DApQVscjZfY5d3VFppoM99fNTu36YbtDIVSCB7mT7ZIYUfCJ
1XjNTUarX/8BWtZu39nWC3rQ8ygRMjw1Q7p16kLiajhxZPUFCSwp1LMmLgr2IjcP
gMaHhLmj1Ral4mN6VJMW1o+OIt9butp5LzQRJQLlacdY3d3SVWB+xON8xXDMnMCj
ZrSapMnd9Mn0jqt7OxQHWQO99jp2xsgr8D57d5eZf6sUyObPcbH4cTtCf+i/WRKK
Qdtb+hXR7YVy0wHoqewIIL2RFQ9wjie2GHwM9vUdWRJXoiksT7kbUJ2L1+Ct/fsB
iR+Ay3jv/XL0l8h7i0avScVlTc3Ez9NolpS01O6bfE0P1TbsWZ6B1UAgkB/m4QyC
ZNcgQCw6ywsMniIonrI4+v5susY05GsUFRPb4McvNZsjoBYELt0FAI2wKgnMj62S
JWc3w5i6g1Thu0Zz144AyI32tZ/4fIZ/eYauKXHSuS6Zwlj97tZlxFFaYOZOm7Ij
lyWZF0bfio6cBH2oUU/xIUJsPLqilTh5OV9E7nd3TqHWIymMlMwcO0mVcFMVFvV6
TIBs7lrLQLpN0/XbdccEaS9Qd46L/2rfauTPHGGuKxO9s3yV7ZDrM0RhUmZzi4E6
/u8S23SkML71yi0a7vPKIjCLaLMAZ+JabA70O2trNsEfxMCC72ukSbzH4O9JGgyB
ooNnqAQoH7JZljbIvc6m1+u7Fj7uib0Hg79XtDs1ZLZwKQggQnNK/HwfZDBoMo9G
FuzvyhghG7BuFZhspfwhMhvARyKc6zVfjr04Ky4lXQAVr4AbcwlI4vTLP2bm1xNI
Fd2h4GFQV41eGAWVZRgDDj1iDHXXQLLmRbcb9pG+8hCimsWJBFrEy3490SjKj3PE
+LdYP7ZnnWlmbt+PROSJOnlEetCt4EhxnALEdXZNg4f2TyWUeCQc8tDr5ISNA96G
tKDdx6FpbCZMOcSklayrMvJn7tJLD9RzP/kq9H31haIiHspgkkgWSZbD9akFmI9b
jwrkapHVqOWbYBduuEbQLg/9YbnGBtHwjL0nbU7nQwOq6wD9JPFhEUBIU+ozCbVd
hkflGwbB0RXgsEQrUh9cneSJh8AnvqzPa6CWebCfLnD5lLfEOW7cCWHpNKBFJfxF
hKG33ozccmPfU1XZFkA1/lrReawIZfF7mx8qibqDorHNHjAFsiCpEbundYYP5H6V
UcAW0QsPTxqbY+L8KZ5wAvHBZyrrtA5Mu3/qDyJWYZ3eU85WIzkgkyOvJwPRdvhm
Y0Egw8euhLize42gWVoOcigD5fxQhu45NvCFT17C3zDGzvdpQCpZIoPeZJuVoUud
rXs9/inqESreCWBORjmHa7BrLl2eyMPgItmX/D/D/6yvC645tooW+imM5wn38dg1
PsORvNzQxCwFM2hMli+FWhgkK7ZqFfkPawYfHoXAv64RLG38DdbiHL0zaFknkJD/
0JDpZYnohOt2skMPFfxuQt9PxdIYQQhzKJmuBZCRryDhY1azlPLpTqYBhzKU/pEh
J9LbCWU9AF4hpg7/EH7qDz076GJ5wg/+MdSbM8Wst6oSRiuEsbtMuDwR3KheHV5G
ikeppguPYWObGQIpUIuphQotqfDtymlvKJHIBDaWsALTgOfMwsNrc0NPK4o+Hv6/
hJ0p34bJH+Q3PBQLofHu0ZMjb7Lt9h436hD0bHAzA2O9gk0zHxA5UUp9Ukg7MJkH
hxUk2SmCz2ZSyY3msemw+w28z/4Zzq1A6pDqnpX5ZHeNm0tIq3naulNI4eMIs6m3
nEuK78bJoqPuhEkfhlaSrtP4+YtKLKPxMWefonko71I9edZfuErYc8ELGXilUIkN
EU7MxK8xyM6Gs40Ky6jvObvO7JxI8QH+uFufsU0V8tGnC5tLF0Z2AM+TyTViebG9
QUQpv0xDe11zgRrFWM1CiMi0n1j5R7sfWU97RlZjc93n5kd8h2wiehXZ/noau8bT
p6SOqCfKa0CcHS4fQIWBJsnGDL6Gi1o0rBsaF91pglA=
`pragma protect end_protected



	EF3_LOGIC_ODDRx2  U_oddr_x2(
	   .sclk ( I_clk_x4          ), 
	   .pclk ( I_clk_x2          ),
	   .rst  ( 1'b0              ),
			
	   .d3   ( S_data_hs_oddr[3] ),
	   .d2   ( S_data_hs_oddr[2] ),
	   .d1   ( S_data_hs_oddr[1] ), 
	   .d0   ( S_data_hs_oddr[0] ),
			   
	   .q    ( S_oddr_data_p     )
	); 

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
lp+oK22ZiOTKUPg579nEKaVImnOr2RBZINF3qHCTkZtKIbLXGb7Vw1PVv9d08jY8
2o96b44s59h9B6LWxpRwi51abkDrjs57EmjXXNDfVUOwg4r1NR7mLBHn8675k2uU
R4K5jgZJPiNxAsX3u4IEZ/IIoD8hTV0mHy5xYIrxHyA=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
WWZsMUZEdzQzZUtVSDNlNg2CzPicW2ATmvOXBIMLnaTb8sEMUSNpKzlPJwFuiJG7
cmTXvuMxOXsGYfXJ5jRDNkWcR5UqthBQc/FH1N6Qp1YrhL807+43+hC1k9OoYMlR
`pragma protect end_protected


endmodule
