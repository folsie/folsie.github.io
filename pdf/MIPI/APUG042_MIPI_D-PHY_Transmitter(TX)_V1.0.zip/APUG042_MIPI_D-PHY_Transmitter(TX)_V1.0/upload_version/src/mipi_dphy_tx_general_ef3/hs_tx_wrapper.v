module hs_tx_wrapper #(
    parameter LANE_NUM          = 4,

	parameter HS_TX_FIFO_TYPE   = "BRAM",

	parameter CLK_LANE_MODE     = "INTERRUPT", ///"CONTINUE","INTERRUPT"

    parameter T_DATA_LPX        = 4,
    parameter T_DATA_HS_PREPARE = 4,
    parameter T_DATA_HS_ZERO    = 10,
    parameter T_DATA_HS_TRAIL   = 10,
    parameter T_CLK_LPX         = 4,
    parameter T_CLK_PREPARE     = 4,
    parameter T_CLK_ZERO        = 10,
    parameter T_CLK_PRE         = 10,
    parameter T_CLK_POST        = 10,
    parameter T_CLK_TRAIL       = 10
    )(
    input wire                 I_clk,
    input wire                 I_clk_x2,
    input wire                 I_clk_x4,
    input wire                 I_clk_x4_90d,
    input wire                 I_rst,
           
    input wire                 I_tx_valid,
    input wire[LANE_NUM*8-1:0] I_tx_data,    ///[31:24] -> lane3  
                                             ///[23:16] -> lane2  
                                             ///[15:8]  -> lane1  
                                             ///[7:0]   -> lane0
    input wire                 I_tx_last,
    output reg                 O_tx_ready,  

    output wire                O_clk_hs_p,
    output wire[LANE_NUM-1:0]  O_data_hs_p,

    output wire                O_clk_lp_p,
    output wire                O_clk_lp_n,
    output wire[LANE_NUM-1:0]  O_data_lp_p,
    output wire[LANE_NUM-1:0]  O_data_lp_n
);

	localparam DRAM_DEPTH = CLK_LANE_MODE == "INTERRUPT" ? T_CLK_LPX + T_CLK_PREPARE + T_CLK_ZERO + T_CLK_PRE + T_DATA_LPX + T_DATA_HS_PREPARE + T_DATA_HS_ZERO + 5 :  T_DATA_LPX + T_DATA_HS_PREPARE + T_DATA_HS_ZERO + 5;

    reg                S_tx_valid_1d;
    wire               S_tx_start;
    wire[3:0]          S_lane_state_code;
    wire[LANE_NUM-1:0] S_hs_data_end;
    wire               S_tx_end;

    always @(posedge I_clk) begin
        S_tx_valid_1d <= I_tx_valid;
    end


    assign S_tx_start    = ~S_tx_valid_1d & I_tx_valid;


    always @(posedge I_clk or posedge I_rst) begin
        if(I_rst)   
            O_tx_ready <= 1'b1;
        else
            if(I_tx_last)
                O_tx_ready <= 1'b0;
            else if(S_tx_end)
                O_tx_ready <= 1'b1;
            else
                O_tx_ready <= O_tx_ready;
    end


    hs_tx_controler#(
		.CLK_LANE_MODE     ( CLK_LANE_MODE     ),
		
        .T_DATA_LPX        ( T_DATA_LPX        ),
        .T_DATA_HS_PREPARE ( T_DATA_HS_PREPARE ),
        .T_DATA_HS_ZERO    ( T_DATA_HS_ZERO    ),
        .T_DATA_HS_TRAIL   ( T_DATA_HS_TRAIL   ),
        .T_CLK_LPX         ( T_CLK_LPX         ),
        .T_CLK_PREPARE     ( T_CLK_PREPARE     ),
        .T_CLK_ZERO        ( T_CLK_ZERO        ),
        .T_CLK_PRE         ( T_CLK_PRE         ),
        .T_CLK_POST        ( T_CLK_POST        ),
        .T_CLK_TRAIL       ( T_CLK_TRAIL       )
    )u_hs_tx_controler(
        .I_clk             ( I_clk             ),
        .I_rst             ( I_rst             ),

        .I_tx_start        ( S_tx_start        ),
        .I_hs_data_end     ( S_hs_data_end[0]  ),

        .O_lane_state_code ( S_lane_state_code ),
        .O_tx_end          ( S_tx_end          )
    );



    clk_lane_wrapper #(
    	.CLK_LANE_MODE( CLK_LANE_MODE )
	)u_clk_lane_wrapper(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_clk_x4_90d      ( I_clk_x4_90d      ),

        .I_rst             ( I_rst             ),
                                               
        .I_lane_state_code ( S_lane_state_code ),
                                               
        .O_clk_lp_p        ( O_clk_lp_p        ),
        .O_clk_lp_n        ( O_clk_lp_n        ),
                                               
        .O_clk_hs_p        ( O_clk_hs_p        )
    );

    genvar i;
    generate
        for(i = 0; i < LANE_NUM; i = i+1) begin :   MIPI_DATA_LANE_GEN
            data_lane_wrapper #(   
				.FIFO_TYPE  ( HS_TX_FIFO_TYPE ),            
				.DRAM_DEPTH ( DRAM_DEPTH      )     
			)u_data_lane_wrapper(
                .I_clk             ( I_clk                ),
                .I_clk_x2          ( I_clk_x2             ),
                .I_clk_x4          ( I_clk_x4             ),
                .I_rst             ( I_rst                ),

                .I_tx_valid        ( I_tx_valid           ),
                .I_tx_data         ( I_tx_data[8*i+7:8*i] ),
                .I_tx_last         ( I_tx_last            ),

                .I_lane_state_code ( S_lane_state_code    ),

                .O_hs_data_end     ( S_hs_data_end[i]     ),

                .O_data_hs_p       ( O_data_hs_p[i]       ),

                .O_data_lp_p       ( O_data_lp_p[i]       ),
                .O_data_lp_n       ( O_data_lp_n[i]       )
            );
        end
    endgenerate

endmodule