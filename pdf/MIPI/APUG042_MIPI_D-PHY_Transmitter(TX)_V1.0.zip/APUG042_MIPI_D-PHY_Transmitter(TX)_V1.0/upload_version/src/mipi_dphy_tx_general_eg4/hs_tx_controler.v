

module hs_tx_controler #(
	parameter CLK_LANE_MODE     = "INTERRUPT",

    parameter T_DATA_LPX        = 1,
    parameter T_DATA_HS_PREPARE = 1,
    parameter T_DATA_HS_ZERO    = 1,
    parameter T_DATA_HS_TRAIL   = 1,

    parameter T_CLK_LPX         = 1,
    parameter T_CLK_PREPARE     = 1,
    parameter T_CLK_ZERO        = 1,
    parameter T_CLK_PRE         = 1,
    parameter T_CLK_POST        = 1,
    parameter T_CLK_TRAIL       = 1
    )(
    input wire       I_clk,
    input wire       I_rst,
 
    input wire       I_tx_start,
    input wire       I_hs_data_end,

    output wire[3:0] O_lane_state_code,
	output reg       O_tx_end
);
    

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
h5VJtQjHUP5sx9nmn2vEvBKrnWuUYJaS0Rq1/eRQ4TcGH6QVsfTIfd2cbHGTYT7J
0Hp/8Ec0ltK5f+GEQAvw0591crH4P+rjTcAKiA6zbvRoSXtPuWJdjfCi1YC3k+zV
H1HSGKvUVbIaTf7/w3h8ao1OKpkuI//31u/RHMXY7Po=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 4448)
`pragma protect data_block
bnpzTGM2Y3lQVVJ0b1FFRGxaPOgGXK067swbAQspJAKNiFd0W+/xlDOpdUFecEYV
rQ5McFddYpeeaNFEREZadQTUcREqng98zxJ9HfDGBFoUhbr8BH83wqjS/p4VJlhQ
NXpGI2a7wf1RzSdn9FkNSfeQ+wdUfMCJaXW0VfBdighROQ+EBdtgZ9TcKrAxzB1i
CUXePSL/3jrxx1uLsohZYG3pIzqVWB1SoVn3pcfJ9+gSRzLWaowJLi2gw8zf9XzR
zQkHMi2DEIaV5nvSufr1WMRJyTDCNTFDkdL9lIU0kvIP6P/V2ndZb+d5WEZfri+t
3XIhd77DnjedonJDQSNl2/wTKFsEml6C68Nh+bAGOwww5TPvcfOtnVKrXL5CvrlP
J3ccnfjtQK5/NpHjztpdj1/wg1vzijG7y7MReMHQjnCsuX0GyhJggDbyx7j92q2t
3hDxPMSKpFp81+7eRho6EqdGJzfSGBbwKlv71DcGC05uKO+R4qFNQmEjUbjKkOmr
Cm3F6rmJhbyzH+TtfQSw/ktRG52bB5w9jfBgW9tIfNgKY2vvELil+0YxZuBr3l3N
FmURyeYsd8LQcPklyU3MVT/CQe7DjBy4wDfi76PyEDPEhFBJTzZISYJ4gxn9phE5
SHJOxkz2MVbd6LYPcUu0dahg2+ZA0wAVlwfFJcXzIMwMWwlrfVbcD03Q34aCXoVs
5cMzRyhu2I9ZHbqjELbkLLerEB7gtoaYVGw2ug6CO9n8ybxa65fppcAhfhQRsy8N
L77m5qlPnddC/137D3YPwR0Q8XQolyjGhur9tFRQHF35YBYboJaxBFfgiZwi+yat
gZ3Z9KW4qCcH8cz4skXi3jeW2k3QU87Bhop/JzNJ/bOtzAUsF8T23vk9Pd279lA4
CXixvN00k3KutXcBTT1mDr3qrMeVULvOAKsxeUr79Op8EhSqEpdRLlXKoe4lHpKK
dYDJfXr0qP2FH9kLJrC2zH3en2JAqCqmdqymXcIPU4WVztgQC7yfygKCNw9ua8Wg
lFLUGZ3AFx9k39iZWNcdMn+OX0+ls+F6LqhFxABz/7zqQ8U08LE4djhMdmdcvJAD
kOcjDocX5+u7Y1Bl2Iy5czJsin6Xxy+Vuxswe8Ug802RVZamPNY9ZZ8g/P+B4HZP
QIf83L6tBQKK+6ovuUXyAH4MRiXUuZjT6qxrpLFUjnT7Ap2H0nA+dsvOjwBaSOLo
5WjNx6mB7EBWrl86O+Tc7MfoxWjXJ6OKrUTr8BWbbMOGT/fHFTiWU1uVOKQfXmOL
3ksFNKLRX2v36EjQ3lkajunpCO4fmz7EQlwYb0c9aaIhBHb71AEVDOAbZbkE2wqU
lAQKjLTP4Pfc7DjmfYhpJUI6XNox1R1wj22esSsfVD0mEmClNg+r0WnPQflXwzGA
CC89bbb3tuRSyZ04posmFixz6b+4a8fD0S/lpKJXKN8JJj3ZQQHT+Wn4E0DUDE60
mndJYUaxPpoqVebcbkXUMwD0pnyizPE20mU5CF+mOXYb3+kJVVOD+vITKTMkyVGq
o4Q7wtLdbzHIvF9ZX7HqPOnWRBGbIr8nps2BbBV8oRN5jsbWK6ob8CIfEmRBI+qv
fZ87v2UNx/YgvDBGdZuAxXz4M5tPYUbydPZzNY0qgTl1wx/BRbXHFjmr7u5wajB8
4ahR3LIFG38yTJiRD4eBmNx5QVygw+efcqaOSFluuuBgu6uUWNtkLg9VHfzmT+oK
qKJn38+l9TK0MGlk4vIsAMnboER0DoloHQH6nMiZCeKjZcroviWSozqlLwgPwueQ
C5D6S7ziVwT5PA+vdr/KrkPaqNDkzK5cBGm9xxQwe/ZsVXBmrKGemWXScjNRwHbo
TbmYmox6FevApQwboNJ9Ergl1tDPXHunfbHpxJ2rkB8BI3CnMsrRBieTpyHhd1eB
QQlc8PuqeIzH/suPDXeOlg92cTDPhUN/ouVgvp6pzwhXm5p2BoEsl0EjXYBp3ZY/
hbizNZeqO8Ol7Xm+LSaDPHm/g/Ls77Mw/aF5K7dJoC6e8VgWAo7Ql9CTaaONRSGl
3/hPDuSTPkhdnbkmVul8eCJnSJb6769T7t22COUPYXNsJ/TMYz+5D/nd8nGU4T91
/uzm0aOuMpj5hOMBWKs81cD8w0NejDT0l5uuSfLEbNqGMx9fqG3f4+aQ8TaINpmD
mtcr8NhO69lyIm3lhmri/j8XyiQdQuKl9PA/sfm+XHIJyf/Kx9MYqLUbd4rIvTXf
Zo8Db0Hg7Qelshc+TGasLGnPb2LUYLSmuJh1eb9HF7vyJ/0MltZdxqwTdKWn5Usr
yySONUJO46AekH21xAKUGm459cpE0LSgdNKfa6jHpDZNpsxvMmCCpxrLeQQyNGxr
WUC83KQdWKVMEj3EyQRELqNR/u3843iNFzWzkUmbgoFWVVPqrIf1+865yUlxtlaD
NHeCJW+vgqLESbT8elqGdty+71kAptQ2r2AYQX+ETNkL1MmBtP+fJ6oJFEfjZzks
olt6ZF4jMMoNN2gWQml5VhyeGZq5NQxPwB+TVuePsYBE61EhzjTwWO6En3Mgteei
QuQwgymag0vaJw+lEpG66sBrJ8lsaJEwQbqq6itVw8smCUlHMP6zsCXM5qSTcg5R
ArNjbI36s7PRw0bM0+EwsRuQ4hv4N97I/HUeavF8K6XJDLI4nhycnSWL05ptXIJZ
nxCma8mtfsrvsOmc892fqWRv8PTQapV8rNn6jNtw9lt9bHQ7avHoNoyavf+CD2i3
aCUq+ljoPmVpaI9ybtjmLSUhQIs4dqqiahQaEoQzi5pCgIqnDoolGVVnwvlewAO/
Gm5xQWtBhCA661M/QBeLYFDJ0lRkoF5f03TUeB+nl53lVxFYQK7IEGyOUZPnjLHu
9GiXF1rDgTG4DrvHy/cLRtMqSm6bZOSsnVS8eQoZrmM95+5e0ZPQEHWA9mh6r/vW
gPX6BgwHsxETT8+4ED4I3U25dY53quuQ8/867w3mEwOV21eXKUOa/X2spfFOKjRj
zhR39YDCxk2nyJwAITgQGTNvjrl/5ES58D7WsG8o10x/cJWK1p3DFgFvJiaLf+O9
YMwJpCVrSlR28m5SrONk++v9jzOxTgRY/geXnuBsUZhZnFHXcmdpNwoFqBMJV52M
L3tQmBdFbBa72OdAODo44NUdMaWSiIIY4fh0bugHB86xhHr6/cAO0urpiEOKs1kV
5KWhR0EqkDtksO9PP7wDnLx87BiUpHkxetlcGtxSQz6WEi0vRrfD/PItm2YSVbzO
fvUmJD64AZ7ICsVV1poSzoY2s3V3pNJygjFzMACumo1mvrosAmniUdVdGcCdw8II
pt+iwFXY3+IbOtaeGdY/wmsLqo5kR1C3zPdqGa1gUINHN+DlPn/bJvgyJauO8828
0/YVpidlk9WYA6Wj+Gs7nZdw4cNGAF9G3jEMatqgWl7pyAqDGaGjSPNXG6QyE3hZ
0+oJYTQJdOdRzFP7jqAK5FBj+OwzvlMXbbXDC5b9ucyIyMN4FZbUG2+HuBh7LH/m
4/4NA2314iybu+ikoJ3Mzr9XLbv9avnBR2PSvS87qydxbXqxjr4fy04b8nH0N/H5
Hsg2G72xMRGefOQqcR2PtZJ7L6YhK821ti85O/Gxtt5xbfVusx7YdMblxTModjy/
uN7xGUpV79g9ydW0X22EZWdJcFaO1jb41CnnOD5Y+QaQz+7hu3ykI/xAu2PxG6Ox
zde/8LUO/RMiXRenzqEnDQl+YhDoQGRGUVD+w1j0Yn/nYMCJvW2G1s/sOxM6pHM5
XxXOIjfuwDqsHJnYcjLVHJmQZ4RHBXvF3SsdCQea+4hcK7f4EWKTbQIn+p69OFjE
cNcDm3U+GB/k1L7CyotoNJ3ajxWHU6qPHymZgm01tSo2eAk0SG/OxV9c4m4wpasB
snU4Slow0C6LhFWk6b/qzTULLDG+emekLQPRgcX7tSqeF7bzg0uTqKGxPGvOLkwX
c0Irrewgf7bc6brWBG/TK1k6SD2Zwh9IJtgZryFGg5WKkUbPPCa0Om6IUaCv7KgB
wkMrHLkHf1tW7Edf8l4XEI6+pxPDS823GV+JEkm40yTXfl0GW5U//pGQfgnA7vZN
Bk3h+JkAjEzrT1oHhK2J7ha+44kU8asv0tyuUuyvlbmSLxv4f3gsCJgePU+Gu0ex
/zdyiO8ZsevGJ1dYiT3SnHpAtKyw3DtT2AQF91TH3O0WNK0FKI/5FUmav4zfTsKg
wpv19BdHMVabO6QYvQ/Rau7H/rRRv08qQxQc64JmjR9pOlUojw3p/clSLIyWXmHC
KXVd6BJQbM0GIWJ8lcdPr8gTqShSeUM1zsY23XfpiHJXBsGaHdOUSqKvI8W79hmU
mvrUGxKh5uOqVBOS25MshxCckI7nJUjVQGeZTI3uz9u/YgDHGgdPS3PiRuwTfD93
pOGzGtnv/BrN8SptGNf9D0czq3U5YkfFmIrlosXknWJdg4yh91ZME6qYlD8Jpm19
bswrej1Y605j8jWEzhgTyuuOpNO4gU62YGdWY1eqP9Pi9zsUWlyr00IJciWlmN0D
tBxCrUhXClKD+wWntq92o+XDllWh65wjQKw3gxQNdo5SIJ2quiP83z2rr638JllH
nkh0nSBMfvpFDNUL4ZtC+mp2oZHXbC3ahTw2KbZOeYwmqxdyfpGvBUK9zCoFT6kI
4c8T48ilsTiNrKhzs4lHZeO3s2myPAxtc9AZjkqK+UIqch0xvBLz1/kQ66WVeiTt
2a9MDhXtswz3Hw1LIwOrsC5xsHrYxo6o7V8fJ0sEuaAg0+cBFiyxrbEMRae/YfWF
OYKGhmwHvLrRSpujClhTguZEzqkmraxe9giy1+72wI8c1ZGOqATrLUDt4hwiAZlr
r0kEgQ5+xQbkBZebrT9tX/ihtuJxsdgPMU+a8sQgjgnA7eHg43G1iYd3ogLHx8lO
Hyy4ZnnaDiNDQkzaf/M3PDI3q7kQkJU1sQ+GavCYgi8qZ7O5z2Vlwon5PjXI/emQ
VtUOYkw4oCmJTC5MePXQgq/UN7+vtPIVxTNyvwo4P2sonAK+y4T+xFsT0Q5TGQzu
wjcbwvuDfo40SVgmdZcv0LLImtaEPrjTfVhj5h17PF7wTg/MwyC6fWRkHn2E+eOQ
/j66usHzSvkNywYgz9ldn7S/4ouoCn3T4LKWG8a6Ps/wuPiEGMvCGXkpBxPPeARg
zs4r2SlnYFL65Z0vqoHq691sA0hn5tcRGYAoaPlhKixEOwKcAUUzdSDKMv19YLq7
27t+h7ADnSRcbCqqDF2mQnvvIYXNtlBt/Cd4fxxStAiRSaY9k9QuJuQNsnXxwbu2
SELynmb+kjwjaj7bPziEkO/FltRgM8Ix+JTZY+M9vKRwH/Gt8GgN6fYxLqlJlbr/
24YRZktI4gmew1cie+nUjKvKFH2rUyhabfx1g+rG58IUB5BL96z4/trFSpT5uYR1
nxhEesB3h/oAQdMSbXq0n5Po74Pk7wqXwuZwvksed7VquGzETXuARxoLUqyjI/Zz
oFVIKxbKWvnVwCZH1l87bWry3ArGRzA+zq7tArKRPrE7jzK1zY0zlZP+qo6iy4zZ
78plQoAwmQ29FJ0z52rMkH9Bl/w7ZexPmq7JuB6sbndLCaCRXg328U+BdCy4FkwF
UP+XzbcGC6kiDds/sP86T66zFZzmfksXj+myJ4blXsH8ge5bDFtFM/O9aYSILqlu
zLvy4j1B74auo+U2JqwG7XifV2UC5zFE0C5hNTSrHIt2OLZ7MGdnbTk4mqWzPV5S
u+auHW+T0RnjlmpiPCMSVros4wjUQeQksxmDOyJUJz/BmpkMPyYp+c971VLNOHqV
kAtB6tXkSfiLSWgXezWmgUxKOvau8UdZYQUnPYDxdeRSPmbdZj63S0CJAuKtlwWZ
ZEv0KEgCNSz155NqBLPjxaiTdmIMZQ8noPi52LyXXiQ=
`pragma protect end_protected


endmodule