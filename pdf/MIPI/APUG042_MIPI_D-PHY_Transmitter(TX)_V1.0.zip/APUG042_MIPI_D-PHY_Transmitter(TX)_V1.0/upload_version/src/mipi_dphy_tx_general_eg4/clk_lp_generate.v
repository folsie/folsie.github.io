

module clk_lp_generate(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_lp_p,
    output wire     O_clk_lp_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
FGLWntXO0Du3Otkf+dWrnAyjM9nRd3LpaWuutOWY9iTtbIxAHjPj9yF+xL6H6t5j
HjF9Mwo/gtv7q0loVmkYSarAVbiGttYXjszO960R32VH0AH1kIGBn6OOnF4eq1qK
k1EoXDCVWyrnjCa/etdv5/9+PGxSQx1KnMIKp71qoaw=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1808)
`pragma protect data_block
bHBFUWVBOEM1OWx0Q1Vsbn7TYbdUTUahqJk5XL5bE9sDAwpOiwU/rTXTkdX3Sl87
d41K1dMQjHpGNQ3JtZWDuF3yAtevBSH6oK/eBnAQ8q5Cqs32aaFwOqsppH4L7g4M
xWufxT5kLI/3wZRVVEoKwIxnWWLecvFz0KrLcV2WDsnBEXgnrNBe+/ig8KFDh4k7
8xcBjgQBcYbklBVOF9eXp2lx5VLPsl1j6ExVc29bayHlmcgWEsvK3v+vcL6HmiOE
fPqUwixxQJC1KVF2Wz020Fqkkc/ZBth6sAkB4HkJ/hSM8tSY3bHiZlVSnELAbUCq
33kilj4wi9hWc3ni5ONYO6Do0AidJNYEnjU9YNqFCJarQZyFL4ufS8TFwcYGHMMH
fpYlgH70637nuAz8bAtzvTAn0ArUXlLgyf79U/b9JeMv99NMTeoU6Yw73A1aFMkc
xmrsJRk00KJG2rDc638ELyvyBZksEvc69euO+8BAYCDTpf73nEVkHmDK3eNCXKie
H4cjRcbaAImAZViF7yP6k5joaep/Vafo/khT99JSeclVxxjafvv9s4AQxq/uK3CC
s4TWpa+8MsrUC/HmYAYXHmAfbg+/05LlibVNj1QZiH69jeBWT2TUSJfAW2Vxl1QI
i8HjyQDPoJlW1cQLRApPD01SzZRd9FB7eGQRLQDrXpOD8RNycr67rGDqZv1c0mYj
+y7nKsoGo7SykVyOY70jHz7owAlEEZ5hBRzl0OqnG3EkMUo07iv0tbUEvBHxV34Y
czfdB9Cdzry/mKj5Yu90etNMhPXM59UaYy/nK8wL6C1JAmLLkdqAXg2spVVO+hOP
zqiPlzY53hlkbo62BcmAYUhQ1Vrjbv2P0Jirjp/zXlMFMAhZ81/uxLIzdnbKQXQF
n3AvFUDJaQyh7DbJ5sIK/cCq5583kV9FgOfvxsfr4Z2s34XMNZ6BEjNv27uAv4PZ
bwuT9qrFgDEAzsiBUNNYEKjv4uddHllwupjdwtlYad4Dj6RU4+oZvv3Hnzo00Uk+
VVwELv9nqByaOnTRnFQVApGq8fkZfpd4IqlvtHywDnrkdi6j9OmwVaetI8Gkr+5+
z6TUwkiLIerZy3H27haUKutUgLnM+G6NBcF22Uhgm+nE28YFvRDm37J//+Lthh+9
PKXe9vhr+lmU5bUFR4LlOJf4NE7NuEhoaYjD/iQnFpI1Gg+dHV/bkraVMMNjzMPs
1bR1KaprrNzrPX7HOnMVgleYnnuV71LW3XIBRg4QJknJdskGfFnOQLyijH7oxdvA
URBoKMdf9KUtNXIt0lDk1tCoGaj+Fw9m5Fg3Rf7J0axa0oxAfoJo8NnSco1A5tNY
kkWroQM+0y5Mpr2mm8gu03v+VyJGeLn90t/3VebbwBulAcvPpPCmfgTwPBbcHm57
KdjzirdaSbCQbpTyYbk9UxYBEmReuOTSb5DQnP/xD5Uzlhf/ljpKZ0q054OEGPAJ
CNB0jgCPCCVcPsxD0Ebz1G05tYu9RR4rpbX+U7yUEA3ICxm/8wV9ljNMbaXVvPGC
+2ctyHIexOnTT5Z96JeWRJktH1GKBt8oIuZ9YOP6zcGt9RS96tsUp/cN/jYpJS1K
7CYDH6qdQomBYjIKXiV5ZdHfIUva46JbNpfs3dXQu01oYsneoOzI75gorUzzw+1n
a3z6zZNZIQdbm7A/EyhFOAi0Hc6GFR25CFTL2yTQKOgbiET8YRuLvtGCUL4+lvsn
UqZrCC4lyqae1aGFh1MIEdwKWIF17ZqEhU6U8SaqCt0bjv4lIg3cbLJe8TTSx8JQ
mY0JAH7i8/5kyvYR0o7vK51y/zaLULEHewq9LW9F88xLyKJuOFdpDh0rU4SKM+ke
BiZicNWafpu0emH3eGsXsirCaASL4V36Nlku8jJpjMP4sWupf7QSetpDJgq55zau
y2C2s4/QKI2hh8h1d6xZj9FlOXvJKC3gfbuWRcfq9nbbNJxRaF7Ue0T2vESkY8T+
qHXnWU9nF4D2CXbceaOpduqk6P7DCCqgb3IvIwj/M+wjEEmqreY3IQ1E+auZTZ6+
kxaDEooICgTAfNPXROHcQkxBVdX7bz27/vwZvZFdjd50cmNOxMvWSE3Cqqm8qbVt
mPcuNzQIAX14V3f5IbOMwCZkSVwMstXUuqj+VC3bRL7kuxhvPHXIIhsXVAhb6OPj
Razbf4lxEeFtIqzIJEYo7680Elnm9BStHphntPg/owU76CkAHZ9Dl6sKMCDs05w7
pHTb8ZHsVTMFOk52tUb/qyn7HfVspU6JzKh3KLAk5/aiMBqBfvtq/IUTFyxhbxCh
/b4C2RAssAsAF9G8aVZQQIOlsnqjbFyehOVR7EyRqi7rXaeMDogIMvQ+Vaoz2C2p
CdbvN8d+kbTIrxzx7KmVCjOEajb+nVX5UR625Jdazm4=
`pragma protect end_protected


endmodule