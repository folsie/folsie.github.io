
module data_hs_generate #(
	parameter FIFO_TYPE  = "BRAM",
	parameter DRAM_DEPTH = 50
	)(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4,
    input wire      I_rst,

    input wire      I_tx_valid,
    input wire[7:0] I_tx_data,
    input wire      I_tx_last,

    input wire[3:0] I_lane_state_code,
    output reg      O_hs_data_end,

    output wire     O_data_hs_p
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
NKn5mN9U7jU+Lmi2bfiensNwFsrajss1NEtpF3a0U2ly4Wk/NpHZhgQoyKoXcgzk
FDhF46WELvJRpikIy1lR3wIxdxrSZYW5Opj5udcobnlvocVO+h+3OijsbVpT3/2j
ypXxdihDdGzb+ddmr68dHwXc27PNfV1Qs1KGzswYJTU=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 3296)
`pragma protect data_block
V3d2cEdGbGNSUVBIRlRzNkMvOCn2pyJmzwUfHWdDBIzZ/mml0MD2SwUgmb2qT/2G
lMUaIOVZqOsMEf0RfcSeY0Q10iSDEDNqFPrzdpNh/MOZTr/+5HbwvbhDlSbQws2S
lAuAwuUZ2x6Is/fQRppqnYboiMEkqSst3hMPk2RTxN4NsbMj8ySJO5JeovIJ0yRh
j27Xhcv5duba04+rmcMtaIpzAptqY/+pMk3Xvqlklb3k3ESifuSUDL5fZDbS7NvD
pHzF6oWb/fZaaEW88Nn9uUXCbIwn+ku5B+aFvs3H1XCRAyW8hvM63PW3LwIsWMki
tt8mivq562o53cf/T+QVec9NXwWRxjkfMxX7Jr3POoNcbyE4IHm2d9t/0z7cysB6
CsuFiuawN/DWBG7UtchMCG/XpkgzIYdSe1SfosNqr4o8ETANVyCEDaDfgVnAFd3k
aSjenTHrsh2uKi1uZ+T2Ep85Kz2X5wrHUPXhv6bV+YIh3RomqlRH0D8UrDif4V8p
dA8k2WaG2Jsz2bk3pWSdzhcIgcoB9GO3BzYqTE8zgdOuFK5/Fdn1WUzRfpcfP7V/
bslg05fW9E5YL/V1zHz4XI5HgUALxRv69+3oE9KwMoDZoHOstvNOOakn9MvRw7vl
e6MXPPDcKORLozakWQjkNJ4q9jo9vWUTvXMBZrIDcRf9s7fS4HHD8OdAr/f6Xs5/
FjxUSnAJ7yFEethhfVAUln2fgwaU4rj8LzDQV11Mb/yvZGlS7qnag7Uf9detimE4
t2wVtlv4JiQRswboNPOQA+sMHk7SXQjCEJj7a/wX3lVpq7G5TD5H6bWMuwJlX/oK
fteCQ+JtIphIFM16cgQFGuAOU+KnkV1bJRc/LGKIOU7wZ8RDpnc/AbYOxSWK4uYL
IWFJx9gvtKLiBaJchOZIabGiBNmVC+8Z1EI+/k7OhTPbCiUCwZsumIwfbki98cxO
wvwnkHfl6EHSlIiOBLOhBNnOj/42nFMQKMzEA6KMP47Da2cGgLrxVmo/jYkbZ3jT
Qll8bcQBPLu1XbCwIeTxuyz+sELQ4s86WH+TUFM/2f9Z+k2wanc6mBDaUJ2qESHM
GcuIQ/biIJ+U0dM7NzsrUhuR3PgTLZx7sFhqb2O4yc7i/mhVnnowHLOQTAZBMUqr
0o2x9BtYpwmGCSIRc3b3vJU4iEEp/9RwCw1gqJuCNuGkvvSCIrPW2hshAHQm3ol5
Mp7nerno4YG3SGBIplbQduKJRdeCR2y4wGjYmxAbIlQS6PoCCc/vIqprIeQIHlHM
hn0MdCZbkmNH9bVHCzbZ13bM9XWjvPDzGHvql6t6XckRYtwwcGLQH9FSxhzOWVz1
ZlP4h0rJsL4Y3W8JMsMeDQd2MckRAO9Ezq5DL7cwxFyqYGIwCKj4ojyAQENb1njr
5ZQu92nZh5Tb40k6Tt415naC/pFGD0nEtbxbb8/RvHksn8ftidWkLBXmlxCN+/am
5i+ungoS8sFDDttpFWdKSJzRgqrFfesavhJm6jkb3vgL9BkXhhllbG7jAvpMNXkV
9ersj0jX5oBsb6taTqctfJuqRYvVLk0+cNCOCinqm4kPV+4HkNxe5LBHVs+Kf4KQ
EtIYdcJlBFm1DhA6DbBymda00gRf1m61dlk7CvpB7h6hvqsLTYphcCe3NsfE0kCc
l+LU5DOdWwpBQGOssS+uY6Vz0EKOMdJCk12BsLxznSU5FJ37PHZGvkGItMOoPP3p
Nu0V+u3j3SmPW8nu+T6knrUD0fKrZt+W/HtZzSCyvVNbYGXxVyEqoUJzeFxktu5T
+vVlxQJGfqUPSFluzA7I5nHxYmy1ZGHRUin1NC4RGZr1gcpM1u74M/ajJmOrZexn
I3GAkXKH12ZYQE4Zg0099/FTbpn0Ds3NWwNW8Rek6f731OgItamWnb5//W/BI8bc
niw09reGXwrix1xorsuAt3PVuixuN1mBovzDeJxqUWa8Bvqp6gyK9xMSBMAM+AT3
zaDNL5GWKjGbW+Mc+r+AuN64clau/n6IY6CqfAB4pLB7w0YyfrkHyg0+294Oxnya
UzqL8+hB5WaKBKkz6s6F8aI2FqqK8cJfK0XOgNpcNn0BMGwVszinBZb8NakwzbhV
gVXs7JWJn/baaKi9DQFSgHvzMmvde6D9o399/YTwbZRF3WReg9Gi6MfVaLUuSzFd
RL1HQAwn6xYlMvIsPYT7DgB+E6aA53OKLo5ZoxoPzL2dti1oq4RFaKNeCiOE5DNA
rsYUPJ/YUg7FNotUZYkbQvwE0CETH93LtO8KbiwVdsUj8RxqoSN9Qo9GDEsCSVGQ
y1qfR48gEKW6naNaBBOS9+wecuZ4WwFZzLGRDVRjzvuRNGWCIsaVHjYcQzIq28KC
g/l7vLOQOgCmcdkOY0YPrMP6oYdoPGhlUZU+gX2Cy2H0HYihSS5c0gXEMTtykwfS
h7enWqwUzFGdrU9MXcmfS34XZ7jrlT6WX+ppaqmLrC8YaNL4lL+T1ZWQK9s/cawQ
QjbJnG717D21Rvv/3umDFg7mKJktjqa78I+7fjswGS6FbdJVkBp6wLVf1S6jkkA3
bnlTLsd/tleAyaYFy3QAucDYappvLctAuD9rOexCsnw52MvyLQYoWHAQ5Eq5HzDJ
YdiQeiZRKkPnl/rR5teEhWZ0OoIzrVYpLtPD/sdOQDDfkg4bQrNC3vvKJ+mzUqig
TzHS+QCtV3FubSgWSB9jSS1LRxa6b/1iuOTFwbQPNO8gzR1IgSr192YUrMbb2Qdg
1VtS+Y6HDIteORCo4u0l3nZ6p9NCTbqQ+4yR7f5GupcBxhdEzvA1K/pgN39HAOBP
FEj4gwUkSvwfrPKH3+JIW35E5wPZgI+NgwR2czaNeT/l9e3S1emdWvKdunUhpRly
14HFiSGQmCRNSGAjzgGNqMvQclP9lFvWbPX3s9XPCiaKptF3TuSlRfkyXfdrkEam
W0KVBJ6KQxEvp2NEnH2iX6+9oRuksDVt5xql6SQgt7FF6JTUl8X4Qdz7mql4GorW
uNeD72nmiJic0z0HKskspLASpNWjsPN6JBtxZjoP6EisAnKfGTjy8oVAwAExsFP7
1bCDOxBx661qJHxrE/nbiH75P2s0AUbRCYxU/v6Inu7clSSs1NnY4hfgrIFdrgih
ddlOX8rCLUrnp4LTGiZm+pQKCubMokt2ChmbaRU+G/9NmecZFO0g6MW1OMPyOdcE
nOXH/dFSNHjw0BmBUzoYedbyDYG+vBUEFNGsRVxBtqcOX8Td8W7D1OB6VOwA8iUE
tBZJKxqMzPSPgT7pX2ZV3QHdzuANgcsd1bbTby+eaexqUXRXb0pcDi004bTNLOOM
Oslj85757s0QrqNfjPNtI9RcpFeBsyD7XfHsEgmASJ6MBDV35OjXi84ZD65RW78E
7AGEYFO8MkecB9ukxyCg+iLZVo+VFyYjEnW9B7tXEM4wPwCExh3N0e+uNuCeNWG2
u4FIZbuUkgmYVQ4skpc3rQoXEN3SWBt+R5cnDPpX3yCPP7hGxlrGerkYUDUXb0hu
FAxDtyN+hEwZkmsNw+bvvUq2/i0B1T397zeDX3elCZVCQX4fZ1PYwxqLwbjiIQ0x
7LHvds52pFCyny0u1vkZbT7JhUVROQl61376ox5czgF4zTOuORSy/Ff+kTlDHiu2
jgQ2Ze++aU5v4VfTVqex6ybDXlUSd2uI9fkfC2TlUwKIJqZ8ilVv7LIwiG313JV9
3RcVrtlHLv3ZEGn5q0TbQLMwHirKnLqLHrVVxUxc7VLZf+qwqsEfvcneMIsSJesf
jKAHDia9MG7B/2TAHzYrBxICuB8p13aUIabG8ZgHUPU/CwLSwNVBQUVrzXVAt7iQ
jYVVwGTgEB2ybV+jZU32DpW7DefXaeYEa0qZB7VSiriZwxcCR75n75eCgl4bEtMb
JDGrqYrUOWyghMJTfyW6WXSDF3gu2cbp3+zd0EuIWyIm5AG+4jcu8X+RoIANLXxs
wcO9K4h5wyPhkB6feZ+RPgK/LbKg4Dykez2EVdpJeUDrlYmpUpILozM9n9HypO0A
9BhR3e2E5ATUuWJm+9k52OBo2/ZgqhAyMJ45UHupm7fCY8f6BjEYj4ZLXMLGtd+a
mwE187TYIC7aQigd3AiACCQ26E7L4UlbodBdJ31ECVi/xvRkGuP7UWLwE1tiVF8X
zdeCuFtPoedzj1lEkK551MDQEyoTzJUof+b1gMlibroriyfwEl+OuZJ7yK0x8O6+
IkaCutbI3sBaKjvxkp+jSbQaZoMmzMJUfmTtR+SebXctLv/1KxHzt0F5ImkLl1V2
npDfXiKFRHpkuNJ9jZ4+1bT5lukAIQp0Qpwxt5mQtB9FBu2BqqyfOwyLIufxtAax
0W2Lw7lJkwVyKcp+uIv0oh2lp2i5YqpzzdTCfdn+kNU=
`pragma protect end_protected



    dphy_tx_fifo#(
        .FIFO_TYPE      ( FIFO_TYPE  ),  ///"BRAM","DRAM"
        .DRAM_DEPTH     ( DRAM_DEPTH )
    )u_dphy_tx_fifo(
        .I_clk          ( I_clk          ),
        .I_rst          ( I_rst          ),

        .I_fifo_wr_en   ( S_fifo_wr_en   ),
        .I_fifo_wr_data ( S_fifo_wr_data ),

        .I_fifo_rd_en   ( S_fifo_rd_en   ),
        .O_fifo_rd_data ( S_fifo_rd_data )
    );


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
CmYoS21yeuZE7gXLz/87OLCv02anC/pL6r4QvgMXioPBbJzC3Wa9vzaTvUmaYCjX
P5CAfNWorGtEX6CtvOLPNFcdPxosQ9siEkuvPCSvZ3PLEXlSD33y5aEMHpbpil0G
jxrPd+kkOks8VuYEOCwYncMKHaXUPmEEHYGl7XbH4H4=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1728)
`pragma protect data_block
T1RQZ0dpOXZHY0xsdE5UZPHRi0gpiaw7gay+H8J3LrNejtOaZmOkdCoLZFIBc8Ir
sDVbKpddnXRbHh/t3DP+3YXkXIKsXhGP/aqStgjUm/owoulqPX/idq2ifjKMNxHQ
uJNoUG8Gm0ZnUROs+6DloYidXc9dUZL4o96oq+JnobyhSnyd6VfekLnZo77FFDEf
XngMYDaa1d7FPVA+djRwnR1XCfYCdVZA0aARO3OWsn2RpMttlfSL9sdOfYOCKzx5
g3naGPPmcaaQjUO7h/BRoTtmumZsrCHW2qE1q+IZkRs3shiYVvh4rGT0Sb1f1bte
Xh+bUJ7bkuWVc176u4UaDK7TtoofThgztJPz+IhSpoXLxhiXjF81tlCYoKU1r7uy
5FQaAC2W9yB46grhXXduCKgH61FByLa3dShZhWj//S/NF66uqeoayxkY94jhor4d
JAG8RPW3PXiArRue16+0kASa/bWxQFWf7K4hpi7CehsBMwNrijDBvJOzdpK12u+2
GkqwKy+lTH+Aqw1uSuBJDWcNnaDcjTVC8EHUGc0DfQuZl37S5WY/lMjFn18Mdkx4
5qlct5dpxl5PfCjmvhlDFfPvGJvMgHmLi/J6H4UoAPZc6jH6NpT6IDm/UyojrXCu
4ParlKGzI9z8wNqeflNXimhH+AC3OxuWZfOpBa5eAqLAJV2XJl3yPUsOlkSXr0se
iqcdYoowb2qOBAQDuJxhpAifzuU3htxeD6t0QohLkS5DX+GrS4wgaubjCuH1lHeY
n+zZJtROL7HwkxG/QcrsidUmi0R+6rOx3fbAEBjVLaS19wEJ/CFj+Xtd1ReDtKSd
pbk54C+rudlek6HnwMb/4yXIqDz3z3TJkETe+sP08gOJ7KLWh41/nBr+lgvdoeSI
2rFBKy2N7xBssh83mToPkXX5hMO9gS3UHeYws7AJjyYNLNPoLlLzYv9AUoOwUiio
hdb/aLINKtjp9lNWfRHPhFKlJ4GeAPBDj5PvJLnMJ7D3OimmvdNkP8vYZkSmVK9R
tienLuOtho643KH4mVhUkZvvubdGfnk8pMqFllL01ZFmRVUZAvTyJ5NBpRqQTGU2
dpRQPVNG0QsmxWcnoGJDVxrcAPQxA8T693u1RKdBYyxxpJChjObrr/EU1yf1nkSa
Wj+wbWdghvtU7QzuijsNDT2ceBae2+3dqQJ7N0inANj750YtmINtyMtBQtVTzFry
E/kpdlqIWFVzQit6JjkzKzMwMtEYWv3uwSPaPTW4nYPiVgmwXcUooKJ8Psz6G8KL
jBzYBZ+Csv/XezST0R8PU/UYZ5qtduoPskUCMvZuuSJ/GCWYypKodEvB6aeI8wMG
VhpuH5A3BY9l4ZsBz5YUACQ30nq6Pr/ODDllLxrjf0YhWKrxcQmWVl3HKw3/aRpu
Pnn4xj4UmrlF/wA0igA6G71ojiWUerD3DF13fr6/+P8CjNXggZyB2VivZ5O6zUlU
h2zFnZBU+K78EPfjx47MLMa0Odre15YQMx75tHinjVBvr3mpSkQI6AhUxT8JNzla
+iMFbW559taGpJGBv37sL3w+uWefxE9vTjVJ0n+4GHslfIkw6H2LdeXig86oMb1K
sztzvOEFq+uo1sFKfAbccZJz/6FyxWBoaoT5cQSRmAR6+1Rqoc3w7h247hXxDVgN
KTmAPKgda8/OhAYn/jWiutSorQXUYBVxvHYC9Iua0kBaV7BjSbOcBqv4kpUkcuxx
P9p0hlaWAKAl9ObmgiYisgFXmaheL4Fc9szHmKKOCsp1hlL8vaxGgGz3mCe5Rq6k
k6M4uaNJtRcNnQN2PEaD7PPY+0NBrbyS76G+c8u6Zd/inaofVQtu2zaPoWr7L41z
TUDnzRDQspLNAma9bBFQX3fzNCWgFLbZNeBX5L8AQnh7EHWRvGtIWeSkI8VDUGoK
baAOyAtee039Ho372ZxXC7kRdDn8rjlghf2SZ1NkvCxmTqsuEg4YbquUQBv0FowA
Bn9wt5vkSjVly/lRb1nd2GPdLcmDF4eGEEIZSLTFEL7HDvlBOLd9W/wbrSZuV+K5
Xr0gNNn8U11KUve4v0SqK4C43zjNPq+f/ipXSI7w3B+AfiXkJXgZE3/b1mtzirQC
icftn5jM2zcxjV4UodmW5sY2sLIPeApIwv2g6S9cpNXfm+dovBE+EnEykFrNh8tW
cmBFe+FvY/YSwivjoAFsINl8GBq/VoUl3SyZqCwQjLNtq/Njobv5aO3Wg64RlHIY
dCfS9Nq6dhOMO/MO2fSEQe0kPmc5qkRR5yiVdZu0/3YfGERA2XJ33owlV8mEMsAW
`pragma protect end_protected


	EG_LOGIC_ODDRx2  U_oddr_x2(
	   .sclk ( I_clk_x4          ), 
	   .pclk ( I_clk_x2          ),
	   .rst  ( 1'b0              ),
			
	   .d3   ( S_data_hs_oddr[3] ),
	   .d2   ( S_data_hs_oddr[2] ),
	   .d1   ( S_data_hs_oddr[1] ), 
	   .d0   ( S_data_hs_oddr[0] ),
			   
	   .q    ( S_oddr_data_p     )
	); 

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
QV1AiunjSRVKYLJhKBnWnsanlX6/CyCw5IFQygtSm/j19pH22CUqO9NLU58DfS36
ysNS1lYjorXrhkB0AEgVXpgezjZJZEv1QMyKuZuk0HpKCGzsErzX9H827RrJa5rw
6V8WnSHhH86LcifFflFnSespHlwtnXqPyX1D8aQj+QA=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
RzRsOEdreG5NRTJPeGs1VN8G4btZtfvssiZpiFsxxSTvHE37sih9J26EH66RKE4h
/UCei/IrshUrVpDdjbnjV5p60W3nf9aBGOa7sTuMC1f6HnH0oxuLjZijCZUcbCTE
`pragma protect end_protected


endmodule
