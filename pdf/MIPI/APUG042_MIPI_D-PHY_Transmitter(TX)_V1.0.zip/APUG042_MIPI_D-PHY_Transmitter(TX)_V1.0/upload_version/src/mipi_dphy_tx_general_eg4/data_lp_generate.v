

module data_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_data_lp_p,
    output wire     O_data_lp_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
XeVXERCA7lluFNh9pP6N1/hkdpCr4T7X11je49/6CMR6MC2l5TqnUQe/Pn8fbkgQ
O4NMtX0YJN9ZXplCNzw20eQy4St81AlzNb4mprXbnpxQFnWKGxpAygqxQbzaMjVW
0DcC5zK8Z/ldDTYZ6wzdn6hk33wXqdD4FnIRgWysrNs=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2496)
`pragma protect data_block
MnVoeTFXbGVkVGhXZlZTdtqS+8OCl1bHnccRSwjakDLTmrD4/+Y31Mlr0v7Wayfg
R2eAGC4JzOaK6FZFIPJseNQsJIekpXHqB78FbFuSeEMjbvD9WaB4VHbLd/HMyID3
6TRVad7+0ETEcV7S2jaSUbCCMF/Tr3GEemzmJhwIZXiugmf2UxZ0pBGoadWWFv8n
GNVmGDNQ3C+WZ5DNLCAfuz78ipalL6wpJ43iJRmf77muw19k7qROv3sh7lCQwUxt
lsEVMaVkWeO5gZH+Ig7LygJFxokJsj7M/bVsKwt6/RDIPIvdU8tpTVfQdhs35rw5
4JIc01ty50K7mBMU/qwkyFkFaWENqZZQguqfo72FAlzRU6LwmUWDMz2HJn3UnI0Q
Y1zUpzbdduS8X9NQDL52pWdyWnFdJi832aOIN9SOU8S+bBQoGf2hIijwwmom3BtE
mHMJz1o/5SLcpijf11N7S/rr/zXEErU1BsY6VWD3Cne5wW+EMMClJO+MznNVXXzI
7Q1WrY9BreB2ZxaBIskmRrVkoRCKeNoYvWAVqurClnR90X8Llak/0yzcRoLaWD9N
DANcbr9Hf5T4MTkrBrl4reKaPPTIlVJGo5vq26dooTYUuHTk1gHJr/fX706gcpzc
/uPgJzIwfiupRJxyiY5YtdfgbgdeCcOncvmQ7wE+ETuSTLTbPjbWjg2jSvCayBGM
hyIpyi/DG/gU5x2mtV3+Fb/piUQQbsahh1lqnrdpWTPiBy3krM2v/82CVBj8yWhW
681DiSZnqdA33KqUWyDBBgaZKl4uoblQ1PJiOa8Ws3JxY5bNNgMZENSzxko0B2XL
QLB5LomnTFqLL25WlwIfPsNjJ+JLuwU3aHC8jf+Zel432OAyR8vdD1VTMV2PhpV1
VwCjHmny536zXcWQT9cLglsAOQmuF9VfOC0tP0wXrEY6n66sdLvArm9gSn5Mdr1X
sCzMJehohK1BTzjjQ8tZZ3kwV/me1fNaINqXJtIQYAKnsOut6C5pdxRYzSBmZ37O
exBFRErJy2bIx7HfHA+CIT3muL9uA479UZc1Xpz5WzBRCFHQA5CWb0hUZSVz2QWf
+VED+WUgP80NUEiOYGKc2Ia5rSx/nWiFkJNp8C46T5YeIfe48nZZ+hvE/xL6hSt1
z/Ux2DxQJKRm/bETAfAnUUm0b3nMFksaxl5ugyDxGAyjJWHDSGrpbwh1q7tx70xZ
Zz1rwV0L8W4Svt3eK2V8OjGqJFzzcywltMMUCAG1B7qeGESBS6LSw7C4WHoPPKhX
6WsoDjYqBxXuzN+NxpeoNbgJJvj4P5jZXBL+5vrh1K7jB24ugz72HqQ3P/6UkpfQ
BAirA0yj6EqeOkplDhVJcwJtXBNICGo5FHVECb6o2NGpb1WMNDbkSgALP/aDdMdT
AXjSwrRvSIVSGRyHrsq65riP5pL8A19e4dYpt3V2U5DmQVzcMFabCyFUjfCoOA7Z
Lk9LyenbbG4vjYc5XlZ/sTYZeqqGVfbGM0MNTEnRVVAItECqRx709gTYg98Ld744
e07vskubF4kOOCLOBgMj93WGgttGbhGg+u7/qE/iO3C/cqn2DPO2ccryE2xA2ZV3
C5t8o7+l/bqzNohgJ7Sol99PuzHSbOQ1QsIiiCSOJUPpElA2EX8Gexhk8TiLhVsy
iT8dd8rBNoZZEIR73dd6jiVq+x38hEMxnVH0b5LiFR2vGx1y5NhsZ5jU/0QrLghQ
eLSM9n/JvaHjRW6m1XeVf1I2q60voaAEFwXfEKoqeNvUrZe2Tv2LDSnvZaUmAVoE
2MhGL4vwwD73pZ/4yoqm5SPaWkvYxdPPxE49UOXGwPP1ZfA4A46HOspe8ooAl3sO
E5d3tQE7OuD/dtD9DlIOUkfl9kkw7owvrO9wByVLHJZLAg1aDVzy+yFWENfOWlk5
V50B8NKtHwYNcQ2n91orxS1eNY3ivVVxKsfapy1uzOORWm42lHpf/PSVZgOLs1no
5MxhSt0QVFIYug+Kca9ovaqncFv3eg7n8skHSZGmaTN5MNypLSg3Mcd1WdnA1rtc
gwSvEksgVelj0rwKEw9O+373HjVsgYdNy/PYYO/2JxI4f46crryah3Rk7ILdIdVV
mCrj9yGPlU9HGRAcpG+fqLdLv/XSr6IXRxcrVkD5uWeE4Aob70k4vyo/8qApFhaa
4v+mJRgVVoJROqtGr0R883PLqMwpF1RfH8ov0XBRnXGj9INsKFB7T8+Zw76K8X9B
DhdFvEg0ug614NHyV+zQwWJyWa95xIaMPcogqxbo5BWzawH+usDtIr696YPLkmhz
rTD5sXvIEb/yMBaB5gEU3kKKRg31SOzXF8pBtxohQ0L8kMkar2/6fY2BKvBWA9tb
Vz4kEcV0rkOFbuCnmYDXXNqCD3O6f9+Kv6xxyiXAfhBioxKALUssg+I6jywqGeKs
NSODqej7QYih21jtRJaWZToBQ47lbBLp9N6gAPCYIiMrEizSgQwB1/AjOkCv0toj
c882zQFUWJvZprV7DqznECVaLV1gqfYH1mvvMlyuW1NZAKVMOgl4KomfELGlOj47
uM3MvE6+d1v0X0U54vLGZs5vvquqTafoEZJCbf00D1EupDwnjVcrqTfwF0wgI2jQ
N7kLjSCLJiPl/oSZnC24VgRWKm+sSzEQ9/73T9zivuuO/r+BcwJ3dckGpSNsDNVz
jfZDi2ECk5R91Y9JhjuL0GvBQwhGXH4tKuvNoPIbZ+1UXu1CUx3TMltpNOA7Ic3f
X0f3Q12nzt1eYngNKzKxhOrMd5tzTXzOnvAekgUsLQYbNjnIxt66I6RvkYw72dkm
M23Av0WG0BOCKNcKHknC5qkTthodV1hVgZzK5NZmmre240IyswZUhT124i662Sqc
YaC2tUWDHblvYTf1nGMdJnVF/Hh84bG/iY2Et066RRdsC00uQQE/jErYwt0+AY5x
SjUFuwcnUTYhL6BAN3AfejXHhAd6/biomkl5SKoSPGHUnxzcJ0GmqljH2G424LS6
a25rRF6zM+TRrsS/2eMsjFZRlT29ActG2X19RyrdTax0B2PemjCwM7Kjs5u5i4cr
MAah8sDcwI85JNjOgMVNHovmGkP/r9PoHWAZBVhvVAu4GOhu892HrbtG6YSw4eOZ
JIGhZIIaZGjC3hew7t7tCcRn9s7VkI5LKhJvYqKg1g5YmbmtOuAwo9pVwEtW/swk
EIbxHWPzTaZkgO9xmo2+QtJ8dr+uOJYtTWYWQDtKt+ymkwl9gOJB1RbtzY02dRkn
bsgPGroqfvBmhJq6evTGDtUX9W/9MwEz2LEd6HpJMHX3sKE8sCQWQcwq1IXLZ+rl
`pragma protect end_protected


endmodule