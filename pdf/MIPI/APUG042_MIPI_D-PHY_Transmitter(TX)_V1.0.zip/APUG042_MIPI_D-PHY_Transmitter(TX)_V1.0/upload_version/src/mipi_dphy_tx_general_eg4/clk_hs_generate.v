

module clk_hs_generate(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4_90d,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_hs_p
);
    

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
YuRwVvh4wQaJW6a0oB4ld3i31O5TDW1ZYm7uXdmp0okpo20EXT+ohgYh1VhAGZ03
eJs2ZACLKAVmGWf5wKhqT28NuNCteFx8tux78Zo9jcPBQ3dGbkB3kbH3pEbxmBAO
vNRcvu1R7gXbPPi6+zGM7oset0Q/wzl0yAcW38F0pYI=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2448)
`pragma protect data_block
Qk92cW15ektpVUd6NFp6UQixMZZt6rbhKRaqUfV8lAAgoLtOi5EFTNib1jWigEYy
Avam1xFUX0QIVt4Th/WiM7giBPydOmDm7TKDWqBEORcrX3wvDnXlb3bY5ixnyhTN
KDUaHPPkXzJ6Utk5i3UGlJ/vlhN4idu0VTQyH6z1iuBIDsIo9B6+VbaXSy8Maio1
nVoCtOZlRVg+Uk1eEmzV6n2Mot4ioaxZaFKMl8EMF18p+NlZrNWmqaxwnEX6uMul
g7XWj23AOyLhdnrIYh63uzpfeSv9hCLv7DDDqbJP5CE11u2s63AYdu15Lev0u7Br
Tk+rYg+AWra0mIXvMSwmHFdDkCDwD6DT0HL97RZaoPFKTJp3+xMSeIB9/05xYZqf
bVIAxQsjND1d5ouS+NmB8TFNntB0ADmRVD97cAx0ZbVMJE6sOToNoG+MGQiMZFJ4
0KTGk2x4njlcQFGHatrwUUGSyQ0e6eAa4pra971A+pflkExGW7oZq5FNA/8NTcm7
cdH20BoaXS7WlIisPQ7cA6cEN64b4GDTwCgFj3eH/2OXC4WJgpgN5RCJ7RDkQ07W
x2XBb8t0Qdt7/BuCHCulKrlgFGvZhrWPs3Rxho8Aut7auUN0RmNQu/dxvuQh33nz
N8bH1COxWi6crnRpnN8u1Oazh7wRD3oiTSrzfk45JeNSqQGhA1reNHaEWUCKXFrZ
C8eZ3eA2h9lzhwe36+/7syo0g56rSPAYWo0lSVlGolBk6Z3He1zKCxBLXHfI0DbO
hDph6omUXmzik6NCVEcBN2tFocqPjHKJndLd6xxaVl6M8LTPng4Ixs3VAQcuZeND
h+blH9SUaXhQ3TAews8ANvwI6yaEF7xCGej1aFXJCnaZ8z84ES4Utf0vknTdsAcD
jVB43dwqfqFxcFgWyVNPOekYqtMdpIMekeH4Pz0PW1RwdNORr8mXqCIePvZ6MZMb
q0CYMdaRwU46IQgKoDH6WkHFvbp3Xj/xhAwtx3vfLApjbpOxcSSkmhCMTo+FI48o
toSO2J2H/I8ogywQ6q4UxZC+8QPm0VfAHhD2UfUGGTTI6MY5WxASLAxO37YpWd7N
a5RRfxTV2ez4iyWoTSMMKJm66OQgkVHWI7EqUTBeuWlaQLShRS7lhub76y3n05k7
k1V4c7aJplvaG0NPslxMo1GHGdlQx+JY7Rag404IhCj8cmQtoRlpDGFWB8DhQWCb
49up0ds7AnghEfTIZDr+/lhXU6mmwVNXdqw9EOHHnakJSKSNJGFhCAEVeHGPKyMc
9GPssYtvg9uQ7wMRezCFL49nHMB+EttcziYsMBG0He6/lVxG2arOriP8K0OuXRrR
QYT864lP+utm5ceWXeKdQtvqm7Ufry2eRHnCYZgDYMQfb+dWEwaTR7Xit6s85Ek3
5jr1rU1yinFtKCb3B4kieyY5mwfT4j6CNtZqE0dyiyVRyvUUrDuPn6TRwLBaRtUY
mhFbudMrnBj7KS4Fd6uzXb600pBTdBlrfMWoygzVCv924NmQvarVmz5JsLan3sIG
1yPe55ycfmUgggTNhHDxqnh/MYdZY/ZZNTgZPgeO1E5oEVzc7tJXJH2FMyytWn23
i6oyyNXHN/hEQgx97DoZjLluTTYN65fDAqWv4w+bjKqE0SiAaY9ozTdSRJLdN0S7
dPvGSqohCNnjp2Tsw0lV795DdOl9RwCN/XrWN+ZK/WVbzbazOmxQ3E3NWYdRm9At
2GG2sp7L93BVZxojHmzutlJaH1BtuH+O4XSNTylfv9Qx+WqNWePVGuBRu5ZyO2X0
W5PshBZARLIUAW6z5tdme8VhIfbZ0l+RNzey5x+j4CMorBz4rHj2MtmrggpREcbn
i+tS8AHH/ghJOPEK3IZA4IKyl7j6Si3fHg1ddNk0YDQ28+29LfjrEdJsqHjlXShv
7BMhppn396VakqQRCYxQurSPsQUaN4U6vlP2VATBbc59Mg7pSWXQ6wW4Cwx/1JMN
nPnihfC+iM2GdfYvZcLE5ZFGin2Qx443NQBeWnVij/0SbxYyAFl2F/H8SuJfewbI
HUZz1GBKL/4cx/Z/90sSIrRHI5DdQc5Cf33ijIo8G2rWLhAF5+fhj4tfF/TJOFUF
hFg2BPJ9JElw7hO8hhHYkGu1h4fdNnAvvDQ06vc/AiwjWoDZ5t1s8HF8m6ZSIwKp
GoYJxbhLGwO5EbAlBTrxbCzRWVdXJMzDQbc94INQ7DdlIPkoMxVnpLY2F8lBRC44
Wbkc2VK2NrXR2tpTEJj8UPg19dW7QRA+MvFxMNR6i90knHOGImf6iUyISggRRdp7
SQq4pP+4CdvNedp7cY61Zs5lkzZITjxwxjKWxSmSeVewpaKQH155vnoxbI4PZXKX
4MXsV2rKolhz25yZTnXFYnOoY/pmtFBlZYQo6P3Lsb75I2W7/q8Vln8mrpIeo0/0
+AdX1Gcal77DgiTJTsWRtIe3dtWyr8s8pDo6zMCDmSYc2uxYJirm871JYzrhGhzB
Bi1Bde9QNWssfaP+EsdWppcNgizzi0VptxMoJ2qe+DgXz6YdZcD0/nHfdDfIna4y
VoPZl6Y0P7eFLMU0U0Rk39pTr2OXTzfDhvybSZ8/Y02Ltkl7OixByDncR0yoU66Q
4ftEUgHr2Gdk7c9XMpzf2fECCP3S0Cfwnv+XcpiYM0M4XEbczm3Rxhiz3bcHYKGW
IZG+UfTP4XtCFYeNC4L3Xzq6HtzmVIWKcRlsgmCjjoVlsl6dzqHUNAezOYTONgV2
3eSaiWkwAYOjryOBE3Ju6zH2O4VEvSlVg9b3f0dOd1iS7wFV/2DkMuS9eNIZlATY
e8KG0kim1oe016JwOQBQ8PRajeGCSGBhlpZBzgqsZUi1pBLG4Y5G2cG+5RJIDmj3
+ZwogKXb0Is0UfrZ+n1Vrm3oQ2nVHmr3/Fb+YsFeUBDTBLt8Fu9xpn/0hamLf2fv
UWLvAU+XN1tfz8P7GmzEaH0Eh1RL0Mad4E5m1oRTXW4Gs7elHOe2dLSq3aLuPtmC
rbwA42/pUQ9EUeXpaWrdZDSjwcHoZlJiqDDIa2yBIrd+CnXaAz9MqBRBKm3nomXa
iow4WN/C+/32AXqcTca6n9TU2RPVcIJJliHhAlu9+rUOA9ciuiM3zLUgscEvH9G5
BfYkbqi4xYsF4TUfILHKpxx22acZTpp+F/dzEvVN9GT+HY6WtUfe5Xpkw8wr8ESS
TNQRvfTGSbE7AOq/2IQ15ab1IeqdQ6r4E8rclN1J51zw/2XubOk9L0KqbzKsG/oV
`pragma protect end_protected



   EG_LOGIC_ODDRx2l  u_hs_clk(
	   .sclk ( I_clk_x4_90d          ), 
	   .rst  ( 1'b0                  ),
			   
	   .d3   ( S_clk_hs_data_oddr[3] ),
	   .d2   ( S_clk_hs_data_oddr[2] ),
	   .d1   ( S_clk_hs_data_oddr[1] ), 
	   .d0   ( S_clk_hs_data_oddr[0] ),
			   
	   .q    ( S_oddr_clk_p          )
	); 


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
ZptPSRyvwKOqcKlfIAz2SsKYLtvTGwyhCbmvzZ6ZI+AZLKAyXvVKMc3dqS4XA1vi
uQwkbJtEnNidsGtmwTSVg4r7vuwuCD9IkIHgEDv56ZRFYV3iYJ/BmAk9sf9RJTUm
IcS0pMUFnhw85yxhrpOocMHwFNf3LtUFYMOtwcWgtzE=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 96)
`pragma protect data_block
NFZQY3dtMkxPa05XQWJxS/6f14w1QnjeUPvihTEta2krm7SzXfmkIeywADq8kO+7
bBKPS0lrGXPvbBPy39zg3Wn8rSq6vndmhrwxUznY0gPqG11/hlEwLUPcQX4rgi5i
`pragma protect end_protected


endmodule