

module hs_tx_controler #(
	parameter CLK_LANE_MODE     = "INTERRUPT",

    parameter T_DATA_LPX        = 1,
    parameter T_DATA_HS_PREPARE = 1,
    parameter T_DATA_HS_ZERO    = 1,
    parameter T_DATA_HS_TRAIL   = 1,

    parameter T_CLK_LPX         = 1,
    parameter T_CLK_PREPARE     = 1,
    parameter T_CLK_ZERO        = 1,
    parameter T_CLK_PRE         = 1,
    parameter T_CLK_POST        = 1,
    parameter T_CLK_TRAIL       = 1
    )(
    input wire       I_clk,
    input wire       I_rst,
 
    input wire       I_tx_start,
    input wire       I_hs_data_end,

    output wire[3:0] O_lane_state_code,
	output reg       O_tx_end
);
    
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
j6MsOym2sew+NAp3O4a1KnbjGluUFU9qjbD5td7Qdh2E+2ewCeBf12ceP7IQsG+L
E0LG/t/0fzVfXyj4sw546WJoTr5SRf6o+cHi0lmvM/BJ+0+EyXXeRqlO9ISfBkXe
l1FF63tjm0v64SO9TmjLTNB+uzmc06J3IILNPUWn4VU=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 4448)
`pragma protect data_block
dkhTM1VUOGJycFdmWnVnZJrhzj9+2PQtsz5IyPIIb3raGK6ocXCpzpoYNnKeirq/
21hTW6ekZanJ34tFKLToKrU3S+byVZfRiu4Fa76Oll3iSXMtXvQq3luhUPOIwj3h
DikYxGvqe875Z+xhUzGMqYIEQsGpWECcpBIIGpRYsoUQrrKiD1t+I5NR8C9+KzpB
srf1sUVHAh2QHElZOf4DLHQXmezMS23KyPyksy4sE670MCQcBOiXYmz0dcGPATZk
Cg9auecaz/g5OwYVrDkve60/fG1OFwYNY8Ue7YxZXWPAQlMoynTG5cVVaE/8aY4I
cyZ7VqlKAv34rvMMh/Qfs/XIuslEDKORtL84p9sULD6gWUxosgtEWrd/xJmdb/7p
O3n7xnx3UneCwwMnKqhdu+5AQ/iEQ5cpjkxNXTaRam815Z7UZYPtlLP1XmmV9E4I
2yzoRcrLoF8YHgVi3l2GExfxDLLWPzVgu1mY9wBk6GiP4MOXil67pmzw8kPdVA1B
VC2EKQRRmg9sCfJ6+GA4dwigIfC9hgj3mKV2h1eCfVbchvkVXvl9kU52uKAJ8nyO
PMVbW505IHxN7V0oPhnUuZDNUz8FX8RofVNMJ9UrzO8ImdNQvKn68Q9QiFRuJ4sm
brnIrdCKsr/bhlOVYP+6z1iAbb2vkP5gHzw4K75E/C8g2HhS8dcN4t4Xpd3hW7BA
jyT2DC3nXcsYetnXmAWFxTDRK6X4uwXRSQ69eewvHl9XEKG+rEGJ75EESZzniqw7
fx8V2GN6pKyQ3NN67xe4lGzvGn7KiY2fkx3AoVHzfx5QdgzZJ0SOqPooJZd24gtr
u4qDBmKpzTJwrX+GdRmGQuvxkaAULnDKnGe3oysBOtuAtgFcAcHZmq9KWlGrBtKl
dkE0u13+2Al47XjOqerR4uemTio8uleJGGJu0n7JbI78zN20OtbkPFwD8xVcSzLt
aTqmzzMhz8IdO57333EQFB47bNpQx/sPyvc9/3uAvUwPw71bNw53ayxuBD4UvY7l
28WEwl3H+cs84Bf1vSNYhFlAs0aIHd3dFoN5GACr+ekenHY73FxDhq2IIsz+gQqH
qk3zL2gqU5LS9PWUQUH67Tp4NTMMOJnsH0GxjuAMYXPunlYGNWLNedB/wOZklJxg
U0eEVDNbyWje7nlWGbfEeoAke+O/vWYLLeOCpyAoMkDEvqesu/cTDUPcxwYsdVgQ
2AJkJnjVkv9IcwN5EllQiYntcBE0sXCDovO88X78Z84AVPDh/xXXy0/EavsfPihr
SN2vYv8R/bfLhvlsPXLkgv1FPfri9YNQVNoGDy1czqhX9uODm08wgbPzXV2K79p3
E2Z6jcjaSKLo/HmnupgNjeL/k67JY5hUL3EdAi0DNEug/tsXsiOZBf8ar1XzN5Xh
euyac3X9tXtLE8B5xBBFUNWIvyeI1Th4Yuh3sX0waxr5gS2i8v0414G0hxTtRDOR
gznmykZrtrm+ztrW9SNPTY3gkngopPNAuTnXneQgwPqnTaXhp6iD3ST6i7+Ga/f/
KqpoUwPGwWQQAtdY5oHWQhwpIH9n/PsJ5qRPVZN1S72hZvLyVbtDpsIowFBndk0R
ucZ0cWfhNDiTfUZ9pp0YLaalYhDCKV49875PkITexH2WsbcAIJT6fYsV1cwJbT0L
OQqdIFi5LVEAVOIdt0Nr3c+xYdRL3ZQ0H1NlRvRLce9CAUypfNVZgvF3wcoDPSOJ
PsjHH6HJjjA0EZ/aCGxgwp+TWJrQLKZbdnjfR+KIG7nyNA0MURX2prCuaf9pa+16
RgbF40+N8LKJ6eW5F1ZsExybPS2E/wZ3IoVXGf6I4sEypAAvKn/kAtpW8d9FzTji
pz6AcHXWJU6NS+9PPhlEGgFc7XEOQwQmPDwpGZiW5U9X8TOWs/+WrDcWcTcK2SC3
CcD0ImD+lBeE1e65AzRoxwGZ9n5VggGJjGyx00y1cB3BhWlGauhNF/SWoesAVTD7
x14FgYAZBMXEK4Mqk93wAc1TOSjfh3INj9fpggNJYgfzxKZF84047PVbqvUFO8Fj
mgIlDnAWyy3c2RgyHBYnQgCuJCn/2g0JFI9+VX7SOHn9S3pbJYO9Ymb7HlTKtp6B
dz7vKi20Ea3ZiVKm+6XYM59Ky5aYYyXs7rQwuW2mZCAOSnSMG5S37nLDPVGiyfh2
4p/jkzD7bpdJQeODBHiZ7SJLmuxuNXMWS8j999VZxD9JN1PgSALiL9ozu9OcQIYP
UrjurO88vCNjgl+yUmoGVxdV77aZwylICsKddopK4zcGNlLN7iKri/hnLnH7WWm+
V12khcPuS+vFvH8uRT+MvAp2OnrgEpLUuRV+kBqjuExPMpOPlGMj/DzP8b5djrT5
w4zRBQfvmzuzmEAXR8HnMpFvzSTSYopqTCPWxIAFB/YkVqwTG2or8flX40aAVF5q
RKoyrCYu8G6CI0AyaOxxZtqH216uC4JfFzD7TN3LONYEbuI+TZm8bEwr2wvQ05Gx
Cvrone4Wq5gMd75Sg2P9yqeqdx5349X64AAYR/SXmqwMgaQ9Xc9kKHopAs4tfQeC
a95/lCFVDzMgnCXOTcrM8C1WS6kW2iYYIvqv5OSHNGae2XRRCOYfcWsiMF22Za5g
wTS/eHwS5yAoG+HecYZWvnmV7rnMYqY+SzCvfFHQS2aTYCJKvWgsfjxl7k6dJKc+
nYOiQnFmGZxXb65HQPRs6R6WvaeSSJSAPSSDX84rR5D/2mLTch4KWaSz0vqj3S/k
1mr/viP/R5onlZH1Ma36+Wwtev7bwzFLfcTmCKiba3HH3TPg/yabwn1J++EwIMIx
Mji1fjmdl9MhBYwKU/UlVvLroxvNHPa59mDDXn/o54WkK6R3r1CQHKWU7G6kwVjA
QMG+hpSpEtH73jjgcGAnDEl78dFJ6w2wmbsAneSciJEbUheIukoxamhYTBY3dGil
dfHlX3QcKqlg/NdlsdWyVxH1H3/gGmrYyAnmsdqi+qj90IbBHU+w31VvYmvV0c4I
GXxAwJDvxZRfFqLyohLMrw7wrdr0q8Q7QtS13RhKK/ai5YWxtWSgHZwTiNTAYMjA
Dgwiw599bQ3YFZhoQfF2N4npYRVTwDqxH914CIAGWP5JBB7mApBJEgfmUySVy8jY
v+NTpdKHUXSnkYpHQwQyCcj1BM17gtvlQaWWEZbfvB0uFOxDPvW8dljSvLCG1fN7
dglCUYPUHiq2XrePbhMAP5gVQ8dTv4BLJs4DAoVyVJFLjgQ02ucs8U8sUnfGHoQ8
3vg39G5AZWl1fL2sltdkVqvTXlTJrvBnD0nAvnFeNDYtYFe6iMKWeywPW5hJE72T
WvufjxTTn7A2p0GHl1m/HBW43vqrPHZxaIBE1sinase2MIn1m0+1v52d8ZSp4/d4
PX2auIgY+l3HtCvxM+jSOwoRpBhmnVFqT71pKTJO0vIloGaPEp4mfrU2oA1U7khy
+OEeRcSebRQuDzFrT72b2SSDQhZ3u0V4mlehVMT10r5NyfrhEBBX4IbMscNmOzZk
tjzBaoABCfaWHnDpWHhQYXtLbYG2lMC6x+fQ6HfihMZ+9Cdz6vMRMRwLwh494ZsU
ZrM/4WYdI+OTzi9saxbvO8+hfHHz4ZF+uLi6ESQt1R04rJoGeW59I/WcQmyugOsm
5R0vFIESeyrk1wWQOynxWYb/oysY5K3FjWPq7fq4DOmEOzFKpJpmxylSAImjFTU8
/uHn4WQZjRahlq53wIESF4xUse/uQ6lZtIt5HjdHo43yavUZFSz8O+dtItQN6Q6H
GkQdeMHOlmx6Cn7eKkHImh/X7qDpcJF+kkTko+ZaDJl+q252vW1/gZ2qeFrvkrZg
Ffy7UmaCegz3OYbMlyyUx5DvrcRJ2afHLRQFScJDAPr8Q6dHaosJttivKDwnk+bk
AJKUNTd3ydQDvg4Rvu/hOAq2i0JvAGL3562fpW+0nrAVg6jzgciegPpdwRBaVI4j
kSisi3GrzI95JEdzET5SZZUAfhWNtxVRCPzjqxAMbrbxYZM5b+JbZn5A0oSrB937
uAc61fbrAtbf7vHnMbfgYKxDUFiDiTwYRfo3KGmr/iYTJkMTc6XK68hzx9tJ5lIx
q5J0cT9z3iOV0P6i1CvVIQ94nBiAY9zi91BepnLUbAU+jKWxxFRKeBNeCk/p7Rkf
SMkzMf0V9kSabBszozQsBYEaMPn1Fn+ECib/QUi+MQZuMCq5bLlE3ju/hCGbn3rW
1g7EPngvq6/QCKY4g+0lZzVRcHvVkTUcARiwRqYKz+wkKmVmeatrdHluCSuLXeBt
nO7MwAegv4xA4Fm8x5ynx0gPFI5dDSQvsd5ykbCsncb2FPtF3qgTmqBd9XlpAQTL
vN4nHCsU3iqG5ARFLRaa6/kUgrt7EDcRZFwX8iOk4MUaMTvqitUI9qaQadMtm2Ig
jCs9W7Vvt2IfKbQmEEyXrR2UIKIZaP4CKWQEC4IXzWABnrAIyynbieXOgqVjycEO
ez23+5NMSOWIZcsAMxAREZ746jLHSgluglQ+9Ztj8cxETCl7OXVRB8uODCXG2ymx
qRebmZYQUga3/VYbElaxTgdHI4Ncx60ANkODV4tYvfiB7FesVIedSGPwG0BpYFZd
/ZbTUtfRY/eEhGHvQtseGZhZQqNtx4honGFOAZy220IRRsViwN7O629ImSn83PaC
hUNOgguUEb1fZevvAgyBE0rGXWXUk5NDsvbclKLd9MixTshVmDOdtpuoko0FzyMm
eZmt+ld1Skpnxh7YfQEQ86A4ErS8QuDXXJrCYe/YP0EbpvHI569i/xxzhh3ZkQ4O
NCKC1ZPiz6/EU+2MKszzcH4ESakq/jOXXDtnqPCMHMSZq1/afGhFMmkemPzSY0CC
26Fs/tAN1QXnZZ9fqrZpsuf7pslhROYIxH4RLELRdCemsjundOsaVY4CImksM7p+
2riuFOEt7DHPYBsKw6A/yGcUZZ17qpykycOiEL/zrvf3qM8tcSG/X5qF7UxQv5uf
wM1CHXNIlPiX+vmXxiPTo4dB9sJ9PFB4vFY3o7wSfFp8nhW0IlOt3PR+Fefd6OGS
zhkKxSS9mduYVY0zohgr3pf+n3ndHDNv30CdRxLwkjljHyzqeDIPkS2jqcLfkdHr
bs/2DLuIu7OCKM1Os1YFzqvtASmfyQGC1eu3ENJfYkIT7Yqmfx+JdymTEaPGyLNK
BOMBj4ws0dv/4Y7vCJuTt8T2Hf7AV8odFtdFbiAzrA+yRJmjIzOWJfPBnyNHR0hH
2N+B+imV/2OrldnQJ7B2bQXk9B9EtC5aET2yRvMif03a9E1a16yItN7VvJiOH20O
Kvy9O/QdD8Q06qz7ive2GxHuy1oquOyG4+zqk9wTCaCuzvG1aVQATskJQZjXgkSQ
sPv3fhACmfmdbI5Nc66MRNbmxve+6WieRIiqbyy/CJDVgX1nP//rPsx5E6Ac61US
2NuYNXBN+1PsLGr33wZqDnsIrPDLUhMl3WYbXsfgEzwG81qHGxhpmb3L0or3AJYL
oxBIcBA8S2+43KqzvGRRVYNnoKTenVUfx/HN5nDG4iQQQzets4ygPRms6VKUrRIj
JGTFsk7ES4eKvj6VffKs+MCHdZ+DLYGahRrSd7is+uEaYIE1eVmvizrZjGPfNFg8
7Hu7dvPEA74C5iMg96KE2cBF68R+ENbWeYSb9CwDr7CXwJbh3pKuOylGAN7Vmo5j
4E/GZFcvVCc0ngvtgf8/k6D7DEfP8yQea245V1pUerteCtZsAOvGfndiCz1ZGwbU
sBbYbN/L98mDUMZAkT9ISKGVzgQ9VHhAH16MrSrTeORpKlDAwng9acBNzUkGuYUi
bXmEyaMooN1S9Zn1B25Ajl1KqdnvGKf5thQ2qlf8KyZXS31M6luFAqqu98b3/a+W
PxXQ5HluJEpfrBEdh46zr7MkR4vwST2Rc8cn7ESqCJo=
`pragma protect end_protected


endmodule