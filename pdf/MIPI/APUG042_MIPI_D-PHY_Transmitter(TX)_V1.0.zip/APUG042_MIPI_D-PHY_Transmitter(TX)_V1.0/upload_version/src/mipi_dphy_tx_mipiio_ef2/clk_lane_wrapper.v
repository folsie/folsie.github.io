

module clk_lane_wrapper#(
	parameter CLK_LANE_MODE     = "INTERRUPT"
	)(
    input wire       I_clk,
    input wire       I_clk_x2,
    input wire       I_clk_x4_90d,
    input wire       I_rst,
 
    input wire[3:0]  I_lane_state_code,
 
    output wire      O_mipi_p,
    output wire      O_mipi_n
);


    wire[1:0] S_lp_data_in;
    wire[3:0] S_hs_data_in;
    wire      S_lp_hs_switch;

    generate begin

        if(CLK_LANE_MODE == "INTERRUPT") 
            begin

                clk_hs_generate u_clk_hs_generate(
                    .I_clk             ( I_clk             ),
                    .I_clk_x2          ( I_clk_x2          ),

                    .I_rst             ( I_rst             ),

                    .I_lane_state_code ( I_lane_state_code ),

                    .O_hs_valid        ( S_lp_hs_switch    ),
                    .O_hs_data         ( S_hs_data_in      )
                );

                
                clk_lp_generate u_clk_lp_generate(
                    .I_clk             ( I_clk             ),
                    .I_clk_x2          ( I_clk_x2          ),
                    .I_rst             ( I_rst             ),

                    .I_lane_state_code ( I_lane_state_code ),

                    .O_clk_lp_p        ( S_lp_data_in[0]   ),
                    .O_clk_lp_n        ( S_lp_data_in[1]    )
                );

                mipiio_tx u_mipiio_tx(
                    .I_clk_x2         ( I_clk_x2         ),
                    .I_clk_x4         ( I_clk_x4_90d     ),
                    .I_rst            ( I_rst            ),

                    .I_hs_data_in     ( S_hs_data_in     ),
                    .I_lp_data_in     ( S_lp_data_in     ),
                    .I_lp_hs_switch   ( S_lp_hs_switch   ),

                    .O_mipi_p         ( O_mipi_p         ),
                    .O_mipi_n         ( O_mipi_n         )
                );
            end
        else
            begin
                mipiio_tx u_mipiio_tx(
                    .I_clk_x2         ( I_clk_x2         ),
                    .I_clk_x4         ( I_clk_x4_90d     ),
                    .I_rst            ( I_rst            ),

                    .I_hs_data_in     ( 4'h5             ),
                    .I_lp_data_in     ( 2'b00            ),
                    .I_lp_hs_switch   ( 1'b1             ),

                    .O_mipi_p         ( O_mipi_p         ),
                    .O_mipi_n         ( O_mipi_n         )
                );
            end
    end
    endgenerate

endmodule