

module clk_hs_generate (
    input wire       I_clk,
    input wire       I_clk_x2,
    input wire       I_rst,
 
    input wire[3:0]  I_lane_state_code,
 
    output wire      O_hs_valid,
    output wire[3:0] O_hs_data
);
    

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
QHraEgTRLwMpIxjKTPY/d93EvRGFpSoijnb+DCQMufc3HdFMrPYUlnfmWC5MNjXS
S63BMwQw+/QodcYvkJxjEgsRkcNEwghCLwtFcPBEZrJMGai/FFMSrd0reQcNARvM
CeyrBsDSptt6akHHSm7PwH1rUIFDyNZOmlpLLt7b0wM=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2944)
`pragma protect data_block
ODJUOUNvMUVSVzZYU2pBUGxcV4feJZei45ep4B7l1tNgDHTfbaP/nXWfNXxKFxg9
U1xoASrGJAcEjFNFDkPfx6PtWGl4IvNs8HJwmzBYoWVWO+AwtuBnYj4QCbcZ+UNQ
x1Whfe+kbd/UQ6xVyYAhg2cXoLNOXHqmDfr7cg1EHMGX7p6kETAsEM35MQv3iKjY
p9oxTNWrQSm4PnbOSxj4093dJgwyVAWcY4DYbXBCQNMGdYq2u17JWZ1QYiBnn+vi
bKpBHEbvYDkzOhRjmbTEFtagRvj2MSMqizjQa8f8LIzpFOKsQmdVqr2c04gz77BB
PXr0sJSU08xA8nknLjM0mvnVKeYiZilzTPnXNMU8h2p4s46sCn4LLm1I43zebJio
UZG9pxrslz6qKGMtkLWZWTVGDaX2MdmIrTi+Tj+eqQ16nOj+7gSQTIRIVVje7z8m
C5/3nbq5ymfYDFhO/IhO5L7Ue9URQjVu5Xk3HsEfKJnbBr++6CZvVRZXOqYWJn47
O3L//JJu4wdeIxupMwI4GfTsCW9kiTt6Awr9VgYOaO8SMFQw3KCKmymkqe548NK4
NhpfMvR8F5CSQHQTocb0o5HhtcsTAMdDRDv0krln7sHZ+MGsPp9zE2VWiApysxyG
bvtb+iWqanOHaoJZQsnL++pcYEe4veAFipT8rNW/2ITfc48IkLCp5vDPgTJP159i
4jD0Gvpc6q84fwuI/AR/PluvztlgTznTN/HISDzWhGdvRbNmOm5jHrwuhUooDGMb
mTQy9S+JjzfFLU8aPM/klx5g3iX8uvcMYknjgC4ZUp9optUIWPvdmyLshNc2LsXE
cMws6Dwn93Uk2YqRXw5GYAwsxrgPVb/dlCxZ9bWtMOZiSjziRuEd9J/Tdl59S/Xc
J/2q4mk0Q9/3BSHlU6wAiHS5JMUprfcgOqBynzRj68DdM6oWrzyQS6b/Ph3BpNev
j9RK+9CHVtjVlvfQ6I28K4J2Gy2hDiB/QoQYo1hgbWZRGAwLYofR606fFIeNtekf
o8H4mqx/YF/TcQD1bumua80TGKt87CJPDdI2yUND//341LXA7xw6AiXzVNwQ33BZ
VTIywJFgSJCNzkrdItWu1pXJmZTW2DwClblgc/psG5X2shxiKhX7p5nlDCXil3m/
fVlvF0Wg+jYDDmOto1OVg7GX1wxzjbGhr5tvn5OsZwJN0h2OE8HuFT83trdQFrTW
Nbl0fKRaQeDOJXq4DH0ml3MvnanqpkGGWPXgE3cxYbBm3DQXyHExxDwV4N2vfFQW
EtIzsoaQPgeV7KIr+xyWrvrzDHFSyueQwDk2WPRzRpQqfJD2eidBgbaWI42KBvV5
kkAdEl8QhM7mwI/rOTP9HL80oaH0y1ROImK4Hfu9GrrNvj6JCe0gPwadFojNsgc/
aAfw2R5fPkYqNJXjrOKe1GgBZMd/LSd154v1XmeDuM6/7jsgsneRiSvjsQDyh0Zc
dmAad+4XIcZzTsivhIWlLAsLOPqHFew/GdVw7enO1IhWz3qdEbCwEzM5XosyA4FQ
Vt4I0Wr/MiGKhX1BZIdNarxJEgGHUpm+IOUxsf/u7F2ecsW0mmQUKgTt/bBSBouj
E15ngC/pviCVB3CgI92bMYxrHLJOywzqMgOqRs/gDXbOcvE3U7lZJbQ8g5qBiPn9
kh4/Gm4yy6hA4whw2Mi13AEdBvdbD/U1IH5biNQ7ishGDeWq2L5mKBVXig1/AX9o
AeziC+pCZ75kviPKYhE1qKSCcyl2BqfrhG7ZGtRbR63QOpPC3H1/7C2IwSlCTzvb
zqMWJiRBWAtJS6wXI09r1MlZ0KCekpNZzvxSRJOGEo5UfN7o/0PpfnfjurBvUpAh
vMmDxjRFNP42LhQ5XO/dCGoadcj0e+K0vvkTDUNSdoW8/aKmJqDxQoiavVnihU1x
o1x8IjTWmC1lsFkjBSItRm5/4EA9iAjY8rlX9WXCPKQdjUNN21z8Ftd6wb+kZrjM
WqysLEDjraTEaOIZG/CWLgKLZxh1JtCxma1oL+rOKr4Fl9rdAXW8GJ2O5LkgKw/K
CHxnubrFscogV01TfHg/+V8oHEVsHCfN+Dq2xpQUsQpXTGErtWMRlLJkadLXtmcz
xDr9bdmjYVEDU2ZgTuqEuKvDW/qa6Q8V1ON2ZyZq5f6JAr1veWV/LvtfwfkhVZA1
Z1iJ4Nqi1wJJujKVxiEvHFi7l3R/IkALBsq4qqksI4YcbVGp4gNOJaK0dZtpNLOO
xapFQJMwo9mfVFI5l7p3dWLZcrpQigqdQJA5xrAAGGHgeOc6N7HlqwFLRFrmKMkD
CpHvP2M/N0WRHpy9Ji33RwFrvJF9igfO9fjMxWZ2l1Q9r7dkNC0H0XcQymx3hh9q
OtocohzuG87bZ4AwBoNbdsSq1wtgbsq5313VzEJvFuDi3zf5NWjJpc6kbdrrufcU
m+3Fc10BIJxqfzhFB8f3fcuytMFsLjRo0KmAXKNS8az15NuXfty9lxWYeYjyxF7U
9BhkSbbcC8RoaGQSyoYeVcQt189YXWOeO0RT1WqZ/SBrdzxr6FQa4kIGVTTPW7P2
oSps0fDNjsVjVXHVwr/qDlyT8Ig4jlDcYvr4mM2STPCqm6YvJDlMoboD/AemgERx
Nb6iQn5w33yPlEc4gEL3iMIohRpGCbVBZFdHjrtkusJQB8c8RHTYD+ZjUreL96Sx
k2+dLsHnpk4YmNiszFqSTC5FAhJkvNkj4P3Y5ql0YnAgno0aFLRUD9Jw1dcVJBUB
75yxV0RH/7xZV0viDw9wqiGXcKfYUto4u7hU/GS2c95X+sBC2FhlnVELz/mYBh54
4XKzJuR/q55S+FnJLZPJkfFEvJmA14vvmEXLmjlDzluzYuZx5Wxg/h7Z4Yb84LW2
JO6j8nnySEcqzEdYd26c2yNcTNFUHm9xfzHOYZAt55jcN4MgIRjauai3U9BL1urL
JMYLBJzMPf1/1eI1TJfFqXV5ehAWOMcZ/tK0sf1ssZe4FLmTd75UGrcstkK7OiwF
JwBLi5HCrGC2wejuyBDH12VZVLgksNIfUFfhXh3vIQi9Qr3/99/YeEDMY9NH9ESV
B9w6VPAs682B+DG/1UlN14x2hEf0h2koYIkKIHLSquVoPWENMaFOyebM61ifHRSg
s7kH4EmGl55WrUPohaDVPI5pvY9mYN6fGYb0+Tqzm6WI6X6nHEYE4+mCnXO/j7Dp
6B3WPfBELBgsxs3UUiqmyMHJKWEmUMQ8Fy0e188ktJwMTNk4117Hx1IO6S7gldAl
CoTCHFxfL2T6y63fqBm4zNMResMLUp4mm9vckPk9ZR/ftOO3ijjrh4nULRiub1up
22MiAC80SHF05SkJa+o5ZLoXe4wjz/wiGZEFe1rqD6x4jaNsaZYyy+sUVE/W4zvU
zvdlR+D/l3IreHygkonyRrx4QrHEZJyfauREa4wvzSWmsuNnvDGXbaX2b9ELJKdU
WtdAIyuRHMQNfZAoxrY7AHBU2EKXQxpMFknA1twKWUZowjBzdnJIte+B2XnDBN1U
3bfMGmJ3sqEWN3/tWK5ALQfTjsrSaCFAO3fFWXYEGJfmWn/qZQHxfGnGOzWTbOfK
PFZ54s5SAgQF3nldVRjurNXUQ9n/DZqEhXLYtAo/lL6Wh9tNSSJECe9me2SNV4c+
OtsuR2i+reEDLCwGBRfg4LB+2cYy0b6KBiYpTyyRBtLhS4okVHkkIbLbsNcK77IR
jn4oSwge7j2dP4Ac8C8ueO/blecXUd+9OvOCj/GkVdqL9XNhQty3ipfc4OW8gm3D
WtqIqnqlbPqaOvlpQufOqGFElifMc6nZkjX0QtPUBtCJnqLUi8PNaUBK1d9EwoHQ
hTuVLpOByk2x/8V6PmZS0w081t7yQ+jtNm+b6up/yKuJQxHDGGKt5oXh5IatnEEh
cm439ueVeZ15NPkUV01RYw==
`pragma protect end_protected


endmodule