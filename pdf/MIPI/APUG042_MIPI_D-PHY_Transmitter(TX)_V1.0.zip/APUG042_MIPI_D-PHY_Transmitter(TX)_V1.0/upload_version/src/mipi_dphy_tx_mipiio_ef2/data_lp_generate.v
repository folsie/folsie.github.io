

module data_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_data_lp_p,
    output wire     O_data_lp_n
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
DYIuEZ17z6OQvwNMlmrn/3FLKWt03hKo7XR7SZsEUa7/rqRt0VndFF0nSC7EVbP+
Utndz/NuiDN1jOHZ8DGwyCvSmC9v+0laNGYSxCFIA46qycfQuPgR6CVg8KkEleFw
L+fgOOZdF93+CX1toGX/h8iUbJQL4GRGBweIKg3OiQ8=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2496)
`pragma protect data_block
TXNPWXR6Mk02aWpySUxZRjPbjt09KYV0lrqWJp51gY0lnSr+QtMdUYL8x+70Qece
EsGvYV9KhDMPlOJPID+QzO5niggWeOoCOQ296DywyMUrSQWEcIm9mttm7WlzcjyE
moe7gVPRXldDotLLlkPWQOdz6QC1hL6nJXSYocl+Wb78jTdZoK+aw8sxbKdoKgrD
rBLsQuFYcWpnCR3mNtVfPvojOK5ga/D0v0HCoXm9DdgW4PzPuhaMhK0fdneHctNU
72Y7yWQmtvkJKiKmIS6DuES3iQFP+a//LMnW6c9dtvNM5+UnsLGehm3SVHYdPpyx
t8Tcy3+OcYZ5PNgb0n8w466HTA8JfTiIX1Vg0PRlg/WphzzmS2QGpx0mt1xJOSts
C++/Es6qQmY62SvJny8y5yHVwU7xBo6t6tH0X48Otel+FwKVVBIuL9UQBI8FOdDZ
7z0qf9obAg7EqnJhkoC3odtwjwFcFy+I9N34AbosywDgf8eAAw7x6SfGntFEO26u
LHCEw9gOx4fsh2x/TYn4Xs71+ylUdV/HPT8HjhIg/9+Fgr+eD92PVGK7LYlC44oD
O/ETuO/4QfL+FSUz3yFWa/PFV4NR6JBdzMiXWlrOU0t61C1c3yvC69dHW+NoghG/
vymAMDUXgDUYwPaj6Uz0FyRltCyk91xzFBenAt+/u7w8hTBEHwm08rfhiA9zA/Bn
iX4o53f3Jc7dbwUO203YXOsye9DiM8gMZQZUlRIMUYsu6inH49+OOR4tpnb0e0TH
tYnwIlBAxJzSP716EOtIAIFRDqqNSkfhvKR6kkAGnadhhx0XkoUYDt+jeebrvsij
6AFk+q8lszeVLc7zNcvcUvWwSPrk5WRiuBfmYwGKKpMhiSYdmnVSyEiNkP5NL2Jx
o/o0ql0E5IFKk01dFkkpQFaJCsBLuIO4D8BPkYMIeoYHVy9iqMFiqB7Y5HE9bjNc
a7jGXzxnLrbNCy5qgKcMLozOxXXvr2pMOOBpltBQEtvTHrvme/tWkucKoONkTBP2
XhjzaSH5TrWCiHxUpKT+/TISHGZ+VmznjLudm5EPwxSyrvRZXH72Wm9zWFuYohBr
lsJVIsvrXw02X+ylcuSMQ3OPK0W6AK8B1lOqLg+5o2VR/LB4c7aw6gR7iRMVK7x4
JwSzDnP83sYTw3HYCBa9vghEzfMZKw+SS4HLkAyw0X6Xjpl2S5y5B8pw8m6ykkXK
uSMn6AG01Pkqe3vCRWYMD8tlvVgBnV1+ATrbiibLN/M3Mt/tjD1ePi5tsxa4fnut
JB5HNsjg/OnZ7+WPuliZRdJKoFR/rVXITh1IUyOz6ThYcV6xjqVDHay73T9regK6
6ynHUjUj3HQktNvasmP2aZVyjB7a6TMLJYbF9zlu0GUK+iixeWy2vuUzizmB3iri
nny1nf6TCmTuq5YkXQtWbd2sZz/SgFRpBZa3BHxlyTt8Y9r37RvC+CN+slalmTBH
VQyUoQugrYh/ZWfkvfTyIrJg9P6Zpj9DybLXU3enJIXJBpqoLRrXV/uBXocFBI5U
a39C2eX/jhMyMEbxsv+IsWuRWrgj80qsPxOXXhHxih0dwLFo7r9CJvgCpLz8t7lP
AF7f2+1rf5KbnjFIWSEktrZ+lCh5XGVqi+eD0wab/AWglza7pZSdB/CMU/vJuMvF
R1lkGzWgtI+6dr2QFyM3o2yKLoqh8OQm1UmXPyZvL2tE073ZXzaEZAO6cYN5aiw4
yUZ7XA/zdwzJF7mREp2UMp2IEHi0F27NYhsCqpcFj9/Hr3MMGrfsjab7b+/HcFM/
dgsubjjh1VPsLPMPvtv5A81GSB7OVplsuQdIoF4KahWpBG3GysGP4p2ZnI6PKR5O
NsvzQ1j53SwO2yRe+BeI/W4Yuk69F5hvYCpmPSh4AJPGLWhRJJtxhOU2PnZOXUTn
yyU+sccnZcCKHnAmDbZ3gcYZdSLw+meClTx8ObwtWDHq9mxfV9kGvyXnqKWvZgB9
WeyFdDexJkX17yr/FDIhqsMlaFadFJcilPpQ6/7LqRrTZvOBsDT/09eXtcuhAo5s
VP7WAEiZF0Lds9YZxu8PiLh2Py4W1LHXAC4zv2TLg7qdoYqz/oOTmq49WvBkQS6W
j1NIiBT/CKy64QIHrCpmIJzJ/RMB14FCn7/2TlbEBvG7qQYfRhi2JHlGLREWnPne
MKKKaqLu9PgHvYOnp8QDX1elxj6IVMEj+Cjk8L6NN8qNyINAzDvC9HwYamnSP96y
EbxnPtTgrQuHiImBijZ58ekLSHy803JPEZxb1aKOi2MLgpaBAjTsFiI6gWVOmA6e
gC6Uu7NK3/q4HO9aElJSEFNAtMJUiaPImi//RncPNNPhsIDYacIa7sN3px/0VIq/
C9HZaxZtpJF2yHnAehRkVbnNkYZvp82yCZ+OMQksMYxp9kGU6ggeR2o64icj3Pay
7Q8L0+gTgWz/3Walbp8WfVqcXe6+uchg1Y7lvH/gRiNWTicHjpyGXChP/LC/wcup
abjSsEiCAjls5wXUGmClPrqwPlTYn6faAXaskRfexW/1Q/haU2MfHAEQC4m5kV9e
554QsiaxInW+r6DheDXFIeTGL8vbvg7MNrglul8FMnt27ZEppQVzTahoYpJHgGK7
fYmFRbvGnWpSjbQr067+BzeNRivku7Gm6Dt2tj4DvogmSKUllUIr4yCGc+do9azc
GTGuUvbP3D3HRNxVX9MpQaJXuMG/jLOZdgY3qT+2dMI8Quoy+da48iGiu1nw3Osq
e+GlSdknZe/ZEbELz0n/cSnhcJkZRYHF0CWeZRi2cGUk6mPO/NKG6Fj/P9f7MscW
t95jgAYZN+5PwWmxPZ09S5YvGnLeovwexSG/z42ZC/45YR/zb2B/WqXPeMfs3W4v
/YLaIByY06igogyf1B00ipl7FJ+99uOjLA0BjFJXpbT4+i90Lg+E+hrz575uxQ07
OETCOXiBuJWj3G3ZxQxxey/Z9qlnapvEY+xl9SjHWNqrYbEREdcobh++A+OUqL0b
5Imvk67XDRWXwUKoIgXjPb2/6OrjpgF5/5eiQVb9TkIexf8Q6lMnmFg3j3Rf5jFq
A8/X97OUlP9tPZ+gJHrT71ze4TsQi+5axHjR3p8vKdmJn1yt4dQqf21z+5bMXWwV
HQFZuPQuE/zy9GgJhmQj2ivb7ZdABC4fL+nYsVS7Q5riv8SdXFa50GJ3AN9AgivK
YIlvnnQBef8stJa/UkDM/p9yS24+Ybry47BIwEe9CqwZ09iYEU4lE1hFtmq0HSsg
L+gmfMqu7eWImGcx9IqaYUdaQC8Kt86Me1XQrUHZXm1kcPbyJnRJAaXv0GUJBc1R
`pragma protect end_protected


endmodule