
module data_hs_generate #(
	parameter FIFO_TYPE  = "BRAM",
	parameter DRAM_DEPTH = 50
	)(
    input wire       I_clk,
    input wire       I_clk_x2,
    // input wire       I_clk_x4,
    input wire       I_rst,
 
    input wire       I_tx_valid,
    input wire[7:0]  I_tx_data,
    input wire       I_tx_last,
 
    input wire[3:0]  I_lane_state_code,
    output reg       O_hs_data_end,

    output wire      O_hs_valid,
    output wire[3:0] O_hs_data
    // output wire     O_data_hs_p
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
JM20Rd2VViEF0yK9sQiP89G2Kkb1lzCZsc0SWdsoZJrP5xw0CwS+mDMs3p1kEJ0W
mubnrLgOERxZako5GxbGyzYiQ35D5SC1W28D2+FQPCjI6zlIii0ABqYjm/KnuhQV
zufjW00u1EEm247+pEUhWzxSecNN858uvyDkfwMGc+A=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 3296)
`pragma protect data_block
WXU4VWo2NFhvNUo5SFhvQms3+VyiLRh3pEI2VeaYfm2Htv6paKksJOHq04GgXnvo
+HB/0ITjrTx5xkx1B0LIFJNGFhCNHX3MBWLma5pJQdAn4VBTqdA7LV2uwr1xDUkp
dcqyjD2rRJwXsZkCGQz8XNpYaA+o6VuvaLgb6rZGsLxBJHi7MyTfvL9dlBZ51CJp
HzWEYjf8cB/xPRKWb33LSG0kYjemnCyq/tS4kiHMpD58RgksXCBdjFsi38ARpfnU
SccSte+BrTueqFpOAjBMQCOpJqVJWwmf5pemKJzBSskheP33EMb08Ab8E09+Xrnx
3wC2T8HbxgYYR4GcBuQVEZFyhkMX0PbAh/HJ3mNqpEvmFWrbYAYJZLpjjST5kfIS
Fuegch4OYT3blnUcLukfrayfMfzwPYP/rJfZqg+hke+hPAZif7mdExvi6EVINhi9
kltJYVOiH2Q2WRYEbY+ctu+HmOaB1f6Hvu5qNUohuHm/FygQcBXS+CW/JSWKB3UX
3W0mQZS0GlLONm/4KSRh4uNidGblzH2Bw67Kx+JU03MtsroiMJpWJN4lakBYHeRl
VsD0AekMQxco1ScLwjjapNsuROWm4lbtJmOGhVNGo4Ew55NO5aeY0KbjzrQvj8IC
gxh/O8VzAt165Xo3kjyrSvvQ4oZIljCKRSLJhPs32npcpf5rnnJuKG89Ckl+4hQV
SViFVcuPL0SFEROt5z6dGn8UewklMAzRxD3IUQiXnB82tbvu7XVi6ipNdAb4oe/c
CV+J7vDw6LplRmGCDGmOksBAaFSRhGOGa07nPOqDL0Y8nWilv2SLPLUoxCH35crk
f8qpLkyjj8Yj3HSYIJRpxiQT25jWWTKFb2Isy3AK84ANrgwnmynDIEmXtrexD/iL
WEJzoF9nnmuDt8vj6jyuhJQOYC/LCMUsXuhAF2BnlMSJRhPu+kP2oc/UsKbGIfSs
8WaYyYxWcwF6h4GRJ7VihLowusF2RnCS9w8mRpSie/eMAzGiykCuJ9X97rRQAEvh
YowtBZykDVofhb6rUe4/9X4go5QNCV/In4W4uwXDq2vqguNXBoFiqHYmpev22gl2
N0OF7o43/rYW5MROITOcigOw6PbR7oxxtd9CYpsoZwusNVRxSNkRXZhPs1Bxsrf2
9rPkhbvqId8VZBrCdzRz9G3zTyrrl9uun5f6q0aaGEx5G06RriMkJCeZfPe2hve3
YnSl4gBXpGrfKrJKsm7Flz1cS0EmnKwdD6CCj3sVM1zRM/fZMh9Xx8SdEmU4aRfO
gd9iTfnAoJ4o2rhDAu1ptPsU2Kj3PHHeHzEHvuBlkXy0spdp0I3Aw9K+9VCNIrW/
qqsOOK/kuSOwGJcAWGnDClYNezce9KNWbwN+if1+bOfupEyJXj0Xp+OY+KXjbxYo
U3tcqjFux3j2Z41HkDgoL2Y0tzaqg8u4B8v89TVrdm48Z59mn/r7TxvdYqe4NZUh
Me9rjLCbHlBwOQOpfbKowuNjyw7CF+S7jQPtdDDQC/4ZI187Gx3dp/dh94dNYTpr
zZc5WtiQCmIAyCmTvT+1PgAMmvoP6Z5GMWoHY45GPNxIK+X44b4/w/+YjG8DKgDe
0PY9pGfVvpPlkbX+2sYwEioqJGiQsONmI4jiXB4ZB4CxTYndO6HdwuRWGft852Ec
X5dP5S1uK9FV2arPIOYHPDEVEUuISUfWu4D1mWRlvr3G93DiV6dtXnYX8hdPPvvg
yTSd7yYTA10dWbfBL3hkHnmcxY5DjQbiEMPsa+FDN8ASWZG020c2cqjRZemJIPsC
a9IE92dLg6Ja6SYPNp4oA0sJcDg45/Ct/8KPgmFfFb8eakRfpFtLQsuwDWrRMmj5
htnF2rEYKzaGSDdYJfveemvPyJtjXO6d53oX56CYXMrdJcZ0ppItXHWUWdDnM5Bk
0mEKijybIkoFTAhPG56VqjjDiSi1pOAda2RYEp4KC1o/lvzio7F8m7wKbFl69LS2
PcG5NLv1ux0U+ipSY43cp91IrzaOjujwjSu3aHFX4kjvupdv4pXrDmNI00PcdQip
p8ygi/TtG5w+bhQe9KpFvmKLxvjGo2OegIx/15yG6D8fsis1SHQczMqcAeBOLg12
LQApDKUZSmxwvN/+PieInsAC05W0sfKVinR2KZxH39apcgWn9wZp6Wpq4rxIwp35
R3bkO0bgzJRa+wICq2sQ6uglFMJibRxRm6Akawr8OpCymZ7tVxL2Bw5hYtc+K9tK
Q+ZIR+KkMj6kGsgbOAYwyBH3MVslvC/dj4LIFDsfkb3Bs7l1imq43thGGRE11hsI
0uo0GxjLIBD5Cptr48O9A9tHbdvBGK8jUsspaaEl7oO0voOkw+RHFsahvhRrk7+4
Chw4fBAAztHDRySCQXPCqMXPT/cnbj1qjHhEvjXybDaSJwcgCqVh3SyrSSoKHvTh
E48fYvdixumEEgnZak4L1sxmuWoxIxyos5CKHxeXu8DPl8kwUXC7G05I7TsuzgL4
zFQjkwJFN4kjchqgwP33EjWBV/K/yWAbhgoBAK+N1G6QAWGHiKL3kUjQwcQGbeWG
x0dIWXd7h/dII/UGUYGCDOPiIarGoVX+fRAgWQzZ2ur6hntIE3Cr+ThYgYaFw7xF
2qwY02WZSfVMe4c5O3zNArK8sT5Dvn26f5gB/UlPX7NFKGbYkW3ItdbnQ4Hbx4cC
2MIZwM/vBuFvlANmrZjpPVwkhtQ1S+TgY7c2OsvJ9q2Ri+F8aaItUQ+foRCGNej6
AYvZzVRqNWegIAhzlI14M+BSwSZmmeclvS4/cjvnPTEQYxQcnIMG7emvgX0HgqR1
CfMKiRah6vV0Qv5DVrO1h/5jKoFL+xjJoAEdAr4osyut8+HyC3GV0anGnf7XwYGH
nOQ7k/fI1XVlIPpGsa5aF39uv4zEnmiFWQ8CWzuWLgBSWCZIltchl++GjbUdCXqS
W0IrGDLgNuWTcxsXmOxRIZ/sbXJez0AIfXtRHL2GONs/tfqJh/eXwYjUaEJJ9vGC
rjzpbkoH/W8Xou0p5JEOnQOS935SeZxktMdfggfKAjy9dwgtR6ihpXToIgULC5nf
Dv1CQFWvor9QSfMP3GkQ+hXY0ZdjBN1muA2auJHxxTtzF8URdRVNLtWEPkdcroSX
QaIOaR2YDr+xlT+y3OUWezWKsNZWZjk8QbXqCFBHAcLmamLU36Sm2ifw7SJlBNrd
1A+r10MzquLdlCweBVBmqwLA/31d8MUIo3/0hsSvuGx5iAeUrHly9hS49jBqe3oM
dfQ1quMJ4VhmAqA7Baqrg1ZmKXrIXIQQadB68s+KvXV9vn3mRD6UerVW07oaqZbn
RJjiK547rAXsx8fe67SAen384c5ZENqV8VABSDtTAfKb6P2fS0AVGDxM005eJW2g
AtA5Y9+B3dI4DGP9d7WdGirIwjvKPx6I247Nv7Zn4GU0rqX9XzOewS6nHx+7Sv6j
6I7G5fzQM3oblZv6z5Mt8SWKWyXc58lOGRM429wq8ArU18BHGckI7KusO9bGTKVo
Ckk8G08Bfcr7RoxuzwQ6oDD/OA922JPbxtQ9wPVxVNh/cP3jJIZbzMAU7UA1bjlX
ndrfONKEGUinrKSnVmm7oYdS3s2BPcjfFpMgtpCPWeMsAG3H5thSSbYFQ9Req/2b
fvklZJaxxLoBfhSYHlYle1mFP1TRDddIxDgUmsOzD2ifXfyDXwIZh0UZs7Cna1fL
yC0Y2zz436rF8ckDna+JoI+UfjHwA0eyAJOxaF/rlQTX/hfuP/mb2fYauoa8JA4F
FeSUH45cBjs3tEg1lPSCpyvfA9SElTv8waYJowwRZ3Ar0ax2hbgwLv2bjV2EN9+w
3ghYcGtgZtpUkIegF8KNhCs78UQ6SR+/Mj/FwEIigGOqAb/dmkL88hahUVfCATeG
LHxyboPBoT3dHaxQWDPkxTSJtyVcOOmufSC4yxvqnOss5oJYm8CvjoaQSW+HN2/z
QP0r2t4bgOWeujbWxaKBa3Irwh2WElTsqdE5AaaBJPx7+C29jdcH0LNLxvXzuMmO
GNwaiLlrx3WEgvb3C2VX/8UBJF78+WRjIbnZ39n0Jd1hXRfgeMXS7sV66ko9NfUU
NR1ib4zcFR4rBxbvyXJpmDwcNt+Tk+FWUBEVO90aJZLDSr9VDhCdZNwgfOptJEl7
NiDnDrTvqoeS2FfPG31sD8vjHx/DdZU7J5rcCEe8yK3Dml19TNgbHzatWdvxdV1B
ULzHrv8OVm7bclb4GsoXHzN87bJSf7o6S4EBuK/TLLODGsdHZkhn9eMWs7rAbzuE
MSb2/tBQx1GzQMjqg6Gx71BtwKsjZdEvw0YZC1q1VzLgyL8cYvqjn+r4UnlnZAck
+QqyOXGMSHKx7RYj26CEIFebPhby1ya3QwMANQfhw2s=
`pragma protect end_protected



    dphy_tx_fifo#(
        .FIFO_TYPE      ( FIFO_TYPE  ),  ///"BRAM","DRAM"
        .DRAM_DEPTH     ( DRAM_DEPTH )
    )u_dphy_tx_fifo(
        .I_clk          ( I_clk          ),
        .I_rst          ( I_rst          ),

        .I_fifo_wr_en   ( S_fifo_wr_en   ),
        .I_fifo_wr_data ( S_fifo_wr_data ),

        .I_fifo_rd_en   ( S_fifo_rd_en   ),
        .O_fifo_rd_data ( S_fifo_rd_data )
    );


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
iyShcfhC+ZZhdiBuLDQ4RoEQzIKFbw7JE3nTVJ6cd6hrHKuvUyp8viix4Yk9NNpL
uMMoETfKvzPGwl1lAi7VTCX5DAJfEYqxfGF+Q+1KdAiHWbzH9XqCrsolpnRcgkD7
Lwu0XUmcDUCuQ91SibFTU0daf2+kC9NdCwAOWaGG0Vc=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 2592)
`pragma protect data_block
REFUa2pKN1ZQVU1RdW5ObiDYey+qfjcFuo09M+xpBQiBnvRekjkk+/xgTgCbs/J2
ev3ZNBJF2eFhmhwhyxdkEhmFEvQJ5jKQGp/LET4FhRba71nFxAdHu8FL0GQ47zF/
D3mVbHihkgDcyPHaSny03Fd8NvMG9fTUp1jsCmAXfEc5SinhWI8BuwJAaJf5oXqP
X8T+5O3kp1qich5CK3DqHadXrpgU1GVMn6FGEZyy5lPuUK5+qeIremNwq1C8S0lp
pdHF7lHsY2pP8ehmySgcfFoYWwLSdyaDiZpra22PobxeDFTu5wLkUrzX08lKhtVg
WGgWKr0OgoC1SKoDgyNm6PuEcCaubq83i5s5mz9AudTq2S3dDMfJc7nF5J1NQBuq
Bgfd4WwxfkaBas6czdeDKQVPf4ze+o98YWXvXBXljExjapXnxR1a8eKP9fCR4SDk
BkbBTEuJQNHLj8+hZWWxOluJporcsMHWJZUwA9IgXI3jxWeAIbiVwQuCdDtsXArA
85I3xyQSkFiKzvFD2T3JPznZdFbAGsh4kncPZ+WTLgPNcIm7gWtoZ+c+p0Ei4vXv
/5V6cFEn072IXguXh7p+KZZ+GDrPGBEZo2C+CovSIf/SwIzafxmO8tv1uXDNa5M1
siuZX3Wd8fsfHCykjGcRqw8haNQ9nGL1/q3B8fHj0eQjbEIngvmTEiE0TWnNxyiS
A+TJtDX5gT0PtS92T1yASNIr1r4Jms90o0e0hxEwC3MVfZMDN+DGks7EKHwT9U7I
KVCMHXEF0PqWkWvO+Uw1fPp6o2uwXcHCwLhyWxRKANvrQyg/mkJ0a4bcgz501yxl
hP/gbH3tXqUY1rjF84dMYMb8ESjl+CN137OrSYPWYyHy9vrunf8Bn3gvBFEqQyJu
FX2GdwOFxejjmTJbxMQsZgKSrptFkpeJSnVLXJhJHGuw8SH367BRx8wozLa6SiXt
7NNSH+U1cppCvw5yTv8ZTNcFqOtaXYnqaHXpywsCo+tdZkcoWEXRB0ykN9NTHh2D
dwgceFSvB/j//rG4vp8Cl0yBv68XohjNNSYtDfe5/RzEuu/jlbot/Hgw8RMIUDK6
1RecT/QWM1/4LVoiES8fdm/f2AvYwndIq8QEFROG6wsUDd8TXU5fw2hcZxGIPoGg
L2L6bBnz5vBcs52YIcywi9K5vI2OKWN8PxsIr60yMP57SEt19LF9/Nqum20gyBvF
sH8YkHTds2bq0THmyCg5GSesyUVx1k6b/QozJhG4Yg0MuWyPDRSWCAV7qQghh6Ze
eRlEwDn7+s7SSM7Ygzf0qGG3YiGyAUGnkHNefQiukdPJBwR+71qQ0pdHWK/qCTAX
bouOmmeKEHaf//8xIKNHHELVTOra2MyehsvBu3twuhEjcrordckZ3wgWt+kxXFKc
v/4OX+jnSqCK/IogsLrNbPBDeBk+bYDOLclsOh9pzI+UH4R7PRTiOAfCgtHBykns
e2bQJTHMClwk8B3R+hrc2sBmTSU1EFsAXW3uMT37RpClm7vgT+ppQHurHFl/k/cE
Zk8t5eGt4n4RwBom11g4rvZ75oQxuk7aBEQOlV/ZQ1M0Sr4PJzQkujEBq03N6x/Z
OZZoojq/uPZi9iyxuJcJyFKrv/EZKuHqOcnxK4kAfVGImLnTaThu67AuxEsE53yc
7YXWlDXZ8d6d2gM7lQKrrC+b8XsLbY0/mJMlNRKjZlIUg933/vJuQh7smBS93v1d
l7yZXV5I4SFwK5i8+xfjcqvVf6i+tV7CDfotdA8m/dlz7ndD4fIwZBg2+7nijSIf
kSVaqhCroQV2t5t+EDaEDbKC09O6Gbx5AeVeKvPosPjBJv+91vmrTvNAa9oAJFsA
irrVsEA3RRQxXhZM/WjGiW/fIfWlBit4Qllmy+oCV8BiKVdc3yx3AQAQMnglydgk
1wbWL+lbxTTtXDyjnKOXmA1Z7mW+OA1XSbdO7Xek/0diP0bhPmjA9JN+6XitX6Jv
frVlAip6aPgMXvKsZVYfHEtKdlhnrj0DAziH+PfeYGiGbtPNHb3WGD8eUq0Jy4vZ
PVUqitpIAcP3daBKdA+nwljIHMVLN9KAWaYQ1aezb3/A3wzSLGEcvQ03ynNSebla
COy/5KICRqddgqQhJwaCZRp83ybA7dJZwf2THT3YDpeWop6qWwbcGVIisg2xGgBb
GJfh3jbucc1MmPQ+E2N9SO7kaWYhxFd2r1x5ThiAf+F2BeV6YqySirPIr+F/TxPr
aac7Nms7+1MdFitKV4y5OxrJD/3fAqRHZg4rJwTDVVEhi0gYmmFtLnPNitjfqaCf
OwyVtWno7btwYol4I/mk10pO4LNIgf0BbodR3WfUtXWrPZAbcKmYQZ5EYYsdQ3iB
WTuhM9tT4fDLzIWcrnh4p+a+wxv83KUoNR2y0pSAxWlZxr1goQqtQb8HvhNJAqFh
QX8t8PmGEYV6H5pWWEKGJiIEcxcssZLpsUEa2dNoDkBFOA/vSxNxneZmzKfc2khQ
qODSEqJJnaxVF2wHo0NQpn7HO0lVRQxcf61lR7oj1d1E7h4s5Z/HHP5miMljBukY
dnvMOO6cSchzhoATbZx6QMhJLikcXst+bfMD8gI1xE9VnGvu6Tr+P6RUZaabmhk8
BI6XZj6lnMjD7nhY3NO6XR02Z0/qpeadrkNp+D+4FUAxtvZ/HXV9mW+htM9Q/x6Q
m0EchCf6LyCuwaCuAzFbeogFNQ3WPZnshqm+GAjoCGkRq0SISJTkxlFJa2cnsb3k
D1A6kRguKJpWhTwqki+7pMWW6BvfEqdq1N67TJd26xjCa8Ed6Iy5m9hCkL+qfUvv
6e0xq4xQvBKvAoQuROGKE8ZmM6/2BC4s/MQHjeRh3ctc8MfwJMVfq7JsJ383w9yH
++b0fbMJvdOjpToXdjWeRsRdx/mLiawLdJ3I1uoUIFXY06/WRUzWJCuC1GBLfJE6
KApvkT3w7Z7z8bNd14o6aOhlBJcOvACrnniMwBmQLtCsAkpLpz64cCUy0nLqOMLC
wfezbuQeUx4kOKMjMX//vjE3wgBk5dn+mBBj+4BMFgB+u9/X6xXt+N/klIMUjM4a
qbngX5iK/Ps+3+Pxjq2bQb6QAzI74swOEYED+5n73Xep7QFOqln22JMTOWjaeoDl
Acxn/mv9PkzHr0rPnHCADQC+K7zsPAyUcaUBT9ljQ3bbLRTXuagpLQD0v9Rjsj43
wqoo76sKtMgfCQg6urH55as9UJfxoK7Un9fQBmugvSdbxU3T9EeWCRGI3WxDHgKB
QqkxJsinbs8Yjfd+RQleXagTDsRCHywZqY7JuvQIDuj1XE+Ok9lg8G9YTIl+DwDU
x5CAL6aIXcSnpM0CPPdlspaWXBzh4/xABgGTfghgJ4chfhmLEzqucf/235skzFCZ
2aEEDFJdXcoE/eaEOF5P2S/c86NegXwtDfLJxAhosJ0SAHizfgwMrFuqg/i7ndt7
`pragma protect end_protected


endmodule
