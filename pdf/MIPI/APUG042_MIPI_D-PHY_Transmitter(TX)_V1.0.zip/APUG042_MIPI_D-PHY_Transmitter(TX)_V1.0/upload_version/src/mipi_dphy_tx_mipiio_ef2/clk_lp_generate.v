

module clk_lp_generate (
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_rst,

    input wire[3:0] I_lane_state_code,

    output wire     O_clk_lp_p,
    output wire     O_clk_lp_n
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
PYNULCA4ZBaxRjaR9M7roEcBomtu35h6gR28sD9m+eHwBesEzv7WOAvrB2dGzp9P
0Owz3XvQ6FBWkfn107yuMPLNYmDkTYwdEZ7IvjAjoi0xd/b4McbaB9Z0ViAVxwT2
f6CCgOyHAbybvprRq+TQabdIxDLFbBPZ+BZ9guBgWXk=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 1824)
`pragma protect data_block
Z3RpdTgzNllNUnNHQlZ3a5mHU7eG1e+x06/Y4krIfAu80nsFyoR3P1ZxhItF3Zwz
UN75nJKnl7S8COsO/U6haQm+9r6ixRWrIZiCinHjdb+WQ0zLwthDa9uTTNldxBde
6whgt+PaLsjfSNdir1Pba5FhmexopoE6zoUcXi9E3JWjLCp2ctdS4iDeu7nt1Alb
O3bxChC+XwWcvx9GwvmONg8YWRr8AH+tHEZ28nbqCC+1YW9xqgPAHoNaqNduyRCW
Iv7hNZ4/KbdE6MNcL06t66SLtvvr2+5Y9boTZFKHfSTsBwPInq75Do43KdWnV/6l
8XFTsPd25UAo9nKFNCRtnaZLP+ysCbGrc9dgqq/OYuU1FntYLKO5PCL/p4OQBmJo
ZUrDEPcyTkXZb0M2n3YYpDCe8sw0WiKNF7N/h3W3yWLVMrM0KipYixapYtejyhMF
qHOFnyfp688ok8ESaIv9wv6gsU7osvcvUFmNZRsdIG641M4ImrzkWWOp+pRlApfU
g3CO2NQkh1xnltHwA2R2OhS0C+xOvLKFZqOSSJ7PcqmPc4nt2+VRoa7xhWM/3Do7
hC59q7CavrL0Dlj0g21UbMik3FGNy7X+Vo/3XbjMNF0GDSgmmedQgU0BZ0zPnhnw
K8PC5MmYseEiBaJEus98rbwu+vBERU9zapJNslFPonKUEY4ROFOqwCXIQWY25Lx6
6oVyPfEjMoV5F3CeT5dFebnSyGOBvSZITpBRAZ6KbbIFrHvb0KAy8sAxBje5mbDJ
S6K6xBm0IR5mBTzKlNz8WLQmJGhbDfnMKs9wXsVuPuoURW7EJ6g2L335TBNlSc1i
qc/O354kQgva7l9N6jYMnWq//6btQEZZ98y5yjhLJiXHETq1qmcVNSo6YoJ5PzCc
XdOK3Nm4vHJRbJ9mDLSYtTXkm/bKICuMtfJSOYWkYO32W2PCv/4gSaqLywlCQ7qP
8L3zHzJr4eIqV8L71r1EhNlKk1982WVTY7JfvMJGjYft4AUyMpswHPsFVd45T+8W
KXEnqay5Mn5cYT+zUWC6KioDeNjQHzGNBnMRb5xY16hv8INIwoyUkcSNKQJ3rGWs
uexlxOdul0wpbmof4d30IMuhupgA0ou0Z3rqltHYVumobhPQWEHQBeQeqRisG2xk
9oFaLgLpOmLHIFf/o6g7bGkZi096jYGq2ZzsXDD+y3jNVgtF3UueXHMAIHUFapkK
5jKwNqZ4Wim8iN3lZMSVZANVYrZh+Kv/QMPqzxzSrZFCYCArW/Q2xWeq1QU9Nhu7
mFTlYvPHpoCrYqapy7jpyvNKXpSzYQANjgixp4CFt8kksQvWNBmPKOBPl5QD1ZNM
WB68J+XbDPEr0+EbFZjS7i0gGSXVCZI/XvXkhXqRZVHk5vhyt/g3FQpTxs2bBC+K
NcJAB5ReHORQaDw5aqrzM+D9MD3u1aC4YyGmQN1Y07Ns7AUdOBq2euSMS5P6gZc5
MuhkMFW1xArccLMTxStXb5hlYdRgt9nLEZBNhD6Gn0Ruie1fkQZUgKjA+KDr8gIS
tp181B1uZn/OzZy3dJcr7VhhMxZfzPu27Py/hRV7Xc/QuJkN+cSrM9YKsjnMpBIP
hJNgW2PYKbpAq25nMkiDYw/gH6ocN8xwVqqnm3OOBt/c4pvDxf/36Wuz2tQdnb0O
ZGzkYeq+DMp9dDwWy1eFpqy3RvU/rdIT1hdl5FqN8RAzE7OOeLCFBGOwjkMMTbAp
ZLjnTYGUwMU4slWS16DkzDe0l8sg0L2tapWVQmkm7Q8j2CABp9BisnTYet4w2HTp
yGZxKsMJu/Hm9lRWAkctdBc7XcONIFR8qRJohMLKvGEXz0OTHliBSDWZYgwL8Zm+
r4GiW391BO74/z1EviMjjCMxdLekLKmZivEvdPx/zz2Hgb/eW5Yd5P2aP4E2LHk3
Xur0WIy4b9TLD6fBQvDnvPFFxSv+V45axawr4mAg/K5CM4VVxQ7RgSYQVowAtVhG
FxJZaYt6SyRNEVyETHa3zm3SNirv4CScUfRk5JoLt66utwwIczQxSZ5hHZnhcqWT
p4OoJyev+6U69KRH3D4FCjRjw+7y+DGXOiL4eWGBJc5HyYs5W02FNmJrZNXWNkhR
VFCWgeJ94wLyZI+V+oeRd5F1LFLtT7UdsdrVThNwYJOWhv9v9pSAmImocHXp1RKx
q49LACx33kB5/K01LNj+DnJBLT9s1BSObpCgha/fo+qbXxZmUDHyii0WKeDjCLu4
xTW6jIX0CHxg3h5np5PAE+ubAAFVIEILtI6Z36os5MrizjKRF1QK9QGSHGAYUQGP
TTk1YVJ4EsVYOumdXmk27bk2NtoHXlZE6TWQuQtQeSJR5gBmTHdbbiE+CNdvgDh1
B7qonKM9C++ZrrjSkZe4g3DoE7o1eANCiBkIvVzivmGToDFjOpL63ZVt2iVQjtGz
`pragma protect end_protected


endmodule