

module mipi_dphy_tx_wrapper #(
    parameter LANE_NUM              = 4,

	parameter HS_TX_FIFO_TYPE       = "BRAM", ///"DRAM","BRAM"    
	parameter LP_TX_FIFO_TYPE       = "BRAM", ///"DRAM","BRAM"	
	parameter LP_TX_MAX_DATA_LENGTH = 100, /// 1-240

	parameter CLK_LANE_MODE         = "INTERRUPT", ///"CONTINUE","INTERRUPT"

    parameter T_DATA_LPX            = 4,
    parameter T_DATA_HS_PREPARE     = 4,
    parameter T_DATA_HS_ZERO        = 10,
    parameter T_DATA_HS_TRAIL       = 10,
    parameter T_CLK_LPX             = 4,
    parameter T_CLK_PREPARE         = 4,
    parameter T_CLK_ZERO            = 10,
    parameter T_CLK_PRE             = 10,
    parameter T_CLK_POST            = 10,
    parameter T_CLK_TRAIL           = 10
    )(
    input wire                 I_hs_clk,
    input wire                 I_hs_clk_x2,
    input wire                 I_hs_clk_x4,
    input wire                 I_hs_clk_x4_90d,
    input wire                 I_lpdt_clk,
    input wire                 I_rst,
           
    input wire                 I_hs_tx_valid,
    input wire[LANE_NUM*8-1:0] I_hs_tx_data, ///[31:24] -> lane3  
                                             ///[23:16] -> lane2  
                                             ///[15:8]  -> lane1  
                                             ///[7:0]   -> lane0
    input wire                 I_hs_tx_last,
    output wire                O_hs_tx_ready,  

    input wire                 I_lp_tx_valid,
    input wire[7:0]            I_lp_tx_data,
    input wire                 I_lp_tx_last,
    output wire                O_lp_tx_ready,

    output wire                O_mipi_clk_p,
    output wire                O_mipi_clk_n,
    output wire[LANE_NUM-1:0]  O_mipi_data_p,
    output wire[LANE_NUM-1:0]  O_mipi_data_n
);


	localparam LP_TX_FIFO_DRAM_DEPTH = LP_TX_MAX_DATA_LENGTH + 10;

    wire                S_hs_ready;
    wire                S_lp_ready;

    wire                S_lp_tx_p;
    wire                S_lp_tx_n;

    wire[LANE_NUM-1:0]  S_data_lp_p;
    wire[LANE_NUM-1:0]  S_data_lp_n;

    assign O_hs_tx_ready = S_hs_ready & S_lp_ready;
    assign O_lp_tx_ready = S_hs_ready & S_lp_ready;


    hs_tx_wrapper#(
        .LANE_NUM          ( LANE_NUM          ),
        
		.HS_TX_FIFO_TYPE   ( HS_TX_FIFO_TYPE   ),
		.CLK_LANE_MODE     ( CLK_LANE_MODE     ),

        .T_DATA_LPX        ( T_DATA_LPX        ),
        .T_DATA_HS_PREPARE ( T_DATA_HS_PREPARE ),
        .T_DATA_HS_ZERO    ( T_DATA_HS_ZERO    ),
        .T_DATA_HS_TRAIL   ( T_DATA_HS_TRAIL   ),
        .T_CLK_LPX         ( T_CLK_LPX         ),
        .T_CLK_PREPARE     ( T_CLK_PREPARE     ),
        .T_CLK_ZERO        ( T_CLK_ZERO        ),
        .T_CLK_PRE         ( T_CLK_PRE         ),
        .T_CLK_POST        ( T_CLK_POST        ),
        .T_CLK_TRAIL       ( T_CLK_TRAIL       )
    )u_hs_tx_wrapper(
        .I_clk         ( I_hs_clk       ),
        .I_clk_x2      ( I_hs_clk_x2    ),
        .I_clk_x4      ( I_hs_clk_x4    ),
        .I_clk_x4_90d  ( I_hs_clk_x4_90d),
 
        .I_rst         ( I_rst          ),
 
        .I_tx_valid    ( I_hs_tx_valid  ),
        .I_tx_data     ( I_hs_tx_data   ),
        .I_tx_last     ( I_hs_tx_last   ),
        .O_tx_ready    ( S_hs_ready     ),

        .I_lpdt_tx_p   ( S_lp_tx_p      ),
        .I_lpdt_tx_n   ( S_lp_tx_n      ),
                                        
        .O_mipi_clk_p  ( O_mipi_clk_p   ),
        .O_mipi_clk_n  ( O_mipi_clk_n   ),
        .O_mipi_data_p ( O_mipi_data_p  ),
        .O_mipi_data_n ( O_mipi_data_n  )
    );



    lp_tx_wrapper#(
        .FIFO_TYPE   ( LP_TX_FIFO_TYPE       ),  ///"BRAM","DRAM"
        .DRAM_DEPTH  ( LP_TX_FIFO_DRAM_DEPTH )
    ) u_lp_tx_wrapper(
        .I_clk         ( I_lpdt_clk    ),
        .I_rst         ( I_rst         ),

        .I_lp_tx_valid ( I_lp_tx_valid ),
        .I_lp_tx_data  ( I_lp_tx_data  ),
        .I_lp_tx_last  ( I_lp_tx_last  ),
        .O_lp_tx_ready ( S_lp_ready    ),

        .O_lp_tx_p     ( S_lp_tx_p     ),
        .O_lp_tx_n     ( S_lp_tx_n     )
    );

endmodule