
module data_lane_wrapper #(
	parameter FIFO_TYPE  = "BRAM",
	parameter DRAM_DEPTH = 50
	)(
    input wire      I_clk,
    input wire      I_clk_x2,
    input wire      I_clk_x4,
    input wire      I_rst,

    input wire      I_tx_valid,
    input wire[7:0] I_tx_data,   
    input wire      I_tx_last,

    input wire      I_lpdt_tx_p,
    input wire      I_lpdt_tx_n,

    input wire[3:0] I_lane_state_code,
    output wire     O_hs_data_end,

    output wire     O_mipi_p,
    output wire     O_mipi_n
);

    wire      S_data_lp_p;
    wire      S_data_lp_n;
    wire[1:0] S_lp_data_in;
    wire[3:0] S_hs_data_in;
    wire      S_lp_hs_switch;

    data_lp_generate u_data_lp_generate(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_rst             ( I_rst             ),

        .I_lane_state_code ( I_lane_state_code ),
        .O_data_lp_p       ( S_data_lp_p       ),
        .O_data_lp_n       ( S_data_lp_n       )
    );


    assign S_lp_data_in[0] = S_data_lp_p & I_lpdt_tx_p;
    assign S_lp_data_in[1] = S_data_lp_n & I_lpdt_tx_n;


    data_hs_generate #(
    	.FIFO_TYPE  ( FIFO_TYPE  ),    
		.DRAM_DEPTH ( DRAM_DEPTH )
	)u_data_hs_generate(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_rst             ( I_rst             ),

        .I_tx_valid        ( I_tx_valid        ),
        .I_tx_data         ( I_tx_data         ),
        .I_tx_last         ( I_tx_last         ),

        .I_lane_state_code ( I_lane_state_code ),

        .O_hs_data_end     ( O_hs_data_end     ),

        .O_hs_valid        ( S_lp_hs_switch    ),
        .O_hs_data         ( S_hs_data_in      )
    );        
    
    mipiio_tx u_mipiio_tx(
        .I_clk_x2         ( I_clk_x2         ),
        .I_clk_x4         ( I_clk_x4         ),
        .I_rst            ( I_rst            ),

        .I_hs_data_in     ( S_hs_data_in     ),
        .I_lp_data_in     ( S_lp_data_in     ),
        .I_lp_hs_switch   ( S_lp_hs_switch   ),

        .O_mipi_p         ( O_mipi_p        ),
        .O_mipi_n         ( O_mipi_n        )
    );



endmodule