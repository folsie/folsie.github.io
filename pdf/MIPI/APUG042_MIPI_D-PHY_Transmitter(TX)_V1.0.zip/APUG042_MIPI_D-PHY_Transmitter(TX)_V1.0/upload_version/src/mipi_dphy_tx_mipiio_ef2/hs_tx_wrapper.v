module hs_tx_wrapper #(
    parameter LANE_NUM          = 4,

	parameter HS_TX_FIFO_TYPE   = "BRAM",

	parameter CLK_LANE_MODE     = "INTERRUPT", ///"CONTINUE","INTERRUPT"

    parameter T_DATA_LPX        = 4,
    parameter T_DATA_HS_PREPARE = 4,
    parameter T_DATA_HS_ZERO    = 10,
    parameter T_DATA_HS_TRAIL   = 10,
    parameter T_CLK_LPX         = 4,
    parameter T_CLK_PREPARE     = 4,
    parameter T_CLK_ZERO        = 10,
    parameter T_CLK_PRE         = 10,
    parameter T_CLK_POST        = 10,
    parameter T_CLK_TRAIL       = 10
    )(
    input wire                 I_clk,
    input wire                 I_clk_x2,
    input wire                 I_clk_x4,
    input wire                 I_clk_x4_90d,
    input wire                 I_rst,
           
    input wire                 I_tx_valid,
    input wire[LANE_NUM*8-1:0] I_tx_data,    ///[31:24] -> lane3  
                                             ///[23:16] -> lane2  
                                             ///[15:8]  -> lane1  
                                             ///[7:0]   -> lane0
    input wire                 I_tx_last,
    output reg                 O_tx_ready,  

    input wire                 I_lpdt_tx_p,
    input wire                 I_lpdt_tx_n,

    output wire                O_mipi_clk_p,
    output wire                O_mipi_clk_n,
    output wire[LANE_NUM-1:0]  O_mipi_data_p,
    output wire[LANE_NUM-1:0]  O_mipi_data_n
);


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
k/R2xrHj1IJaCrrwtxum1o3/jAjNW85mE8CiDxNnb9bgfE3YPEl2oX6WKHHYRoqO
A8zIdPg4KX7fOJv5gXe8sGLQhoQ99EdCLvdH4jbmVy4HzMQ+YlZlbilgbG5ihmzQ
kMQfhS6RNjx/5t2c6AR5SW8EHKaonX7KTrYikxIb86c=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 880)
`pragma protect data_block
am5qSFVzeG5UTUFGUUpEVHt+kgnb9FiykgdnvM+EVYxKyzCqLXm+P2G9uiSQz0HC
bQc+V1kVIS4xl22Zcw3TzvepG7qiMjMNc04T0h9jAOblao0KjPk6p90XvejYMIRB
rEjbwCXrlIvusr4mkqH9ruDiLd+7VtGacO+J7MDhI1wPx0ahreA+76tcvlgWkFgv
KCekLUlsgJof8AgNZ4DUoYqRRGPhmcgm4h2eydMM/KxvPMQ9bunXO2Cr2bkQJEu8
N8458MvuoxESQ+tyJWqsbS884gYOZZUjUpU2P5UPdp/+ZVjPqLYiVqBq3De4II+L
/V1Ae9bgSXrrzKe/n2gMqAP1XOmyYML4hLjoBIR85xd/DwizeknnNoBDoOi8sacn
f7OANg8FCJTyR2ReF4qMeQih9XqSRMqO7hFgHlqh3G5fr4xb7AXAC7dh1TdI4uIS
HfGQu0+vPa6FVFaDiC2X0Za3HdcKbcDwZT36bPi1WTUYORBkg0+UhCyWKhNPbN4o
VJwGEc1+v2SxgCus8s+VlsikaN5WlpGMGnfaFerbjZ/dTDm5GmXjqtAqhgLUr2Xm
EU4ilzk+V/t+0VkkXzrGkTx7tI9KfNeMGZiiZxLhK4sWL6tKv9uzvJDFaUa7R/8C
c2TfJnnDLVpcP3Fdws3AcSOLbMDbJcQ+2ckqpiJMsoK1PmlSuMfpR5Gzp+ZZADvY
HtPw0/ZwnIJ06xx9WCpNv5LDUe7mnnrZmlR7kSfipX2Kb5zweVRQrpvALPxqeuBV
txeCE2yecNv4aCRjR9/ZBvXksyY9wt0r6SHOzzQcjqCPXaOFfIQXVtTeRsAx2S2m
cnKnTfy8mJ5FB8/DjSKuPJzNKHabQg8SrNiYvwSNQi6Dx4HHJJrqbPh5oUsQC+vQ
M5ZG6d6fTvhLRW6yyWvYkNrXjMZ2xUXbfBp1ftJ1HCAoHQvFbSlP+mOXW9Wx694G
2gFquRqZfOrIRwDlNcgM7HJBIXtJlSUwtZOMH7piZ1P2OqNq4OTn833wl05cKyvv
zwel1jtB9ROxfj4VrcPwR+OYAeOmEGMPisb7eT6If9sArvQacL/svrSrjYysDBJ1
/GOmPYSD4X/viz2Az4FhoSmGCDVl2lvjvoKoEmWhSIA/sgl8AY1JzgYDHFIuYoF/
nQUmmxO6m60aBU3uU0xMWQ==
`pragma protect end_protected


    hs_tx_controler#(
		.CLK_LANE_MODE     ( CLK_LANE_MODE     ),
		
        .T_DATA_LPX        ( T_DATA_LPX        ),
        .T_DATA_HS_PREPARE ( T_DATA_HS_PREPARE ),
        .T_DATA_HS_ZERO    ( T_DATA_HS_ZERO    ),
        .T_DATA_HS_TRAIL   ( T_DATA_HS_TRAIL   ),
        .T_CLK_LPX         ( T_CLK_LPX         ),
        .T_CLK_PREPARE     ( T_CLK_PREPARE     ),
        .T_CLK_ZERO        ( T_CLK_ZERO        ),
        .T_CLK_PRE         ( T_CLK_PRE         ),
        .T_CLK_POST        ( T_CLK_POST        ),
        .T_CLK_TRAIL       ( T_CLK_TRAIL       )
    )u_hs_tx_controler(
        .I_clk             ( I_clk             ),
        .I_rst             ( I_rst             ),

        .I_tx_start        ( S_tx_start        ),
        .I_hs_data_end     ( S_hs_data_end[0]  ),

        .O_lane_state_code ( S_lane_state_code ),
        .O_tx_end          ( S_tx_end          )
    );



    clk_lane_wrapper #(
    	.CLK_LANE_MODE( CLK_LANE_MODE )
	) u_clk_lane_wrapper(
        .I_clk             ( I_clk             ),
        .I_clk_x2          ( I_clk_x2          ),
        .I_clk_x4_90d      ( I_clk_x4_90d      ),

        .I_rst             ( I_rst             ),
                                               
        .I_lane_state_code ( S_lane_state_code ),
                                               
        .O_mipi_p          ( O_mipi_clk_p      ),
        .O_mipi_n          ( O_mipi_clk_n      )
    );

    genvar i;
    generate
        for(i = 0; i < LANE_NUM; i = i+1) begin :   MIPI_DATA_LANE_GEN
            if(i == 0)
                begin
                    data_lane_wrapper #(   
						.FIFO_TYPE  ( HS_TX_FIFO_TYPE ),            
						.DRAM_DEPTH ( DRAM_DEPTH      )     
					)u_data_lane_wrapper(
                        .I_clk             ( I_clk                ),
                        .I_clk_x2          ( I_clk_x2             ),
                        .I_clk_x4          ( I_clk_x4             ),
                        .I_rst             ( I_rst                ),

                        .I_tx_valid        ( I_tx_valid           ),
                        .I_tx_data         ( I_tx_data[8*i+7:8*i] ),
                        .I_tx_last         ( I_tx_last            ),

                        .I_lpdt_tx_p       ( I_lpdt_tx_p          ),
                        .I_lpdt_tx_n       ( I_lpdt_tx_n          ),

                        .I_lane_state_code ( S_lane_state_code    ),

                        .O_hs_data_end     ( S_hs_data_end[i]     ),

                        .O_mipi_p          ( O_mipi_data_p[i]     ),
                        .O_mipi_n          ( O_mipi_data_n[i]     )
                    );
                end
            else
                begin
                    data_lane_wrapper #(   
						.FIFO_TYPE  ( HS_TX_FIFO_TYPE ),            
						.DRAM_DEPTH ( DRAM_DEPTH      )     
					)u_data_lane_wrapper(
                        .I_clk             ( I_clk                ),
                        .I_clk_x2          ( I_clk_x2             ),
                        .I_clk_x4          ( I_clk_x4             ),
                        .I_rst             ( I_rst                ),

                        .I_tx_valid        ( I_tx_valid           ),
                        .I_tx_data         ( I_tx_data[8*i+7:8*i] ),
                        .I_tx_last         ( I_tx_last            ),

                        .I_lpdt_tx_p       ( 1'b1                 ),
                        .I_lpdt_tx_n       ( 1'b1                 ),

                        .I_lane_state_code ( S_lane_state_code    ),

                        .O_hs_data_end     ( S_hs_data_end[i]     ),

                        .O_mipi_p          ( O_mipi_data_p[i]     ),
                        .O_mipi_n          ( O_mipi_data_n[i]     )
                    );
                end
        end
    endgenerate

endmodule