
module mipiio_tx (
    input wire        I_clk_x2,
    input wire        I_clk_x4,
    input wire        I_rst,

    input wire[3:0]   I_hs_data_in,
    input wire[1:0]   I_lp_data_in,
    input wire        I_lp_hs_switch,  ///1: hs mode    0: lp mode

    output wire       O_mipi_p,
    output wire       O_mipi_n
);

`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
av/L7iEEVLNzfQ/k6U2zj2tpaseTRoK/Pt9MqZrAIFTXxUxyEb7hcnCBVVZikGmE
EXfMvW2V2LL/CwNtuQGTCdaHnP1wYYfcGvxe7wUEy9g0YEvZV4Exx4kNPGXnPU6u
Z8rsPK+Vswdcdxw9lzuspVKIECN7s1a6sIVZedzVW+k=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 272)
`pragma protect data_block
UGhuUTNjeGdzM2ZROTloUyLsbBZZi5Hz02Lo90K7sC4QfnxdDFdWC0NcBhb1m66U
xjuBwGyGpaSbpz0VU9fizg2zZAsfYvdcBWVg74isaDYynTZaDka/S7foy0QB/9Ld
as+K/YqD6T9h3Uy/KILq9bge6poLf+BoWSIwjSYatB2iYDA6gfPXwIi2rOt4J5ZA
rBPKwvJ1FtKucKeYzg6d9yAQwheDkcosjvvWCz9Zn8m/yvhs9PnVEqDxkIwoHEwW
FXt4GW4/o901vuoK/Wefm3Blj0rguiMRdCLMKK/zWdW99KbIrzn+6yJpkE+wqDo9
+2CCLN1w37zR92aZbTRVeHKvACWknd8ABw/ggpiOEII=
`pragma protect end_protected



    EF2_PHY_MIPIIO #(
        .IDDRMODE     ( "OFF"    ),
        .GSR          ( "ENABLE" ),
        .INSCLKMUX    ( "0"      ),
        .INPCLKMUX    ( "CLK"    ),
        .IDDRPIPEMODE ( "NONE"   ),
        .INDELMUX     ( "NODEL"  ),
        .INDEL        ( 0        ),
        .OUTSCLKMUX   ( "0"      ),
        .OUTPCLKMUX   ( "CLK"    ),
        .ODDRMODE     ( "DDRX2"  ),
        .OUTDELMUX    ( "NODEL"  ),
        .OUTDEL       ( 0        ),
        .MODE         ( "OUT"    ),
        .DIFFRESISTOR ( "NONE"   ),
        .DEDCLK       ( "DISABLE"),
        .SRMODE       ( "SYNC"   ),
        .TSMUX        ( "TS"     ),
        .INCEMUX      ( "1"      ),
        .INRSTMUX     ( "RST"    ),
        .IN_REGSET    ( "RESET"  ),
        .IN_DFFMODE   ( "NONE"   ),
        .OUTCEMUX     ( "1"      ),
        .OUTRSTMUX    ( "RST"    ),
        .DO_REGSET    ( "RESET"  ),
        .DO_DFFMODE   ( "LATCH"  ),
        .TO_REGSET    ( "RESET"  ),
        .TO_DFFMODE   ( "NONE"   ),
        .DRIVE        ( "NONE"   ),
        .IOTYPE       ( "LVDS25" )
    )mipiio (
        .ipclk    ( 1'b0         ),
        .isclk    ( 1'b0         ),
        .opclk    ( I_clk_x2     ),
        .osclk    ( I_clk_x4     ),
        .rst      ( I_rst        ),

        .lp_dir   ( S_lp_dir     ),
        .hs_dir   ( S_hs_dir     ),
        .vcmpd_n  ( S_vcmpd_n    ),
        .lp_dout  ( I_lp_data_in ),
        .do       ( I_hs_data_in ),

    /// not use
        .lp_rx_en ( 2'b00        ),
        .lp_din   (  ),
        .diq      (  ),
        .dynres   ( 2'b00        ),

        .pad_p    ( O_mipi_p    ),
        .pad_n    ( O_mipi_n    )
    );
    
endmodule