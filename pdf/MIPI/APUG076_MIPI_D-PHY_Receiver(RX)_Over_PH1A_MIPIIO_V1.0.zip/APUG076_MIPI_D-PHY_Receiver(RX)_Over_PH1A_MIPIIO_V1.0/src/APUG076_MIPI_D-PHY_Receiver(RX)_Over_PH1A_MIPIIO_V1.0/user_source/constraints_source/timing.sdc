create_clock -name SYS_CLK_50M -period 20 -waveform {0 10} [get_ports {I_sys_clk}]
 
derive_pll_clocks
rename_clock -name {LP_CLK} -source [get_ports {I_sys_clk}] -master_clock {SYS_CLK_50M} [get_pins {u_PLL/pll_inst.clkc[0]}]
 
create_clock -name MIPI_HS_BYTE_CLK -period 10 -waveform {0 5} [get_pins {u_mipi_dphy_rx_ph1a_mipiio_wrapper/u_ph1a_mipiio_wrapper/u_PH1_PHY_MIPIIO.hsrx_byteclk_to_fabric}]

set_clock_groups -exclusive -group [get_clocks {LP_CLK}] -group [get_clocks {MIPI_HS_BYTE_CLK}]