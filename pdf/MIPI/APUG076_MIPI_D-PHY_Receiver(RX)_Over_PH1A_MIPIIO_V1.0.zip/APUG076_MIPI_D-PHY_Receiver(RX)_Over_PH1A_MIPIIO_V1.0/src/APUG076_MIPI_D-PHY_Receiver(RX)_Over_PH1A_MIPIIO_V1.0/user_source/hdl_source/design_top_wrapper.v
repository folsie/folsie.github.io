

module design_top_wrapper (
    input wire  I_sys_clk,     
    input wire  I_rst_n,      

    output reg  O_test  
);

	wire       S_lp_clk;

    wire       S_hs_rx_clk;           
    wire       S_hs_rx_valid;         
    wire[31:0] S_hs_rx_data;          

    wire[3:0]  S_lane_error;          

    wire       S_lp_rx_lane0_p;
    wire       S_lp_rx_lane0_n;


    always @(posedge S_hs_rx_clk) begin
        O_test <= S_hs_rx_valid ^ S_hs_rx_data ^ S_lane_error ^ S_lp_rx_lane0_p ^ S_lp_rx_lane0_n;
    end


    PLL u_PLL(
        .refclk   ( I_sys_clk ),
        .reset    ( ~I_rst_n  ),
        .lock     (    ),
        .clk0_out ( S_lp_clk  )
    );


    mipi_dphy_rx_ph1a_mipiio_wrapper#(
        .LANE_NUM              ( 4 ),
        .BYTE_NUM              ( 1 )
    )u_mipi_dphy_rx_ph1a_mipiio_wrapper(
        .I_lp_clk              ( S_lp_clk        ),
        .I_rst                 ( ~I_rst_n        ),

        .I_clk_lane_in_delay   ( 9'd0            ),
        .I_data_lane0_in_delay ( 9'd0            ),
        .I_data_lane1_in_delay ( 9'd0            ),
        .I_data_lane2_in_delay ( 9'd0            ),
        .I_data_lane3_in_delay ( 9'd0            ),

        .I_lane_invert         ( 4'b0000         ),

        .O_hs_rx_clk           ( S_hs_rx_clk     ),
        .O_hs_rx_valid         ( S_hs_rx_valid   ),
        .O_hs_rx_data          ( S_hs_rx_data    ),

        .O_lp_rx_lane0_p       ( S_lp_rx_lane0_p ),
        .O_lp_rx_lane0_n       ( S_lp_rx_lane0_n ),

        .I_lp_tx_en            ( 1'b0            ),
        .I_lp_tx_lane0_p       ( 1'b0            ),
        .I_lp_tx_lane0_n       ( 1'b0            ),

        .O_lane_error          ( S_lane_error    )
    );






    
endmodule