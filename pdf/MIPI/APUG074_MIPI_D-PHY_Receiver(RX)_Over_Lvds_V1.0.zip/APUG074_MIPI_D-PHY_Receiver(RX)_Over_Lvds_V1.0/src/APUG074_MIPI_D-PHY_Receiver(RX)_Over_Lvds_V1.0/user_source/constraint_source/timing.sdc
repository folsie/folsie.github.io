create_clock -name SYS_CLK_50M -period 20 -waveform {0 10} [get_ports {I_sys_clk}]

derive_pll_clocks
rename_clock -name {LP_CLK} -source [get_ports {I_sys_clk}] -master_clock {u_pll/pll_inst.refclk} [get_pins {u_pll/pll_inst.clkc[0]}]


# EF2 EF3 EF4 EG device timing constraints
create_clock -name MIPI_CLK -period 5 -waveform {0 2.5} [get_ports {I_clk_hs_p}]
create_generated_clock -name CLK_4x -source [get_ports {I_clk_hs_p}] -master_clock {MIPI_CLK} -divide_by 1 -phase 0 [get_pins {u_mipi_dphy_rx_over_lvds_wrapper/u_rx_clk_gen/U_io_clk_div_0_*.clkdiv1}]
create_generated_clock -name CLK_2x -source [get_ports {I_clk_hs_p}] -master_clock {MIPI_CLK} -divide_by 2 -phase 0 [get_pins {u_mipi_dphy_rx_over_lvds_wrapper/u_rx_clk_gen/U_io_clk_div_0_*.clkdivx}]
create_generated_clock -name CLK_1x -source [get_ports {I_clk_hs_p}] -master_clock {MIPI_CLK} -divide_by 4 -phase 0 [get_pins {u_mipi_dphy_rx_over_lvds_wrapper/u_rx_clk_gen/U_io_clk_div_1_*.clkdivx}]


## PH1 device timing constraints
#create_clock -name MIPI_CLK -period 5 -waveform {0 2.5} [get_ports {I_clk_hs_p}]
#create_generated_clock -name CLK_4x -source [get_ports {I_clk_hs_p}] -master_clock {MIPI_CLK} -divide_by 1 -phase 0 [get_pins {u_mipi_dphy_rx_over_lvds_wrapper/u_rx_clk_gen/U_io_clk_div_0_*.clkout}]
#create_generated_clock -name CLK_2x -source [get_ports {I_clk_hs_p}] -master_clock {MIPI_CLK} -divide_by 2 -phase 0 [get_pins {u_mipi_dphy_rx_over_lvds_wrapper/u_rx_clk_gen/U_io_clk_div_0_*.clkdivout}]
#create_generated_clock -name CLK_1x -source [get_ports {I_clk_hs_p}] -master_clock {MIPI_CLK} -divide_by 4 -phase 0 [get_pins {u_mipi_dphy_rx_over_lvds_wrapper/u_rx_clk_gen/U_io_clk_div_1_*.clkdivout}]


set_clock_groups -exclusive -group [get_clocks {LP_CLK}] -group [get_clocks {CLK_1x CLK_2x CLK_4x MIPI_CLK}]