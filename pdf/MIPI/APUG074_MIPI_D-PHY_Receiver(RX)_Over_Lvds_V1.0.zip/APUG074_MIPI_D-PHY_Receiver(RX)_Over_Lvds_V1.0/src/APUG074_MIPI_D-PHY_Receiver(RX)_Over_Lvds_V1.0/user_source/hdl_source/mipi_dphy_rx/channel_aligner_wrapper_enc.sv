

module channel_aligner_wrapper #(
    parameter CH_NUM     = 4,
    parameter DATA_WIDTH = 8
    )(
    input wire                  I_clk,
    input wire                  I_rst_n,
        
    input wire[CH_NUM-1:0]      I_ch_valid,
    input wire[DATA_WIDTH-1:0]  I_ch_data[CH_NUM-1:0],

    output wire[CH_NUM-1:0]     O_ch_aligner_valid,
    output wire[DATA_WIDTH-1:0] O_ch_aligner_data[CH_NUM-1:0]
); 


`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "Anlogic"
`pragma protect encrypt_agent_info = "Anlogic Encryption Tool anlogic_2019"
`pragma protect key_keyowner = "Anlogic", key_keyname = "anlogic-rsa-002"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
VDqAHZppAUkscuy5+2467uHzdAA7QAUjoJ/M6yjOCKJIXZg6gn8xsRaWqzOYvBPi
vzHe4MGnWC6S9lYXBkSd9wmRXwqPUvKmqtAp3tOoC6iK3GQnHPKDh49aJGwc6m2S
gy4Yqal8SJIvGbvwC0SRhrrqapJhh0D0YRR8wQR4N1o=
`pragma protect key_keyowner = "Cadence Design Systems.", key_keyname = "CDS_RSA_KEY_VER_1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
dPMAFwY4Fw0l2/ZmkCkn/VMIXz0v22y9uTTFz4LTVr6mP0PJVkzVkiTKi88Y8q7B
tfP1hST0RXZVR7XRynt+ArusIEKE+ikgKtVDPTd6XVerWU8VPkKzPz9ijL6msobe
2ALXH0tVPfAPWgnNUxwCjPR+gloyJYAR/mzlhY2Ob0VBOAmby+lzmJR+I2qPNxHd
tY/u+ops2JNnf8tb+uYWE2QVNWOpamKYuoBGAu5Tzx7oPGZQysEQm7KjK8sdH1Eg
McjgW7xRoRrnNrY0gA254FO1LEHN9zaWvknIN1eWzyBMCd29aA8nPSsloF3o8i/u
5vOazVBrWdnrYcq2uq/dug==
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-1"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
A171aK98PBzuaw7sERWvYmVHWziqrihhiaXGfmaTV4psdtgQK7uusR3b8qJNseyy
TMJVERiVHjFtuHEagnuo+oOcbW+6vE+wN1R5G3NN0hG77yNOVBbctlMPp6KPf7Ry
IMOESSUBm+GtHwJkPB3MZ+ibuGSBzzbIxzE6kCKUZvI=
`pragma protect key_keyowner = "Mentor Graphics Corporation", key_keyname = "MGC-VERIF-SIM-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 256)
`pragma protect key_block
NBqAiQgYHNlr+YNrT4WVEktKU3TEfdFRxL2ME5IDSm2Ea68lWkR74mDG3xJeSXMx
Pa+M16MXmRlxWhGctw5vxFLnkp2g+NxAPAofXygBF8vcb0McyV1nb/xDDyG5w326
5n1m+VFZrwzdYPv8tyH74ZXuc8gBaPVGp9PuQrtdW2xyPvDHKyAZ299raFzk9iKr
eyM/iAgn7ctIDryRH9HWkdCxkHDaBt0URMB/ZngI7uiOINGqjfxv6hkzaAqrgk17
swn5e5p9Bgx06UPUctoFl2ZCi8aa5c3Z8HRyrLKaJxDs/Ghf7jIMBU2/j/J9MsGi
lak8g6Rt6OuxwIsgLGAM/A==
`pragma protect key_keyowner = "Synopsys", key_keyname = "SNPS-VCS-RSA-2"
`pragma protect key_method = "rsa"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 128)
`pragma protect key_block
aXkP+qtFCay+qswyGgqJK6ST2T7lrdXTKMxEL1gd0nreinA8P/KRbxx428YMyyil
QkOJZ5FWNwWvf8tsmMB4Y/4vcPcjzm11FcUOF45ZMDIiATKjQAwATqBiLEN07Srh
ieXu7pIC+bcLhUGEQn8DlD9m6qbWpH7Ubkre+aWd7p8=
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 64, bytes = 4432)
`pragma protect data_block
RHEsQt0b3AqpmGQqlW+r41wl8jJfAEI33n5dT+rRStb+pKDkEgN919PVdry4+/pw
FlNG4gqqe5QDoC7X1nN78V562cuVNe9gLETNg9gQXFkCqlLF2vQjhG49rjiL50C5
8W2/6hndWh3iDOJBEpUKAx7V/4PK0IsEp5u9H8kuPqN+n0WluEFQeubx7QNk8/qO
vk52V70acxAQbBAQWylxXicA3kQI5tmfMn0mvDO1Uc7tgnP29z7cQbzdUizsG8AM
sK/ThqfnnaF++J232WP0wOkym54xWa60vtoM5EcTG0YkzTpT9OFBIeUehS5fy3WZ
t1BLgerWjPv0nUchOcKxisqb5BSdcEZ++c0ZKym5HENYtGM1ELYy77648pHPKgKv
VWekBObRNCysbuNaP/KLCXBdeP5h5D4IDgf1FPDdx+IbSqQd/rjk7vRKlqH7WWnh
hIqIgoxMpzw/LvVsaz9TR8fGObi/rPxGu2NKVqW3Xrlu7atryzuPDE/PyNaKo03/
Fd3IID1GMdzcN4nxgvmrr5Fusm7H7zRdO7lfI+1JtPzXuOqFwXrLFdrAtU5pTLrf
ks72bO56g+NDsoyOHTz3SUZkzeBCBBIpoxNHlwUk1421vKmk5jIZNAyEvt1KStL2
BfHFUMnh0E3AnGSyfkLtCybwkd/jj4BGewf46XKUNc/0cYEaprCf6YYzuVNPJOUO
Co68emoKgzevMXTzWoO2SOJITqJPwP+YcpuyVzpofmdI2z1kOkuLhPRn3pBOQHCu
kcLDLA6Md0cJJe0zB7qWTsTRp0D5zAVy4vTMAY5ZOvdkljG7gOgb2X51l30dpu3W
S08INKjb7bBCjmCqQ8c1HAVa39lv6wOj1cymXT8jddFAma/zFAtyt8ZRO9H6IFSe
DFrCkVmwBPWB/jZ0jRG36YqxN/AWp3TeA6C0vl4+h7biBPN1cn9GqvKCLj/0OoOc
CdGi8N8QtwHCbYSc0XE/mwN4eiaQCcqlVElbGmTpvrR5cU35inFZJRHUWPL7VjF8
4tk3vH4qYeJqIwf+7cRFeU/FQBd2nwLzMrQlbeEiXUSpZNEjIGcgNWJw/feSFDyR
wLuC4ZZ1YF0lqqvWT0EorEiUQmt+PkgF5R8sXZ7HmGTaUtbbhEDySCFt8RnTfoGs
new0sqBiaX+iswQ14yU8dK0kkK8uC5hZCdZkEtJaMHiuRvnmiZRDtWRcvSubjTX+
Ixn2G4EGIBFE9mOyh3bbBL+giz9wgljUUm/iZl7hF1mHcL+o7HKrI5idBFABW4m3
mCCPBVFOyyVCHdBNPhOSPjsidGjy3i8Zz0cs0+zYflvCBe2hnIatsZJ8oqxD+G2B
VtpNyTjUeUiz5HkCltraKlEFhfDGxYPK2bFFQ9ZUMBM+aCjua5Bzlhzjt6pQKCxb
SMK4zTo8gVIH687AK6TVsmljnJLISAbSHZKdvwyzXMqVbRbDf4D3j38sIYMyvjnW
7V7EZ9IJKdjjgE/kXI45qib1x+L1GJsAG9ZOcXG70Kr60RQcrS1Bj1pgrlT4Xz/t
gh0k/eaJJCo2zxXkD+BOkPRCZvOa5wc1ZvV1Zae4wusXFHQ+idEyN5e3bF6Ds48R
UfVeHB7gqQtrCfp747T03CzracMij13yY90PCSQiWfgOMZZmKmEvKMm28Jk3iMEm
KNLcJR60i0Y4eL57KB4PFepkKeIVfGWtZpLvz8HJ5Od6KOIqSSVB831JZ+PaS/tz
nC9dt6Lm/0EUvGWevoB6CJ3E3n42FJBqNQIer1iE6Ux287/v4jaGaJAX1FJMZ9/h
awDZnT5j3kaeIZWQZn72uZpYG2ic8vIcyAA7Rg/X2Vr5j288SvPnPtpjVEwP8IjO
NrpTScFK2w7QhW/vEsd0rKHCbX1f59Ro3ID/RfBE0NpQrEo/yF3x+F/4Qj53AlFX
yBWIcZt7uNpRuc5/j547qFCnevrysDRUHthXi605sL0E1d+NWs2WYnjV1Nb/TD1F
WR9b6s2NVWTU4TxKCr8YPPodW9cDfrQFSPQfafoQ7kSDS+pF1xuVzxCY0hxjG8/g
NrAE9z40LW5U7g0dQBTG2kp2p0IOdccXugZx9FkN0hAleXgN1kIu9DHOeZOUVXbn
y6UGxGUz7FTVcvmQrq1s4K5cKEeSHhcGB8FgEHYqiC54dHSes+wUlkEWFGnbQ/q8
yeAk0fBeEZJXaSQPsiMmuL4Gcd1Xw1YgXzD6AuYcSC8gHLahkBPmrQ988LYctF3l
JXj9bxeSXi6AszelgpKDuSuYXAkG0EkeO1qBinmHytwvxYATb0iVph4VBibgeU62
8Pl8WOTVQ+jNc5uPTjWmcjS+beJox0GdQnI+GNR0cdIxS97tSQiot65cOZo3d/om
VstnnSMEWPN1l+mpimuKe0hzaEUEnyJKukjCEuMp44SaHNhpmKghXpdSemP7/bZN
gquYIksZfTg412jm8rP9yoGhMH0H2Ta0y3E2mY7Cr4eZlLvFTF441pZL3v0D9kia
6T/w4Tto4qTHC5TzGWBlKyL81V8sEH4Pk2sFArO6Lf+Tva7b2VjtWIyHbgIfrdKP
qkx7SI8zISSZufCgE1xfV3O6pUoSbXEt36Go3ljAGHcBtjRNbSXH4acXwtlCeXY0
QjwhMB7se9Yd92+N1Jgwt7377QmhFnyL8M+fkUFNGjNx+X6Ho1bUsJeB7WlvURtl
kUsK+1b88HYQDKsIzYFkaqkAHB4JEYe1t50eV1dm46RPKVClpxDqMCW2EEIQo19j
E/cAYBD4pmvF03Xp+P8vFPml8Jgz4xxdgcj4izUm2sAW3iz6msFgRuutDdUyX7cb
TiF/wpM6s8a4un54Hxbwb3yjuWlZuPEZMp1TZv1P5zCNUPIcI12dQsmO2c3QGqfw
ibbPqpMw+BtFOqSi8ULtIYciZkRYWfNTj5MzPzSWsID/MZnkW82X+iS0RAEiuQ2v
gg0W4QrYG0UjfAzAmgMOYakp5CHUYSA6lyBflz5zQXf+dprljESh7Ov01wSCgTD1
wa/RTpmUxwnYNuSU1jwXSvQwwcKVfW0PLAR5E/DNAFueYZrwJ6FRKhm1LYA26Iih
Na4o5J/HdmsYe2I7RfdbSETL/BWtviCYEmTTmub529rpa5Ay8+HEtc1qARyeekwe
9L2rq/VaPRw4kEdHODrft4tQFjMHJ9nUApRoneK3hHkY9m28IMO5ssZImInWfo/l
LIQGPAzZGx6FokD6BbX3SInKXaLf/gaFS8yvDCNZIwix/+dohIYgEvt/kjvPrdTf
0dbnXF5ZVH6TD8hm/6WVk/n4ZtozhTnoDTMh4YWEd7sMXGh23lvfw/awFWFoly6x
0IYG/7B3t1inWnvqBhidVN9mGOholSMGK6EzQEHpthCvHFK4hqWhUcfjdWIX0h4K
7yf8JUzboASfvOuJnX7Z5wSAGdIsN4iW9w9r8YOqy3sAgn7vvXdcS9MPyAMdEMLL
8xBLkxV2IUC55SK053P2FskQKIE16lBXUc3OHQC2uvb3A3jxwAcA3LjZm+ScLDmx
d6oZhNOUSzrVDhW2ogmFDynJFTkYObLmYd9YtrMBNbJegJl+hLcgJ08fnq/w/O6/
eIZt5H5+WwXoODoiqV7ne7FpFfKpY1d3VkCEEvLI8nLawkVmpPxTLgkj02xDmNi/
JGNwaALNF5ZM4vC982Liwei4CsAL82HLHm6ojASwKuLANyYvZkr0dEpJVVfzWrCj
5b9EpwdUY5+HARORqf2i+dQm4/ogUA4CRtikqtdUJkCJ3q5dGjv5Teva8Hgx+zR/
spqhDTwsnzmZ/qnKmGWb2WxeaVPEh7O2YGahmvK9+Z14QzMzrw32r+Jmd72klfL8
lzcI7wcqB35LDqDtUmF4CdyEIXxZGrW+I4eGQTsrnCCVEIcOLM6G9uzcVi/dbqQc
WwKLDhozAnafEdxpJPURpm3SFH9DQ+JPSK9YDt7xB3TnEDSsQS1lpPZiXIwGfx2Y
C7/tCQO1w5xSDYdMKMvlz/oj1XUjYt1LjqQVHOS2NBG7RxJd5IVAW+nEzuwR+bnl
Rq2oXJjKtO5yJ63rHHoer1c76LYKDueCO9hGG9gYjkrgyCZAFgmYcHxe+j+spXMN
w/Y99WXbaV8m5ms71MuShuNMtmxIzkP+3b9EoaeGaY628bEL5vEqg6J+t4/KCQv6
b4ISuR4KseVq8nJsRI8iuPUJrJad/56MPkJzNNxdhYec+x0LZbkXIhJepHQGRLde
jWcBi7XAqx58bqWQ0Ank50RkItW3ho3WrnFFVqbq4v7x2r+SBr32dV/1HDLykBLn
lF9F3H8qwNxycDYwcG3P8hDrHgqkYxMP3QLjQTF1EX1lwlqsUcxAhgdPL7lPftlP
678Gl9HAR8fMo8K5c/76hxG52kROs0ypG6S2CmJKQZ2hbfRYcZdxthu4oIyvQU+J
49upUv1c86EG/AozZtTIn/sJ9iefhgeXcrvbsCY7qtSneCT04jKTJ0M6QGgkzPf3
tWhTDfVzOFF1T2v8V78kg22PL5IqAkImDYWuFIeGt0fX2Tg08gnGg3ay2cHdDExO
tL2lMPcfrlhEvO6vOOVr6LYBQArcVR6dAErEL86KU2QtWTVxKu04eE0S3eh4+dLI
hwvzZsfKV/4MaMPWdcb9n7ixmmK4v0yKzWMKCTTeu+sB3eqqolsf+MY998m5i15f
IFSVnx2MS3UWEYe/OLVyFeRFznAJihjKiFl0ftNkLm9gY340JRsYh5X2gP1gljt/
7ZlCNLn9RWHcxartPcwv+fnFewNGwsoT48fTCrSbDY/hVOP5UyfyQHwWNmk1f6Zz
76LgL0dJ4+31kOURNr5A3MaNnsAO3LyaMS8Hg+IfVbLHwESF5b6HHwdfvDNXfCnj
nOjz7MhSQFCh5ztSylSPSi1vb+d2CQtmf5IljNWgRJrOFrvXgteMwjgou0b8aM8S
iaPa5PFw+A8/U13pp6jglOl7XgHSMld1rhNHjc83bQ4HRLU8jVAoItprEcZxFa0y
xUq4fxSTgJzMeSFKkf27lFexeiVvtuH8eDYYhLUMhOMi4tpZi+dvIr58/UJjUZnh
mFO1+FqhAxU1lfTN3LC+vMEgXplTcf/diIq/hnFir8XxHk1Ydt9y4lvudpFPeoCh
yTNk/tetYS7UtS0MxEyDx80ut12Yc5pXsF4ec/kQ200d1fJqxWCDD7CXPMpvx0V/
kOWlpmZqxUczB+11DKa9XFy3jCZXdeCy5v2Y2b1iT5q5STiOhbNUpXLEhlHoZexL
eRo7CgeuWQ2tm/8R4strN5yADKgGRpFl6OZ170XZsWhzYiAyMxIfujpfvoAZ3Jof
MGd222Kqw/L6QygbMEexPnuG/QrpuWXXIXN87PCBaEwdYib7X5ibGvrnn9g3A99K
JqBe+nORisfraE0jQe94tL1BIy5/5UOaXNmqSPh4Ugn126VhPNDrGqJP9oqfouos
y/k3PnHHK6+zNCLYbWZ1tXjCjKVNrB9gFO/kOc+E2L7z2qWeHgS1j7JY/hl/ljx+
LsD99CuZkh3CPTLtOFC99AFPYYJIhKcUFxRaeniOm0KfFpGC78z9OOVflo1iZlon
relgx0VUD2FIABntcv0oDRAg3LHUNaW307YoEKD44Dg8scQGFiwPCY4YwQhIfnii
4FBfdim3h7re4GKChpOSbaM73E8WjBadk4402lBWFz8HHCXFG92ojXcNhVggz/H3
ul2Y3DjcALxwh04fGn77TLbmGs8I0UOWwsc2xi6XQbrg/JrycV87SKHfL5AXjYSM
dAoAL3Cfq4mpJ7RHPcp3HcdUXmwIbQiHymJlS0Zn8zlt4VrzrJ/JvLZvi+1Oz0kK
CT3Ui6jP8gDPLyDcpAobCe3PDgI9CqmkhHerhiC7Ue/MXosJ1v8hPr/AUSG+vVgr
0AMwc16OHGVRzKsWJ3rdkw==
`pragma protect end_protected