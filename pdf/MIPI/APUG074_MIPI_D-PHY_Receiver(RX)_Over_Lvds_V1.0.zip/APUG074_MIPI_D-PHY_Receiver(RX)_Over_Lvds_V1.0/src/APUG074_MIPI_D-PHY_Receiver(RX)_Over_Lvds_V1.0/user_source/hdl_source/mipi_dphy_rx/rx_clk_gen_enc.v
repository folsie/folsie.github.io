module rx_clk_gen #(
    parameter DEVICE = "EG"   ///"EF2","EF3","SF1","EG","PH1"
    )(
    input wire   I_mipi_clk_p,
    input wire   I_rst,

    output wire  O_clk,
    output wire  O_clk_x2,
    output wire  O_clk_x4
);
    

	generate
        if(DEVICE == "SF1")
            begin
                dphy_rx_pll_sf1 u_dphy_rx_pll(
                    .refclk   ( I_mipi_clk_p ),
                    .reset    ( I_rst        ),

                    .extlock  (   ),

                    .clk0_out ( O_clk_x4     ),
                    .clk1_out ( O_clk_x2     ),
                    .clk2_out ( O_clk        )
                );
            end
        else if(DEVICE == "EF2")
            begin
                EF2_LOGIC_BUFIO #(
                    .DIV( 2 )
                )U_io_clk_div_0_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst	    ),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( O_clk_x4     ),
                    .clkdivx ( O_clk_x2     )
                );

                EF2_LOGIC_BUFIO #(
                    .DIV( 4 )
                )U_io_clk_div_1_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst		),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( ),
                    .clkdivx ( O_clk        )
                );
            end
        else if(DEVICE == "EF3")
            begin
                EF3_LOGIC_BUFIO #(
                    .DIV( 2 )
                )U_io_clk_div_0_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst	    ),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( O_clk_x4     ),
                    .clkdivx ( O_clk_x2     )
                );

                EF3_LOGIC_BUFIO #(
                    .DIV( 4 )
                )U_io_clk_div_1_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst		),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( ),
                    .clkdivx ( O_clk        )
                );
            end
        else if(DEVICE == "EF4")
            begin
                EF4_LOGIC_BUFIO #(
                    .DIV( 2 )
                )U_io_clk_div_0_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst	    ),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( O_clk_x4     ),
                    .clkdivx ( O_clk_x2     )
                );

                EF4_LOGIC_BUFIO #(
                    .DIV( 4 )
                )U_io_clk_div_1_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst		),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( ),
                    .clkdivx ( O_clk        )
                );
            end
        else if(DEVICE == "EG")
            begin
                EG_LOGIC_BUFIO #(
                    .DIV( 2 )
                )U_io_clk_div_0_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst	    ),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( O_clk_x4     ),
                    .clkdivx ( O_clk_x2     )
                );

                EG_LOGIC_BUFIO #(
                    .DIV( 4 )
                )U_io_clk_div_1_io( 
                    .clki	 ( I_mipi_clk_p ),
                    .rst	 ( I_rst		),
                    .coe	 ( 1'b1		    ),
                    .clko	 ( ),       
                    .clkdiv1 ( ),
                    .clkdivx ( O_clk        )
                );
            end
        else if(DEVICE == "PH1")
            begin
                PH1_PHY_LCLK#(
                    . CEMD   ( "SYNC"   ),
                    . CLKSEL ( "ORG"    ),
                    . DIV    ( 2        ),
                    . LCLK   ( "BYPASS" )
                )U_io_clk_div_0_io (
                    .clkin     ( I_mipi_clk_p ),
                    .rst       ( I_rst        ),
                    .ce        ( 1'b1         ),
                    .clkout    ( O_clk_x4     ),
                    .clkdivout ( O_clk_x2     )
                );

                PH1_PHY_LCLK#(
                    . CEMD   ( "SYNC"   ),
                    . CLKSEL ( "ORG"    ),
                    . DIV    ( 4        ),
                    . LCLK   ( "BYPASS" )
                )U_io_clk_div_1_io (
                    .clkin     ( I_mipi_clk_p ),
                    .rst       ( I_rst        ),
                    .ce        ( 1'b1         ),
                    .clkout    (              ),
                    .clkdivout ( O_clk        )
                );
            end
    endgenerate

endmodule



module dphy_rx_pll_sf1 (
  refclk,
  reset,
  extlock,
  clk0_out,
  clk1_out,
  clk2_out 
);

  input refclk;
  input reset;
  output extlock;
  output clk0_out;
  output clk1_out;
  output clk2_out;

  wire clk0_buf;

  SF1_LOGIC_BUFG bufg_feedback (
    .i(clk0_buf),
    .o(clk0_out) 
  );

  SF1_PHY_PLL #(
    .DPHASE_SOURCE("DISABLE"),
    .DYNCFG("DISABLE"),
    .FIN("200.000"),
    .FEEDBK_MODE("NORMAL"),
    .FEEDBK_PATH("CLKC0_EXT"),
    .STDBY_ENABLE("DISABLE"),
    .PLLRST_ENA("ENABLE"),
    .SYNC_ENABLE("DISABLE"),
    .GMC_GAIN(6),
    .GMC_TEST(9),
    .ICP_CURRENT(11),
    .KVCO(4),
    .LPF_CAPACITOR(1),
    .LPF_RESISTOR(2),
    .REFCLK_DIV(1),
    .FBCLK_DIV(1),
    .CLKC0_ENABLE("ENABLE"),
    .CLKC0_DIV(5),
    .CLKC0_CPHASE(4),
    .CLKC0_FPHASE(0),
    .CLKC1_ENABLE("ENABLE"),
    .CLKC1_DIV(10),
    .CLKC1_CPHASE(1),
    .CLKC1_FPHASE(4),
    .CLKC2_ENABLE("ENABLE"),
    .CLKC2_DIV(20),
    .CLKC2_CPHASE(4),
    .CLKC2_FPHASE(0),
    .PU_INTP("DISABLE"),
    .INTPI(0),
    .HIGH_SPEED_EN("DISABLE"),
    .SSC_ENABLE("DISABLE"),
    .SSC_MODE("Down"),
    .SSC_AMP(0.0000),
    .SSC_FREQ_DIV(0),
    .SSC_RNGE(0),
    .FREQ_OFFSET(0.0000),
    .OFFSET_MODE("EXT"),
    .FREQ_OFFSET_INT(0),
    .CLKC0_DUTY(0.5000),
    .CLKC0_DUTY_INT(3),
    .CLKC0_DUTY50("ENABLE"),
    .CLKC1_DUTY(0.5000),
    .CLKC1_DUTY_INT(5),
    .CLKC1_DUTY50("ENABLE") 
  ) pll_inst (
    .refclk(refclk),
    .reset(reset),
    .stdby(1'b0),
    .extlock(extlock),
    .load_reg(1'b0),
    .psclk(1'b0),
    .psdown(1'b0),
    .psstep(1'b0),
    .psclksel(3'b000),
    .psdone(open),
    .dclk(1'b0),
    .dcs(1'b0),
    .dwe(1'b0),
    .di(8'b00000000),
    .daddr(6'b000000),
    .dout({open, open, open, open, open, open, open, open}),
    .fbclk(clk0_out),
    .clkc({open, open, open, open, clk2_out, clk1_out, clk0_buf}),
    .ssc_en(1'b0),
    .frac_offset_valid(1'b0),
    .dsm_refclk(1'b0),
    .dsm_rst(1'b0) 
  );

endmodule