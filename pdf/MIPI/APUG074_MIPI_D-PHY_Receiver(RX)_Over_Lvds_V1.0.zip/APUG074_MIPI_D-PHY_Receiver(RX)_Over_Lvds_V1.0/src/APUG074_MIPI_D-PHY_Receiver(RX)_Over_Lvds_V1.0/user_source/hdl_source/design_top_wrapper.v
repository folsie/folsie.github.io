

module design_top_wrapper (
	input wire      I_sys_clk,
	input wire      I_rst_n,

    input wire      I_clk_hs_p,
    input wire[3:0] I_data_hs_p,
    inout wire[3:0] I_data_lp_p,
    inout wire[3:0] I_data_lp_n,

    output wire     O_test
);

    wire       S_hs_rx_clk;   
    wire       S_hs_rx_valid; 
    wire[31:0] S_hs_rx_data;  
    wire       S_lp_rx_lane0_p;  
    wire       S_lp_rx_lane0_n;  
    wire[3:0]  S_lane_error;   

    wire       S_lp_clk;

    pll u_pll(
        .refclk   ( I_sys_clk ),
        .reset    ( ~I_rst_n  ),
        .extlock  (  ),
        .clk0_out ( S_lp_clk  )
    );


    assign O_test = S_hs_rx_valid ^ S_hs_rx_data ? 1'b1 : 1'b0;


    mipi_dphy_rx_over_lvds_wrapper#(
        .DEVICE        ( "EG"    ),
        .LANE_NUM      ( 4       )
    )u_mipi_dphy_rx_over_lvds_wrapper(
        .I_lp_clk         ( S_lp_clk        ),
        .I_rst            ( ~I_rst_n        ),

        .I_mipi_clk_p     ( I_clk_hs_p      ),
        .I_mipi_data_hs_p ( I_data_hs_p     ),
        .I_mipi_data_lp_p ( I_data_lp_p     ),
        .I_mipi_data_lp_n ( I_data_lp_n     ),
     
        .I_lane_hs_invert ( 4'b0000         ),
		.I_lane_lp_invert ( 4'b0000         ),
  
        .O_hs_rx_clk      ( S_hs_rx_clk     ),
        .O_hs_rx_valid    ( S_hs_rx_valid   ),
        .O_hs_rx_data     ( S_hs_rx_data    ),
  
        .O_lp_rx_lane0_p  ( S_lp_rx_lane0_p ),
        .O_lp_rx_lane0_n  ( S_lp_rx_lane0_n ),

        .O_lane_error     ( S_lane_error    )
    );


    
endmodule